﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class AttributeMasterData
    {
        protected static ILog log = LogManager.GetLogger(typeof(AttributeMasterData));

        public List<AttributeFieldsInfo> GetAllAttributeMaster()
        {
            List<AttributeFieldsInfo> mList = new List<AttributeFieldsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new AttributeFieldsInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            FieldWidth = mCmd.GetFieldValue<Int32>("FieldWidth"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                            AutoPopulate = mCmd.GetFieldValue<Boolean>("AutoPopulate"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateAttributeMaster(AttributeFieldsInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "AttributeFieldsActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 ActivateDeactivateAttributeMasterAll(AttributeFieldsInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "AttributeFieldsActivateDeactivateAll";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            //mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 InsertAttributeMaster(AttributeFieldsInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "AttributeFieldsInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FieldName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldName);
            mCmd.AddParameter("@FieldCaption", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCaption);
            mCmd.AddParameter("@FieldType", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldType);
            mCmd.AddParameter("@FieldWidth", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldWidth);
            mCmd.AddParameter("@FieldCategory", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCategory);
            mCmd.AddParameter("@DefaultValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.DefaultValue);
            mCmd.AddParameter("@AutoPopulate", SqlDbType.Bit, DataParameterDirection.Input, 2, mData.AutoPopulate);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateAttributeMaster(AttributeFieldsInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "AttributeFieldsUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldId);
            mCmd.AddParameter("@FieldName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldName);
            mCmd.AddParameter("@FieldCaption", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCaption);
            mCmd.AddParameter("@FieldType", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldType);
            mCmd.AddParameter("@FieldWidth", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldWidth);
            mCmd.AddParameter("@FieldCategory", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCategory);
            mCmd.AddParameter("@DefaultValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.DefaultValue);
            mCmd.AddParameter("@AutoPopulate", SqlDbType.Bit, DataParameterDirection.Input, 2, mData.AutoPopulate);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<AttributeFieldsInfo> GetAttributeMasterById(Int32 FieldId)
        {
            List<AttributeFieldsInfo> mList = new List<AttributeFieldsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsSelectRow";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, FieldId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new AttributeFieldsInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            FieldWidth = mCmd.GetFieldValue<Int32>("FieldWidth"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                            AutoPopulate = mCmd.GetFieldValue<Boolean>("AutoPopulate"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<AttributeFieldsInfo> SearchAttribute(String FieldName)
        {
            List<AttributeFieldsInfo> mList = new List<AttributeFieldsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FieldName", SqlDbType.VarChar, DataParameterDirection.Input, 100, FieldName);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new AttributeFieldsInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            FieldWidth = mCmd.GetFieldValue<Int32>("FieldWidth"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                            AutoPopulate = mCmd.GetFieldValue<Boolean>("AutoPopulate"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
        public List<AttributeFieldsInfo> GetActiveAllListTypeAttributeMaster()
        {
            List<AttributeFieldsInfo> mList = new List<AttributeFieldsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsListTypeSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new AttributeFieldsInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            FieldWidth = mCmd.GetFieldValue<Int32>("FieldWidth"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                            AutoPopulate = mCmd.GetFieldValue<Boolean>("AutoPopulate"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
