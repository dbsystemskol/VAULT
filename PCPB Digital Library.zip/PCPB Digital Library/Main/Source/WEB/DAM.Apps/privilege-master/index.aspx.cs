﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.privilege_master
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateprivilegeMasterList();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateprivilegeMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvprivilegeMaster.DataSource = obje.GetAllPrivilegeMaster();
                gdvprivilegeMaster.DataBind();
                if (gdvprivilegeMaster.Rows.Count > 0)
                    gdvprivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvprivilegeMaster.DataSource = objDAM.GetPrivilegeMasterSearch(txtSearchprivilege.Value.Trim());
                gdvprivilegeMaster.DataBind();
                if (gdvprivilegeMaster.Rows.Count > 0)
                    gdvprivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtprivilegeName.Value = "";
            hdnSelectprivilegeId.Value = "";
            if (gdvprivilegeMaster.Rows.Count > 0)
            {
                gdvprivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            popup.Show();
        }

        protected void gdvprivilegeMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    //imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    //imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                    imgActive.Visible = (hdnActive.Value == "True") ? false : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : false;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvprivilegeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.PrivilegeMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.PrivilegeMasterInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowAPrivilegeId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        mData.PrivilegeId = RowAPrivilegeId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivatePrivilegeMaster(mData);
                        if (r > 0)
                        {
                            PopulateprivilegeMasterList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowPrivilegeId = Convert.ToInt32(e.CommandArgument);
                        gdvprivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetPrivilegeMasterById(RowPrivilegeId);
                        hdnSelectprivilegeId.Value = mList[0].PrivilegeId.ToString();
                        txtprivilegeName.Value = Server.HtmlDecode(mList[0].PrivilegeName);
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.PrivilegeMasterInfo dList;
            try
            {
                if (txtprivilegeName.Value != "")
                {
                    obje = new DAMServices.ServiceContractClient();
                    dList = new DAMServices.PrivilegeMasterInfo();
                    if (hdnSelectprivilegeId.Value != "")
                        dList.PrivilegeId = Convert.ToInt32(hdnSelectprivilegeId.Value);
                    dList.PrivilegeName = Server.HtmlEncode(txtprivilegeName.Value);
                    dList.CreatedBy = UserId;
                    dList.IPAddress = GetIPAddress();
                    if (dList.PrivilegeId == 0)
                    {
                        Int32 Returnval = obje.InsertPrivilegeMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateprivilegeMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.DUPLICATE;
                        }
                    }
                    else
                    {
                        Int32 Returnval = obje.UpdatePrivilegeMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateprivilegeMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                }
                else
                {
                    popup.Show();
                    lblPopupMsg.InnerText = "Enter Privilege Name.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvprivilegeMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Privilege.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvprivilegeMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvprivilegeMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvprivilegeMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvprivilegeMaster.HeaderRow.Cells.Count; i++)
                        gdvprivilegeMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvprivilegeMaster.Columns.Count; i++)
                    {
                        if (gdvprivilegeMaster.Columns[i].HeaderText == "Active" || gdvprivilegeMaster.Columns[i].HeaderText == "Edit")
                            gdvprivilegeMaster.Columns[i].Visible = false;
                        if (gdvprivilegeMaster.Columns[i].HeaderText == "IsActive")
                            gdvprivilegeMaster.Columns[i].Visible = true;
                    }
                    gdvprivilegeMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}