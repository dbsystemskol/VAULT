﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.IO;
using System.Drawing.Imaging;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration;

namespace DAM.Apps.favourite
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                //btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                BindLabel(UserId);
                BindFavorite(LibId,UserId);
                BindNotification(TeamId, UserId, LibId);
            }
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Value.Trim().Length == 0)
                return;
            Session["SearchText"] = txtSearch.Value.Trim();
            Response.Redirect("~/search-result/index.aspx?", false);
        }
        private void BindLabel(Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            //String tagHtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var favList = objDAM.GetLabelByUserId(UserId);
                ddlFavorite.DataSource = favList;
                ddlFavorite.DataValueField = "LabelMasterId";
                ddlFavorite.DataTextField = "Label";
                ddlFavorite.DataBind();
                ddlFavorite.Items.Insert(0, new ListItem("---Select---", ""));

                //tagHtml += String.Format("<li style='margin-bottom: 5px;'><a href='#'  onclick=\"sortingByTag('{1}');\" >{0}</a></li>", "All", "");
                //foreach (var item in favList)
                //{
                //    tagHtml += String.Format("<li style='margin-bottom: 5px;'><a href='#'  onclick=\"sortingByTag('{0}');\" >{0}</a></li>", item.Label);
                //}
                //ulTag.InnerHtml = tagHtml;
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindFavorite(Int32 LibId,Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FavouriteDocumentList dt;
            String tagHtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.GetFavouriteDocumentByUserId(LibId, UserId);
                if (dt.FavouriteDocumentTable.Rows.Count > 0)
                {
                    gdvFavorite.DataSource = dt.FavouriteDocumentTable;
                    gdvFavorite.DataBind();
                    if (gdvFavorite.Rows.Count > 0)
                        gdvFavorite.HeaderRow.TableSection = TableRowSection.TableHeader;
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
                    string[] arr = new string[dt.FavouriteDocumentTable.Rows.Count];
                    for (int i = 0; i < dt.FavouriteDocumentTable.Rows.Count; i++)
                    {
                        arr[i] = dt.FavouriteDocumentTable.Rows[i]["Label"].ToString();
                    }
                    var fav = arr.Distinct().ToArray();
                    var favList = fav.Where(x => x != "");
                    //ddlFavorite.DataSource = favList;
                    //ddlFavorite.DataBind();
                    //ddlFavorite.Items.Insert(0, new ListItem("---Select---",""));

                    tagHtml += String.Format("<li style='margin-bottom: 5px;'><a href='#'  onclick=\"sortingByTag('{1}');\" >{0}</a></li>", "All", "");
                    foreach (var item in favList)
                    {
                        tagHtml += String.Format("<li style='margin-bottom: 5px;'><a href='#'  onclick=\"sortingByTag('{0}');\" >{0}</a></li>", item);
                    }
                    ulTag.InnerHtml = tagHtml;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        int GetColumnIndexByName(GridViewRow row, string SearchColumnName)
        {
            int columnIndex = 0;
            foreach (DataControlFieldCell cell in row.Cells)
            {
                if (cell.ContainingField is BoundField)
                {
                    if (((BoundField)cell.ContainingField).DataField.Equals(SearchColumnName))
                    {
                        break;
                    }
                }
                columnIndex++;
            }
            return columnIndex;
        }
        protected void btnAddLabel_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                if (txtLabel.Value.Trim().Length == 0)
                    return;
                if (ddlFavorite.Items.FindByText(txtLabel.Value) == null)
                {
                    objDAM.InsertLabelMaster(txtLabel.Value.Trim(), UserId);
                    BindLabel(UserId);
                    if (ddlFavorite.Items.FindByText(txtLabel.Value.Trim()) != null)
                        ddlFavorite.Items.FindByText(txtLabel.Value.Trim()).Selected = true;
                    //ddlFavorite.Items.Insert(ddlFavorite.Items.Count - 1, new ListItem(txtLabel.Value));
                }
                if (gdvFavorite.Rows.Count > 0)
                    gdvFavorite.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {

            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Int32 returnValue;
            //divConfirm.Attributes.Add("style", "display:none");
            //divError.Attributes.Add("style", "display:none");
            //confirmMsg.InnerHtml = "";
            //errorMsg.InnerHtml = "";
            List<int> values;
            DAMServices.ServiceContractClient objDAM;
            try
            {
                String strFavFiles = String.Empty;
                objDAM = new DAMServices.ServiceContractClient();
                values = new List<int>();
                if (ddlFavorite.SelectedIndex > 0)
                {
                    foreach (GridViewRow r in gdvFavorite.Rows)
                    {
                        CheckBox chkSelect = (CheckBox)r.FindControl("chkSelect");
                        if (chkSelect.Checked)
                        {
                            string value = r.Cells[GetColumnIndexByName(r, "DocId")].Text;
                            values.Add(Convert.ToInt32(value));
                        }
                    }
                    for(int i=0;i<values.Count();i++)
                    {
                        strFavFiles += values[i] + "^" + ddlFavorite.SelectedItem + "^" + UserId + "|";
                    }
                    if (strFavFiles != "")
                        strFavFiles = strFavFiles.Remove(strFavFiles.Length - 1);///remove last character(|)
                    returnValue = objDAM.UpdateFavouriteDocument(strFavFiles);
                    //divConfirm.Attributes.Add("style", "display:block");
                    //divError.Attributes.Add("style", "display:none");
                    //confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    //errorMsg.InnerHtml = "";
                    BindFavorite(LibId,UserId);
                }
                else
                {
                    //divConfirm.Attributes.Add("style", "display:none");
                    //divError.Attributes.Add("style", "display:block");
                    //confirmMsg.InnerHtml = "";
                    //errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
                if (gdvFavorite.Rows.Count > 0)
                    gdvFavorite.HeaderRow.TableSection = TableRowSection.TableHeader;
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)gdvFavorite.HeaderRow.FindControl("chkboxSelectAll");
            foreach (GridViewRow row in gdvFavorite.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            if (gdvFavorite.Rows.Count > 0)
                gdvFavorite.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void gdvFavorite_RowCreated(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[3].Visible = false; // hides the first column
            e.Row.Cells[4].Visible = false;
            //e.Row.Cells[3].CssClass = "label";

            GridViewRow row = e.Row;
            // Intitialize TableCell list
            List<TableCell> columns = new List<TableCell>();
            foreach (DataControlField column in gdvFavorite.Columns)
            {
                //Get the first Cell /Column
                TableCell cell = row.Cells[2];
                // Then Remove it after
                row.Cells.Remove(cell);
                //And Add it to the List Collections
                columns.Add(cell);
            }

            // Add cells
            row.Cells.AddRange(columns.ToArray());
        }

        protected void gdvFavorite_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {               
                if (e.CommandName == "_View")
                {
                    String encURL = String.Empty;
                    Int32 DocId = Convert.ToInt32(e.CommandArgument);
                    encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, DocId));
                    Response.Redirect(encURL, false);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
    }
}