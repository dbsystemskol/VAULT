﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class EventInTemplate
    {
        protected static ILog log = LogManager.GetLogger(typeof(EventInTemplate));

        public Int32 InsertEventInTemplate(Int32 EventId,Int32 TemplateId,Int32 LibId, Int32 CreatedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventInTemplateInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventId", SqlDbType.Int, DataParameterDirection.Input, 4, EventId);
            mCmd.AddParameter("@TemplateId", SqlDbType.Int, DataParameterDirection.Input, 4, TemplateId);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, CreatedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<EventInTemplateInfo> GetAllActiveEventInTemplate()
        {
            List<EventInTemplateInfo> mList = new List<EventInTemplateInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventInTemplateSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventInTemplateInfo
                        {
                            EventInTemplateId = mCmd.GetFieldValue<Int32>("EventInTemplateId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            TemplateName = mCmd.GetFieldValue<String>("TemplateName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventInTemplateInfo> GetAllEventInTemplate()
        {
            List<EventInTemplateInfo> mList = new List<EventInTemplateInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventInTemplateSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventInTemplateInfo
                        {
                            EventInTemplateId = mCmd.GetFieldValue<Int32>("EventInTemplateId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            TemplateName = mCmd.GetFieldValue<String>("TemplateName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventInTemplateInfo> GetEventInTemplateSearch(Int32 LibId,String SearchString)
        {
            List<EventInTemplateInfo> mList = new List<EventInTemplateInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventInTemplateSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventInTemplateInfo
                        {
                            EventInTemplateId = mCmd.GetFieldValue<Int32>("EventInTemplateId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            TemplateId = mCmd.GetFieldValue<Int32>("TemplateId"),
                            TemplateName = mCmd.GetFieldValue<String>("TemplateName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateEventInTemplate(Int32 EventInTemplateId, Boolean IsActive, Int32 ModifiedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventInTemplateActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventInTemplateId", SqlDbType.Int, DataParameterDirection.Input, 4, EventInTemplateId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
