﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace DAMServices.Crypto
{
    internal class EncryptMD5
    {
        public static String GetHash(String clearText)
        {
            String _HashValue = String.Empty;
            try
            {
                byte[] bBuffer = UnicodeEncoding.Unicode.GetBytes(clearText);
                byte[] bHashBuffer = ComputeHash(bBuffer);
                _HashValue = ConvertByteArrayToHexString(bHashBuffer);
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }

            return _HashValue;
        }

        private static byte[] ComputeHash(byte[] bBuffer)
        {
            MD5CryptoServiceProvider _Hash = null;
            try
            {
                _Hash = new MD5CryptoServiceProvider();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            byte[] _HashValue = _Hash.ComputeHash(bBuffer);
            return _HashValue;
        }

        private static String ConvertByteArrayToHexString(byte[] bHashBuffer)
        {
            if (bHashBuffer == null || bHashBuffer.Length <= 0)
                return null;

            StringBuilder _Str = new StringBuilder();
            foreach (Byte b in bHashBuffer)
            {
                _Str.Append(b.ToString("x2").ToLower());
            }

            return _Str.ToString();
        }
    }
}
