﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class UserBrandCategoryMapping
    {
        protected static ILog log = LogManager.GetLogger(typeof(UserBrandCategoryMapping));

        public List<UserBrandCategoryMappingInfo> GetUserForBrandCategoryMapping()
        {
            List<UserBrandCategoryMappingInfo> mList = new List<UserBrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserForBrandCategoryMapping";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserBrandCategoryMappingInfo
                        {

                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserBrandCategoryMappingInfo> GetUserBrandCategoryMappingByUserId(Int32 UserId)
        {
            List<UserBrandCategoryMappingInfo> mList = new List<UserBrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserBrandCategoryMappingByUserId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserBrandCategoryMappingInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            Brand = mCmd.GetFieldValue<String>("Brand"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            Category = mCmd.GetFieldValue<String>("Category"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateUserBrandCategoryMapping(UserBrandCategoryMappingInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserBrandCategoryMappingActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserBrandCategoryMappingId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserBrandCategoryMappingId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public void InsertUserBrandCategoryMapping(List<UserBrandCategoryMappingInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@BrandId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.BrandId);
                    mCmd.AddParameter("@CategoryId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CategoryId);
                    mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.UserId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.CommandText = "UserBrandCategoryMappingInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<UserBrandCategoryMappingInfo> GetAllUserBrandCategoryMapping()
        {
            List<UserBrandCategoryMappingInfo> mList = new List<UserBrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserBrandCategoryMappingSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserBrandCategoryMappingInfo
                        {
                            UserBrandCategoryMappingId = mCmd.GetFieldValue<Int32>("UserBrandCategoryMappingId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            Brand = mCmd.GetFieldValue<String>("Brand"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            Category = mCmd.GetFieldValue<String>("Category"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserBrandCategoryMappingInfo> UserBrandCategoryMappingSearch(String SearchString)
        {
            List<UserBrandCategoryMappingInfo> mList = new List<UserBrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserBrandCategoryMappingSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserBrandCategoryMappingInfo
                        {
                            UserBrandCategoryMappingId = mCmd.GetFieldValue<Int32>("UserBrandCategoryMappingId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            Brand = mCmd.GetFieldValue<String>("Brand"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            Category = mCmd.GetFieldValue<String>("Category"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
