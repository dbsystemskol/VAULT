﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class TeamInLibrary
    {
        protected static ILog log = LogManager.GetLogger(typeof(UserInTeamData));

        public void InsertTeamInLibraryMaster(List<TeamInLibraryInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.LibId);
                    mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.TeamId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.IPAddress);
                    mCmd.CommandText = "TeamInLibraryInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<TeamInLibraryInfo> GetAllActiveTeamInLibrary()
        {
            List<TeamInLibraryInfo> mList = new List<TeamInLibraryInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInLibrarySelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInLibraryInfo
                        {
                            TeamInLibraryId = mCmd.GetFieldValue<Int32>("TeamInLibraryId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamInLibraryInfo> GetAllTeamInLibrary()
        {
            List<TeamInLibraryInfo> mList = new List<TeamInLibraryInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInLibrarySelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInLibraryInfo
                        {
                            TeamInLibraryId = mCmd.GetFieldValue<Int32>("TeamInLibraryId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamInLibraryInfo> GetTeamInLibrarySearch(String SearchString)
        {
            List<TeamInLibraryInfo> mList = new List<TeamInLibraryInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInLibrarySearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInLibraryInfo
                        {
                            TeamInLibraryId = mCmd.GetFieldValue<Int32>("TeamInLibraryId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateTeamInLibrary(TeamInLibraryInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "TeamInLibraryActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TeamInLibraryId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.TeamInLibraryId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
