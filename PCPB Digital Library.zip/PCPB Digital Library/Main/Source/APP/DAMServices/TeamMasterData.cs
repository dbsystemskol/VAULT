﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class TeamMasterData
    {
        protected static ILog log = LogManager.GetLogger(typeof(TeamMasterData));

        public List<TeamMasterInfo> GetAllTeamMaster()
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamMasterInfo> GetTeamMasterById(Int32 TeamId)
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamMasterInfo> GetTeamMasterByUserId(Int32 UserId)
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterByUserId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertTeamMaster(TeamMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "TeamMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TeamName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.TeamName);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateTeamMaster(TeamMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "TeamMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.TeamId);
            mCmd.AddParameter("@TeamName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.TeamName);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<TeamMasterInfo> GetAllActiveTeamMaster()
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamMasterInfo> GetAllTeamNotInLibraryByLibId(Int32 LibId)
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterNotInLibraryByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateTeamMaster(TeamMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "TeamMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.TeamId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<TeamMasterInfo> SearchTeam(String SearchText)
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamName", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
