﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class UserInTeamData
    {
        protected static ILog log = LogManager.GetLogger(typeof(UserInTeamData));

        public List<UserInTeamInfo> GetTeamMasterUserListByTeamId(Int32 TeamId)
        {
            List<UserInTeamInfo> mList = new List<UserInTeamInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterUserList";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInTeamInfo
                        {
                            UserInTeamId = mCmd.GetFieldValue<Int32>("UserInTeamId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            //InTeam = mCmd.GetFieldValue<Boolean>("InTeam"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserInTeamInfo> GetUserListNotInParticularTeam(Int32 TeamId)
        {
            List<UserInTeamInfo> mList = new List<UserInTeamInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserListNotInParticularTeam";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInTeamInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void InsertUserInTeamMaster(List<UserInTeamInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@UserId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.UserId);
                    mCmd.AddParameter("@TeamId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.TeamId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, uList.IPAddress);
                    mCmd.CommandText = "UserInTeamInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public Int32 ActivateDeactivateUserInTeamMaster(UserInTeamInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserInTeamActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserInTeamId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserInTeamId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<UserInTeamInfo> GetAllActiveTeamMasterUserList()
        {
            List<UserInTeamInfo> mList = new List<UserInTeamInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterUserListSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInTeamInfo
                        {
                            UserInTeamId = mCmd.GetFieldValue<Int32>("UserInTeamId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            //InTeam = mCmd.GetFieldValue<Boolean>("InTeam"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserInTeamInfo> GetAllUserInTeamSearch(String SearchString)
        {
            List<UserInTeamInfo> mList = new List<UserInTeamInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserInTeamListSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInTeamInfo
                        {
                            UserInTeamId = mCmd.GetFieldValue<Int32>("UserInTeamId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            //InTeam = mCmd.GetFieldValue<Boolean>("InTeam"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
