﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class LibraryMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(LibraryMaster));

        #region View
        public List<LibraryMasterInfo> GetAllLibraryMaster()
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryMasterInfo> GetAllLibraryMasterContentType()
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterContentSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryMasterInfo> GetLibraryMasterSearch(String LibraryName)
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibraryName", SqlDbType.VarChar, DataParameterDirection.Input, 100, LibraryName);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryMasterInfo> GetLibraryMasterById(Int32 LibId)
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }


        public List<LibraryMasterInfo> GetLibraryMasterByUserId(Int32 UserId, Int32 TeamId)
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterByUserId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
        public List<LibraryMasterInfo> GetAllActiveLibraryMaster()
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryMasterInfo> GetLibraryMasterRowDetailById(Int32 LibId, Int32 ContentTypeId)
        {
            List<LibraryMasterInfo> mList = new List<LibraryMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryMasterSeletcRowDetailById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryMasterInfo
                        {
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),

                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),

                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            Description = mCmd.GetFieldValue<String>("Description"),

                            LibraryAttributeSetId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),

                            Name = mCmd.GetFieldValue<String>("Name"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateLibraryMaster(LibraryMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LibraryMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@LibraryId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LibId);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ContentTypeId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
        #endregion

        #region Insert
        public List<AttributeFieldsInfo> GetAllActiveAttributeMaster()
        {
            List<AttributeFieldsInfo> mList = new List<AttributeFieldsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new AttributeFieldsInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            FieldWidth = mCmd.GetFieldValue<Int32>("FieldWidth"),
                            FieldCategory = mCmd.GetFieldValue<String>("FieldCategory"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                            AutoPopulate = mCmd.GetFieldValue<Boolean>("AutoPopulate"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertLibraryMaster(LibraryMasterInfo lMaster, ContentTypeInfo cType, List<LibraryAttributeSetInfo> laSet)
        {
            Int32 _ReturnValue = 0;
            Int32 _SecondReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LibraryMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
            mCmd.AddParameter("@LibName", SqlDbType.VarChar, DataParameterDirection.Input, 100, lMaster.LibName);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, lMaster.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 10, lMaster.IPAddress);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                if (_ReturnValue > 0)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "ContentTypeInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, cType.Description);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, cType.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 100, cType.IPAddress);
                    mCmd.ExecuteNonQuery();
                    _SecondReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");

                    foreach (LibraryAttributeSetInfo LibAtSet in laSet)
                    {
                        mCmd = null;
                        mCmd = new DataCommand();
                        mCmd.CommandText = "LibraryAttributeSetInsert";
                        mCmd.CommandType = DataCommandType.StoredProcedure;
                        mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                        mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, LibAtSet.FieldId);
                        mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, _SecondReturnValue);
                        mCmd.AddParameter("@AttributeType", SqlDbType.VarChar, DataParameterDirection.Input, 100, LibAtSet.AttributeType);
                        mCmd.AddParameter("@IsMandatory", SqlDbType.Bit, DataParameterDirection.Input, 1, LibAtSet.IsMandatory);
                        mCmd.AddParameter("@ColumnOrder", SqlDbType.Int, DataParameterDirection.Input, 4, LibAtSet.ColumnOrder);
                        mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, LibAtSet.CreatedBy);
                        mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 100, LibAtSet.IPAddress);
                        mCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
        #endregion
    }
}
