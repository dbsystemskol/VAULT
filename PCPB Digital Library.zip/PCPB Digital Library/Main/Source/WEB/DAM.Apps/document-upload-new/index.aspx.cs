﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.IO;
using System.Drawing.Imaging;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration;

namespace DAM.Apps.document_upload_new
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);                

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                if (string.IsNullOrEmpty(Session["Result"] as string))
                {
                    Session.Remove("Result");
                }
                //btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                PopulateContentType(LibId);
                BindNotification(TeamId, UserId, LibId);
            }
        }
        protected void imgConfirm_Click(object sender, EventArgs e)
        {
            Session["IsConfirm"] = 1;
            ddlBrand.Enabled = true;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "enableKey", "<script>enableContent();</script>", false);
        }
        protected void imgEdit_Click(object sender, EventArgs e)
        {
            Session["IsConfirm"] = 0;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "disableKey", "<script>disableContent();</script>", false);
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {

                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private void PopulateContentType(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var nxtDocNo = objDAM.GetNextSerialNoByLibId(LibId);
                lblDocSerialNo.Text = nxtDocNo[0].NextSerialNo.ToString();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var mList = UserPrivilege.Where(x => x.PrivilegeName == "Upload").ToList();
                if (mList.Count() > 0)
                {
                    ddlContentType.DataSource = mList;
                    ddlContentType.DataValueField = "ContentTypeId";
                    ddlContentType.DataTextField = "Description";
                    ddlContentType.DataBind();
                    ddlContentType.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        
        protected void FileDataList_ItemCommand(object source, DataListCommandEventArgs e)
        {
            string[] arg = new string[2];
            arg = e.CommandArgument.ToString().Split(';');
            String GuidName = arg[0];
            String FileName = arg[1];
            
            try
            {
                if (e.CommandName == "_Download")
                {
                    String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName;
                    String ext = System.IO.Path.GetExtension(filePath);
                    ext = ext.TrimStart('.');
                    DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                    var mList = objDAM.GetFileExtensionMasterByExtension(ext);
                    System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                    response.ClearContent();
                    response.Clear();
                    response.ContentType = mList[0].Description;
                    response.AddHeader("Content-Disposition", "attachment; filename=" + FileName + ";");
                    response.TransmitFile(filePath);
                    response.Flush();
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
                else if (e.CommandName == "_Delete")
                {
                    List<DAMServices.FileInfo> list = new List<DAMServices.FileInfo>();
                    foreach (DataListItem item in FileDataList.Items)
                    {
                        HiddenField hdnGuidName = (HiddenField)item.FindControl("hdnGuidName");
                        System.Web.UI.WebControls.Image imgPreview = (System.Web.UI.WebControls.Image)item.FindControl("imgPreview");
                        HiddenField hdnFileExtension = (HiddenField)item.FindControl("hdnFileExtension");
                        HiddenField hdnFileSize = (HiddenField)item.FindControl("hdnFileSize");
                        Label fileName = (Label)item.FindControl("lblFileName");
                        list.Add(new DAMServices.FileInfo
                        {
                            FileName = fileName.Text,
                            GuidName = hdnGuidName.Value,
                            FileExtension = hdnFileExtension.Value,
                            FileSize = Convert.ToInt64(hdnFileSize.Value),
                            ImgUrl = imgPreview.ImageUrl,
                        });
                        //hdnIsFileUploaded.Value = "True";
                    }
                    String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
                    String path2 = String.Empty;
                    path2 = path1 + GuidName;

                    if (File.Exists(path2))
                    {
                        File.Delete(path2);

                        list.RemoveAll(x => x.GuidName == GuidName);
                        if (list.Count > 0)
                            hdnIsFileUploaded.Value = "True";
                        else
                            hdnIsFileUploaded.Value = "False";
                        FileDataList.DataSource = list;
                        FileDataList.DataBind();
                    }              
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);

            }
            finally
            {

            }
        }
        
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";

            Int64 flen = fileUpload.PostedFile.ContentLength;
            string FileName = fileUpload.FileName;
            string path = System.IO.Path.GetFullPath(fileUpload.PostedFile.FileName);
            String fext = CheckMimeType.getMimeFromFile(fileUpload.PostedFile);
            String ext = System.IO.Path.GetExtension(fileUpload.PostedFile.FileName);

            if (!CheckMimeType.IsValidExtension(ext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_INVALID;
                return;
            }
            if (!CheckMimeType.CheckExe(fext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_CORRUPT;
                return;
            }
            if (flen <= Convert.ToInt64(ConfigurationManager.AppSettings["MaxFileSize"]))
            {
                String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
                String path2 = String.Empty;
                String UniqueFileName = Guid.NewGuid().ToString() + ext;
                path2 = path1 + UniqueFileName;
                if (path2.Length < 260)
                {
                    try
                    {
                        fileUpload.SaveAs(path2);
                        List<DAMServices.FileInfo> list = new List<DAMServices.FileInfo>();
                        //hdnIsFileUploaded.Value = "False";
                        foreach (DataListItem item in FileDataList.Items)
                        {
                            HiddenField hdnGuidName = (HiddenField)item.FindControl("hdnGuidName");
                            System.Web.UI.WebControls.Image imgPreview = (System.Web.UI.WebControls.Image)item.FindControl("imgPreview");
                            HiddenField hdnFileExtension = (HiddenField)item.FindControl("hdnFileExtension");
                            HiddenField hdnFileSize = (HiddenField)item.FindControl("hdnFileSize");
                            Label fileName = (Label)item.FindControl("lblFileName");
                            list.Add(new DAMServices.FileInfo
                            {
                                FileName = fileName.Text,
                                GuidName = hdnGuidName.Value,
                                FileExtension = hdnFileExtension.Value,
                                FileSize = Convert.ToInt64(hdnFileSize.Value),
                                ImgUrl = imgPreview.ImageUrl,
                            });
                            //hdnIsFileUploaded.Value = "True";
                        }
                        string imgUrl = GetImgUrl(ext, UniqueFileName);
                        list.Add(new DAMServices.FileInfo
                        {
                            FileName = FileName,
                            GuidName = UniqueFileName,
                            FileExtension = ext,
                            FileSize = flen,
                            ImgUrl = imgUrl,
                        });
                        if(list.Count>0)
                            hdnIsFileUploaded.Value = "True";
                        else
                            hdnIsFileUploaded.Value = "False";
                        FileDataList.DataSource = list;
                        FileDataList.DataBind();
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex.Message);
                    }
                }
                else
                {
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_UPLOAD_FAILURE;
                    return;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_SIZE_FAILURE;
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideKey", "<script>HideProgress();</script>", false);
        }
        private string GetImgUrl(String Extension, String GuidName)
        {
            string imgUrl = "";
            switch (Extension.ToLower())
            {
                case ".png":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpg":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpeg":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                default:
                    DAMServices.ServiceContractClient objDAM;
                    objDAM = new DAMServices.ServiceContractClient();
                    var mlist = objDAM.GetFileExtensionMasterByExtension(Extension.Trim('.'));
                    if (mlist[0].PreviewImage != "")
                        imgUrl = "../img/file-icons/" + mlist[0].PreviewImage;
                    else
                        imgUrl = "../img/file-icons/noImageAvailable.jpg";
                    break;
            }
            return imgUrl;
        }
        private void BindFilePreview(String Extension, String GuidName)
        {
            switch (Extension.ToLower())
            {
                case ".png":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpg":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpeg":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                default:
                    //DAMServices.ServiceContractClient objDAM;
                    //objDAM = new DAMServices.ServiceContractClient();
                    //var mlist = objDAM.GetFileExtensionMasterByExtension(Extension.Trim('.'));
                    //if (mlist[0].PreviewImage != "")
                    //    imgFilePreview.ImageUrl = "../img/file-icons/" + mlist[0].PreviewImage;
                    //else
                    //    imgFilePreview.ImageUrl = "../img/file-icons/noImageAvailable.jpg";
                    break;
            }
        }
        private string GenerateThumbnails(String path)
        {
            string imgUrl = "";
            System.Drawing.Image image = System.Drawing.Image.FromFile(path);
            using (System.Drawing.Image thumbnail = image.GetThumbnailImage(100, 100, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    thumbnail.Save(memoryStream, ImageFormat.Png);
                    Byte[] bytes = new Byte[memoryStream.Length];
                    memoryStream.Position = 0;
                    memoryStream.Read(bytes, 0, (int)bytes.Length);
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imgUrl = "data:image/png;base64," + base64String;
                }
            }
            return imgUrl;
        }
        public bool ThumbnailCallback()
        {
            return false;
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            BindControls();
        }
        private void BindControls()
        {
            if (ddlContentType.SelectedIndex > 0)
            {
                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(ddlContentType.SelectedValue));
                    //var mBrand = objDAM.GetUserBrandCategoryByFieldId(1, UserId);
                    var mBrand = objDAM.GetLookupMasterByFieldId(1,1).Where(x => x.IsActive == true).ToList();
                    if (mBrand.Count() > 0 && ddlBrand.Items.Count == 0)
                    {
                        ddlBrand.DataSource = mBrand;
                        ddlBrand.DataValueField = "LookupId";
                        ddlBrand.DataTextField = "FieldValue";
                        ddlBrand.DataBind();
                        ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", "0"));
                    }
                    var mList = list.Where(x => x.IsActive == true);
                    var commonList = mList.Where(x => x.AttributeType != "MetaData").ToList();
                    var metadataList = mList.Where(x => x.AttributeType == "MetaData").ToList();
                    if (commonList.Count() > 0)
                    {
                        for (int i = 0; i < commonList.Count(); i++)
                        {
                            generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, commonList[i].IsMandatory, i % 2, commonList[i].DefaultValue, true);
                        }
                    }
                    if (metadataList.Count() > 0)
                    {
                        for (int i = 0; i < metadataList.Count(); i++)
                        {
                            generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList[i].FieldType, metadataList[i].IsMandatory, i % 2, metadataList[i].DefaultValue, false);
                        }
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
                if (Session["IsConfirm"] != null)
                {
                    if (Session["IsConfirm"].ToString() == "0")
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "showConfirmKey", "<script>showConfirmButton();</script>", false);
                    else
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "enableKey", "<script>enableContent();</script>", false);
                }
                else
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "showConfirmKey", "<script>showConfirmButton();</script>", false);
            }
            else
            {
                ddlBrand.Enabled = false;
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideConfirmKey", "<script>hideConfirmButton();</script>", false);
            }
        }
        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvCategory.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvCategory.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            gdvCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void ddlContentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //BindControls();
        }
        protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetCategoryByBrandId(Convert.ToInt32(ddlBrand.SelectedValue));
                gdvCategory.DataSource = list;
                gdvCategory.DataBind();
                gdvCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        public void generateDynamicControls(String AttributeType, Int32 FieldId, String FieldName, String FieldType, Boolean IsRequired, int bgCss, String DefaultValue,Boolean IsCommon)
        {
            ViewState["control"] = FieldName + FieldId;
            switch (FieldType.ToLower())
            {
                case "texttype":
                    createDynamicTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
                    break;
                case "listtype":
                    createDynamicDropDownList(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue,IsCommon);
                    break;
                case "datetimetype":
                    createDynamicDateTime(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
                    break;
                case "textareatype":
                    createDynamicTextArea(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
                    break;
                case "numerictype":
                    createDynamicNumericTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
                    break;
                default:
                    break;
            }
        }
        public void createDynamicTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = DefaultValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }
        public void createDynamicDropDownList(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue,Boolean IsCommon)
        {
            if (FieldId > 2)
            {
                HtmlGenericControl tr = new HtmlGenericControl("tr");
                HtmlGenericControl td1 = new HtmlGenericControl("td");
                if (bgCss == 0)
                    tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
                else
                    tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
                Label lbl = new Label();
                lbl.ID = "lbl" + FieldId.ToString();
                lbl.Text = FieldName;

                td1.Controls.Add(lbl);
                tr.Controls.Add(td1);

                if (IsRequired)
                {
                    Label lbl1 = new Label();
                    lbl1.ID = "lbl" + FieldName;
                    lbl1.Text = "   *";
                    lbl1.ForeColor = System.Drawing.Color.Red;
                    td1.Controls.Add(lbl1);
                    tr.Controls.Add(td1);
                }

                HtmlGenericControl td2 = new HtmlGenericControl("td");
                DropDownList ddl = new DropDownList();
                ddl.ID = "ddl" + FieldId.ToString();
                ddl.Width = 265;
                ddl.Attributes.Add("disabled", "");
                ddl.CssClass = "my-class";

                TextBox txt = new TextBox();
                txt.ID = "txt" + FieldId.ToString();
                txt.Width = 265;
                txt.Attributes.Add("disabled", "");
                txt.CssClass = "my-class";
                txt.Style.Add("display", "none");

                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    var list = objDAM.GetLookupMasterByFieldId(FieldId, LibId).Where(x => x.IsActive == true).ToList();
                    if (FieldId == 1 || FieldId == 2)
                    {
                        var mList = objDAM.GetUserBrandCategoryByFieldId(FieldId, UserId).ToList();
                        //var mList = userBrandCategory.Intersect(list).ToList();
                        //var mList = list.Where(x => x.IsActive == true);
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }
                    else
                    {
                        var mList = list.Where(x => x.IsActive == true);
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }

                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }


                if (ddl.Items.FindByText(DefaultValue) != null)
                    ddl.Items.FindByText(DefaultValue).Selected = true;
                if (FieldName == "Confidential")
                {
                    Label lblLegand = new Label();
                    lblLegand.ID = "lblLagand";
                    lblLegand.Text = "* If confidential, only Team A will be able to view the file.";
                    lblLegand.Attributes.Add("style", "width:320px;display: inline-block;margin-left: 10px;margin-top: 5px;");
                    td2.Controls.Add(lblLegand);
                }
                td2.Controls.Add(ddl);
                td2.Controls.Add(txt);
                tr.Controls.Add(td2);
                if (FieldName == "Confidential")
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var UploadPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Upload" && x.ContentTypeId == Convert.ToInt32(ddlContentType.SelectedValue)).ToList();
                    switch (GetSelfPrivilege(UploadPrivilege[0].Permission))
                    {
                        case 0:
                        case 1:
                            tr.Attributes.Add("style", "display: none");
                            break;
                        case 2:
                            ddl.Items.Remove(ddl.Items.FindByText("No"));
                            break;
                        case 3:
                            ddl.Items.Insert(0, new ListItem("--Select--", "0"));
                            break;
                    }
                }
                else
                    ddl.Items.Insert(0, new ListItem("--Select--", "0"));
                if (IsCommon)
                {
                    //ddl.SelectedIndexChanged += new EventHandler(ddl_SelectedIndexChanged);
                    //ddl.AutoPostBack = true;
                    string functionname = "showCreativeAgency('" + ddl.ID + "','" + txt.ID + "')";
                    ddl.Attributes.Add("onchange", functionname);
                }
                else
                {
                    string functionname = "showCreativeAgency('" + ddl.ID + "','" + txt.ID + "')";
                    ddl.Attributes.Add("onchange", functionname);
                }
                tr.EnableViewState = true;
                tr.ViewStateMode = ViewStateMode.Enabled;
                if (AttributeType == "MetaData")
                    plcHldMetadata.Controls.Add(tr);
                else
                    plcHldCommon.Controls.Add(tr);
            }
        }
        void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            string value = ((DropDownList)sender).SelectedItem.Text;
            string ddlId = ((DropDownList)sender).ID;
            if (value == "Others")
            {
                TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + ddlId.Remove(0,3));
                txt.Style.Clear();
                //txt.Visible = true;
            }
            else
            {
                TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + ddlId.Remove(0, 3));
                txt.Style.Add("display", "none");
                //txt.Visible = false;
            }
        }
        private int GetSelfPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 3:
                    privilegeValue = 1;
                    break;
                case 8:
                case 12:
                    privilegeValue = 2;
                    break;
                case 10:
                case 11:
                case 14:
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        public void createDynamicDateTime(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.CssClass = "date";
            txtBox.Attributes.Add("style", "background-image: url('../img/nav-icons/calender.png');background-position: right center;background-repeat: no-repeat");
            txtBox.Attributes.Add("disabled", "");
            if (FieldName == "Expiry Date")
                txtBox.Text = DateTime.Now.AddDays(Convert.ToDouble(DefaultValue)).ToString("dd-MM-yyyy");
            else
                txtBox.Text = DefaultValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }
        public void createDynamicTextArea(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.TextMode = TextBoxMode.MultiLine;
            txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = DefaultValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }
        public void createDynamicNumericTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.Attributes.Add("onkeypress", "return allowOnlyNumber(event);");
            txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = DefaultValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Int32 returnValue = 0;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            String encURL = String.Empty;
            StringBuilder strWhereClause = new StringBuilder();
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FileInfo mFileMaster;
            DAMServices.FileVersionInfo mFileVersion;
            DAMServices.DocomentMasterInfo mDocMaster;
            DAMServices.FreeTextSearchFiles dt;
            Email objEmail;
            DataTable linkedFiles;
            try
            {
                if (Convert.ToBoolean(hdnIsFileUploaded.Value))
                {
                    if (Convert.ToInt32(ddlContentType.SelectedValue) > 0)
                    {
                        objDAM = new DAMServices.ServiceContractClient();
                        mFileMaster = new DAMServices.FileInfo();
                        mFileVersion = new DAMServices.FileVersionInfo();
                        mDocMaster = new DAMServices.DocomentMasterInfo();
                        dt = new DAMServices.FreeTextSearchFiles();
                        objEmail = new Email();
                        linkedFiles = new DataTable();
                        String strDocDetails = String.Empty;
                        String strFileLinks = String.Empty;
                        String strFileInfo = String.Empty;

                        foreach (DataListItem item in FileDataList.Items)
                        {
                            HiddenField hdnGuidName = (HiddenField)item.FindControl("hdnGuidName");
                            HiddenField hdnFileSize = (HiddenField)item.FindControl("hdnFileSize");
                            HiddenField hdnFileExtension = (HiddenField)item.FindControl("hdnFileExtension");
                            Label fileName = (Label)item.FindControl("lblFileName");

                            strFileInfo += ddlContentType.SelectedValue + "," + fileName.Text + "," + hdnGuidName.Value + "," + hdnFileExtension.Value + "," + hdnFileSize.Value + "," + UserId + "|";
                        }
                        if (strFileInfo != "")
                            strFileInfo = strFileInfo.Remove(strFileInfo.Length - 1);///remove last character(|)
                                                                                     ///
                        mFileVersion.VersionNo = 1;
                        mFileVersion.DefaultFlag = true;
                        mFileVersion.FileSize = 0;
                        mFileVersion.CreatedBy = UserId;

                        mDocMaster.ContentTypeId = Convert.ToInt32(ddlContentType.SelectedValue);
                        mDocMaster.Keywords = txtKeywords.Value;
                        mDocMaster.CreatedBy = UserId;

                        if (Convert.ToInt32(ddlBrand.SelectedValue) < 1)
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = "Brand is required.";
                            return;
                        }
                        if (gdvCategory.Rows.Count == 0)
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = "No category is mapped to selected brand.";
                            return;
                        }
                        Boolean isCategorySelected = false;
                        for (int i = 0; i < gdvCategory.Rows.Count; i++)
                        {
                            CheckBox chkAdd = (CheckBox)gdvCategory.Rows[i].FindControl("chkAdd");
                            if (chkAdd.Checked)
                            {
                                isCategorySelected = true;
                                break;
                            }
                        }
                        if (!isCategorySelected)
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = "Select atleast one category.";
                            return;
                        }
                        var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(ddlContentType.SelectedValue));
                        var mList = list.Where(x => x.IsActive = true).ToList();
                        for (int i = 0; i < mList.Count(); i++)
                        {
                            if (mList[i].AttributeType == "MetaData") //find in metadata tab
                            {
                                switch (mList[i].FieldType.ToLower())
                                {
                                    case "datetimetype":
                                    case "texttype":
                                    case "textareatype":
                                    case "numerictype":
                                        TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());                                        
                                        if (txt.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
                                        {
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                            return;
                                        }
                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txt.Text + "," + UserId + "|";
                                        break;
                                    case "listtype":
                                        DropDownList ddl = (DropDownList)plcHldMetadata.FindControl("ddl" + mList[i].FieldId.ToString());
                                        TextBox txtOther = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                        if (Convert.ToInt32(ddl.SelectedValue) == 0 && mList[i].IsMandatory == true)
                                        {
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                            return;
                                        }
                                        else if (ddl.SelectedItem.Text == "Others" && mList[i].IsMandatory == true && txtOther.Text.Trim() == "")
                                        {
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                            return;
                                        }
                                        else if (ddl.SelectedItem.Text == "Others")
                                        {
                                            strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + txtOther.Text + "," + UserId + "|";
                                        }
                                        else if (Convert.ToInt32(ddl.SelectedValue) == 0)
                                            strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + "" + "," + UserId + "|";
                                        else
                                            strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + ddl.SelectedItem.Text + "," + UserId + "|";
                                        break;
                                }
                            }
                            else                                    //find in uploads tab
                            {
                                switch (mList[i].FieldType.ToLower())
                                {
                                    case "texttype":
                                    case "textareatype":
                                    case "numerictype":
                                        TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                        if (txt.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
                                        {
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                            return;
                                        }
                                        
                                        Label lbl = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, txt.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, txt.Text);
                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txt.Text + "," + UserId + "|";
                                        break;
                                    case "datetimetype":
                                        TextBox txtExpiryDate = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                        if (txtExpiryDate.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
                                        {
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                            return;
                                        }
                                        Label lbld = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbld.Text, txtExpiryDate.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbld.Text, txtExpiryDate.Text);
                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txtExpiryDate.Text + "," + UserId + "|";
                                        break;
                                    case "listtype":
                                        if (mList[i].FieldId == 1 || mList[i].FieldId == 2)
                                        {
                                        }
                                        else
                                        {
                                            DropDownList ddl = (DropDownList)plcHldCommon.FindControl("ddl" + mList[i].FieldId.ToString());
                                            TextBox txtOther = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                            if (Convert.ToInt32(ddl.SelectedValue) == 0 && mList[i].IsMandatory == true)
                                            {
                                                divConfirm.Attributes.Add("style", "display:none");
                                                divError.Attributes.Add("style", "display:block");
                                                confirmMsg.InnerHtml = "";
                                                errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                                return;
                                            }
                                            else if (ddl.SelectedItem.Text == "Others" && mList[i].IsMandatory == true && txtOther.Text.Trim() == "")
                                            {
                                                divConfirm.Attributes.Add("style", "display:none");
                                                divError.Attributes.Add("style", "display:block");
                                                confirmMsg.InnerHtml = "";
                                                errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                                return;
                                            }
                                            else if (ddl.SelectedItem.Text == "Others")
                                            {
                                                strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + txtOther.Text + "," + UserId + "|";
                                            }
                                            else if (Convert.ToInt32(ddl.SelectedValue) == 0)
                                                strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + "" + "," + UserId + "|";
                                            else
                                                strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + ddl.SelectedItem.Text + "," + UserId + "|";
                                            Label lbllist = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            if (lbllist.Text != "Confidential")
                                            {
                                                if (strWhereClause.Length == 0)
                                                    strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbllist.Text, ddl.SelectedItem);
                                                else
                                                    strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbllist.Text, ddl.SelectedItem);
                                            }
                                        }
                                        break;
                                }
                            }
                        }
                        //for brand
                        strDocDetails += 1 + "," + ddlBrand.SelectedValue + "," + ddlBrand.SelectedItem.Text + "," + UserId + "|";
                        //for category
                        String strCategory = String.Empty;
                        for (int i = 0; i < gdvCategory.Rows.Count; i++)
                        {
                            CheckBox chkAdd = (CheckBox)gdvCategory.Rows[i].FindControl("chkAdd");
                            Label lblCategory = (Label)gdvCategory.Rows[i].FindControl("lblCategory");
                            HiddenField hdnCategoryId = (HiddenField)gdvCategory.Rows[i].FindControl("hdnCategoryId");
                            if (chkAdd.Checked)
                            {
                                strCategory += hdnCategoryId.Value + "," + lblCategory.Text  + "," + UserId + "|";
                            }
                        }
                        if (strCategory != "")
                            strCategory = strCategory.Remove(strCategory.Length - 1);///remove last character(|)
                        if (strCategory.Length > 0)
                        {
                            String[] strCategoryArray = strCategory.Split('|');
                            String[] category = strCategoryArray[0].Split(',');
                            strDocDetails += 2 + "," + category[0] + "," + category[1] + "," + UserId + "|";                            
                        }


                        if (strDocDetails != "")
                            strDocDetails = strDocDetails.Remove(strDocDetails.Length - 1);///remove last character(|)
                        linkedFiles = (DataTable)Session["Result"];
                        if (linkedFiles != null)
                        {
                            foreach (DataRow row in linkedFiles.Rows)
                            {
                                strFileLinks += row["DocId"] + "," + UserId + "|";
                            }
                            if (strFileLinks != "")
                                strFileLinks = strFileLinks.Remove(strFileLinks.Length - 1);///remove last character(|)
                        }

                        dt = objDAM.AdvanceSearch(strWhereClause.ToString(), "Yes", Convert.ToInt32(ddlContentType.SelectedValue), LibId, TeamId, 0,false);
                        if (dt.FreeTextSearchTable.Rows.Count > 0)
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = "Duplicate Record.";
                            return;
                        }
                        returnValue = objDAM.InsertFileMasterNew(strFileInfo, mFileVersion, mDocMaster, strDocDetails, strFileLinks,strCategory, TeamId, LibId, "New Upload", GetIPAddress());
                        if (returnValue > 0)
                        {
                            String strToEmail = String.Empty;
                            String strCCEmail = String.Empty;
                            var emails = objDAM.GetUserEmailByDocId(returnValue);
                            if (emails.Count() > 0)
                            {
                                var toEmails = emails.Where(x => x.IsAppAdmin == false).ToList();
                                if (toEmails.Count() > 0)
                                {
                                    for (int i = 0; i < toEmails.Count(); i++)
                                    {
                                        strToEmail += toEmails[i].EmailId + "|";
                                    }
                                }
                            }
                            var OthersEmail = objDAM.GetAllUserInTeamList("");
                            var appAdminUsers = OthersEmail.Where(x => x.TeamName == "Application Administrator").ToList();
                            for (int i = 0; i < appAdminUsers.Count(); i++)
                            {
                                var user = objDAM.GetUserMasterById(appAdminUsers[i].UserId);
                                strCCEmail += user[0].EmailId + "|";
                            }
                            
                            if (strToEmail != "")
                                strToEmail = strToEmail.Remove(strToEmail.Length - 1);
                            if (strCCEmail != "")
                                strCCEmail = strCCEmail.Remove(strCCEmail.Length - 1);
                            var template = objDAM.GetEventInTemplateSearch(LibId,"On Upload");
                            if (template.Count() > 0)
                            {
                                if (template[0].IsActive == true)
                                {
                                    if (strToEmail.Length > 0 && strCCEmail.Length > 0)
                                    {
                                        objEmail.SendOnUploadEmail(strToEmail, strCCEmail, template[0].TemplateId, returnValue, Session["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                                    }
                                    else if (strToEmail.Length == 0 && strCCEmail.Length > 0)
                                    {
                                        objEmail.SendOnUploadEmail(strCCEmail, "", template[0].TemplateId, returnValue, Session["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                                    }
                                }
                            }
                            var updatedList = objDAM.GetUpdatedDocumentDetailsForMail(returnValue);
                            var otherList = updatedList.Where(x => x.FieldValue == "Others" && x.NewValue != "").ToList();
                            if (otherList.Count() > 0)
                            {
                                var OthersTemplate = objDAM.GetEventInTemplateSearch(LibId, "On Others");
                                if (OthersTemplate.Count() > 0)
                                {
                                    if (OthersTemplate[0].IsActive == true)
                                    {
                                        if (strCCEmail.Length > 0)
                                            objEmail.SendOnOthersEmail(strCCEmail, "", OthersTemplate[0].TemplateId, returnValue, Session["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId,"Upload");
                                    }
                                }
                            }
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                            encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, returnValue));
                            Response.Redirect(encURL, false);
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = "Select content type";
                    }
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.NO_FILE;
                }

            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[4];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 3:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
            }
            return privilegeArray;
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            DAMServices.FreeTextSearchFiles dtC;
            DAMServices.FreeTextSearchFiles dtG;
            String html = String.Empty;
            String resulthtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                dtC = new DAMServices.FreeTextSearchFiles();
                dtG = new DAMServices.FreeTextSearchFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < searchPrivilege.Count(); i++)
                {
                    dtC = new DAMServices.FreeTextSearchFiles();
                    dtG = new DAMServices.FreeTextSearchFiles();
                    string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                    dtC = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]),false);
                    dtG = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]),false);
                    if (i == 0)
                    {
                        dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                    else
                    {
                        dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                }
                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    Session["SearchResult"] = dt;
                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
                    gdvSearchResult.DataBind();
                    if(gdvSearchResult.Rows.Count>0)
                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                    if(gdvLinkedFiles.Rows.Count>0)
                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
                else
                {
                    Session["SearchResult"] = dt;
                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
                    gdvSearchResult.DataBind();
                    if (gdvSearchResult.Rows.Count > 0)
                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                    if (gdvLinkedFiles.Rows.Count > 0)
                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void gdvSearchResult_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnLinkedDoc = (HiddenField)e.Row.FindControl("hdnLinkedDoc");
                    LinkButton btnLinkedDoc = (LinkButton)e.Row.FindControl("btnLinkedDoc");
                    btnLinkedDoc.Visible = (Convert.ToInt32(hdnLinkedDoc.Value) > 0) ? true : false;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
        protected void btnAddLinkFile_Click(object sender, EventArgs e)
        {
            DAMServices.FreeTextSearchFiles master;
            List<int> values;
            try
            {
                values = new List<int>();
                master = (DAMServices.FreeTextSearchFiles)Session["SearchResult"];
                foreach (GridViewRow r in gdvSearchResult.Rows)
                {
                    CheckBox chkSelect = (CheckBox)r.FindControl("chkSelect");
                    if (chkSelect.Checked)
                    {
                        string value = r.Cells[GetColumnIndexByName(r, "DocId")].Text;
                        values.Add(Convert.ToInt32(value));
                    }
                }
                if (values.Count() > 0)
                {
                    var matchingRows = from row in master.FreeTextSearchTable.AsEnumerable()
                                       join value in values
                                       on row.Field<int>("DocId") equals value
                                       select row;
                    DataTable tblResult = matchingRows.CopyToDataTable();
                    if (Session["Result"] == null)
                    {
                        Session["Result"] = tblResult;
                        gdvLinkedFiles.DataSource = tblResult;
                        gdvLinkedFiles.DataBind();
                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }
                    else
                    {
                        DataTable dt = (DataTable)Session["Result"];
                        dt.PrimaryKey = new[] { dt.Columns["DocId"] };
                        dt.Merge(tblResult, true);
                        gdvLinkedFiles.DataSource = dt;
                        gdvLinkedFiles.DataBind();
                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                        Session["Result"] = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                master = null;
                values = null;
            }
        }
        protected void gdvSearchResult_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "_View")
            {
                popup.Show();
                Int32 DocId = Convert.ToInt32(e.CommandArgument.ToString());
                BindLinkedFiles(DocId, LibId);
                if(gdvSearchResult.Rows.Count>0)
                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                if(gdvLinkedFiles.Rows.Count>0)
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
        }
        private void BindLinkedFiles(Int32 DocId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LinkedFile dt;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.GetLinkedFiles(DocId, LibId);
                if (dt.LinkedFileTable.Rows.Count > 0)
                {
                    html = "<table id='Table4' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.LinkedFileTable.Columns)
                    {
                        if (dcol.ColumnName == "LinkCount" || dcol.ColumnName == "GuidName" || dcol.ColumnName == "File Name" || dcol.ColumnName == "ContentTypeId")
                        { }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.LinkedFileTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.LinkedFileTable.Columns)
                        {
                            if (column.ColumnName == "LinkCount" || column.ColumnName == "GuidName" || column.ColumnName == "File Name" || column.ColumnName == "ContentTypeId")
                            { }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}' target='_blank'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divLinkedFilesView.InnerHtml = "";
                    divLinkedFilesView.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void gdvSearchResult_RowCreated(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[19].Visible = false; // hides the first column
            e.Row.Cells[20].Visible = false; // hides the 12th column
        }
        protected void gdvLinkedFiles_RowCreated(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[1].Visible = false;
            e.Row.Cells[18].Visible = false; // hides the first column
            e.Row.Cells[19].Visible = false; // hides the 12th column
            GridViewRow row = e.Row;
            // Intitialize TableCell list
            List<TableCell> columns = new List<TableCell>();
            foreach (DataControlField column in gdvLinkedFiles.Columns)
            {
                //Get the first Cell /Column
                TableCell cell = row.Cells[0];
                // Then Remove it after
                row.Cells.Remove(cell);
                //And Add it to the List Collections
                columns.Add(cell);
            }

            // Add cells
            row.Cells.AddRange(columns.ToArray());
        }
        int GetColumnIndexByName(GridViewRow row, string SearchColumnName)
        {
            int columnIndex = 0;
            foreach (DataControlFieldCell cell in row.Cells)
            {
                if (cell.ContainingField is BoundField)
                {
                    if (((BoundField)cell.ContainingField).DataField.Equals(SearchColumnName))
                    {
                        break;
                    }
                }
                columnIndex++;
            }
            return columnIndex;
        }
        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)gdvSearchResult.HeaderRow.FindControl("chkboxSelectAll");
            foreach (GridViewRow row in gdvSearchResult.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvLinkedFiles.Rows.Count > 0)
                gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void gdvLinkedFiles_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Int32 DocId = Convert.ToInt32(e.CommandArgument);
            try
            {
                DataTable dt = (DataTable)Session["Result"];
                foreach (DataRow dr in dt.Rows)
                {
                    if ((Int32)dr["DocId"] == DocId)
                        dr.Delete();
                }
                dt.AcceptChanges();
                gdvLinkedFiles.DataSource = dt;
                gdvLinkedFiles.DataBind();
                Session["Result"] = dt;
                gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {

            }
        }
        
        protected void download_Click(object sender, EventArgs e)
        {
            String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + hdnGuidName.Value;
            System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
            response.ClearContent();
            response.Clear();
            response.ContentType = ContentType;
            response.AddHeader("Content-Disposition", "attachment; filename=" + hdnFileName.Value + ";");
            response.TransmitFile(filePath);
            response.Flush();
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/dashboard/index.aspx", false);
        }
    }
}