﻿// Norwegian translation by Vegard S.
CKEDITOR.plugins.setLang('wordcount', 'no', {
    WordCount: 'Ord:',
    CharCount: 'Tegn:',
    CharCountWithHTML: 'Tegn (including HTML):',
    Paragraphs: 'Paragraphs:',
    title: 'Statistikk'
});
