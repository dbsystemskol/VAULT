﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Text;
using QueryStringEncryption;
using System.Web.Configuration;

namespace DAM.Apps.sys_admin
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {                
                BindMenu(LibId);                
                PopulateLibraryListDropDown();
                String encURL = "";
                encURL = Request.RawUrl;
                if (encURL.Contains("?"))
                {
                    encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                    if (!encURL.Equals(""))
                    {
                        encURL = DecryptQueryString(encURL);
                        String[] queryStr = encURL.Split('^');
                        String[] fieldvalue = queryStr[0].Split('=');
                        String[] fieldname = queryStr[1].Split('=');
                        HeaderFieldName.InnerText = fieldname[1];
                        hdnFieldId.Value = fieldvalue[1];
                        PopulateAttributeFieldListDropDown(Convert.ToInt32(hdnFieldId.Value));
                        PopulateLookupList(Convert.ToInt32(hdnFieldId.Value));
                    }
                }
                else
                {                    
                    PopulateAttributeFieldListDropDown(Convert.ToInt32(hdnFieldId.Value));
                    HeaderFieldName.InnerText = ddlFieldCaption.SelectedItem.Text;
                    PopulateLookupList(Convert.ToInt32(hdnFieldId.Value));
                }
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId )
                                    .Select(g => new
                                    {
                                        FieldId =  g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                sb.Append("<li><img src='../img/nav-icons/Department.png' alt='' /><a href='../department-master/index.aspx'>Manage Department</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-with-category/index.aspx'>Brand With Category</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../document-log/index.aspx'>Document Log</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
        protected void PopulateLookupList(Int32 FieldId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                if (FieldId > 0)
                {
                    var list = objDAM.GetAllActiveAttributeMasterLookupList().Where(x => x.FieldId == FieldId).ToList();
                    var mList = list.Where(x => x.LibId == 0 || x.LibId == LibId);
                    gdvLookupMaster.DataSource = mList;
                }
                else
                    gdvLookupMaster.DataSource = objDAM.GetAllActiveAttributeMasterLookupList().Where(x => x.LibId == 0 || x.LibId == LibId);
                gdvLookupMaster.DataBind();
                if (gdvLookupMaster.Rows.Count > 0)
                    gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void PopulateAttributeFieldListDropDown(Int32 FieldId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllActiveListTypeAttributeMaster();
                ddlFieldCaption.DataSource = mList;
                ddlFieldCaption.DataValueField = "FieldId";
                ddlFieldCaption.DataTextField = "FieldCaption";
                ddlFieldCaption.DataBind();
                ddlFieldCaption.SelectedValue = FieldId.ToString();
                lblValueCaption.InnerText = (mList.Count() > 0) ? ddlFieldCaption.SelectedItem + " Value:" : "Value:";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void PopulateLibraryListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibrary.DataSource = objDAM.GetAllActiveLibraryMaster().Where(x => x.LibId == LibId); ;
                ddlLibrary.DataValueField = "LibId";
                ddlLibrary.DataTextField = "LibName";
                ddlLibrary.DataBind();
                //ddlLibrary.Items.Insert(0, new ListItem("All Library", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void gdvLookupMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    ((Label)e.Row.FindControl("LookupName") as Label).Text = HeaderFieldName.InnerText;
                }
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    HiddenField hdnLibId = (HiddenField)e.Row.FindControl("hdnLibId");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                    if (Convert.ToInt32(hdnLibId.Value) == 0)
                    {
                        LinkButton btnEdit = (LinkButton)e.Row.FindControl("btnEdit");
                        Image imgEdit = (Image)e.Row.FindControl("imgEdit");
                        btnEdit.Visible = false;
                        imgEdit.Visible = false;
                        imgActive.Visible = false;
                        imgDeactive.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {

            }
        }
        protected void gdvLookupMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LookupMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.LookupMasterInfo();

                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowALookupId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);

                        mData.LookupId = RowALookupId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateLookupMaster(mData);
                        if (r > 0)
                        {
                            PopulateLookupList(Convert.ToInt32(hdnFieldId.Value));
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                    if (e.CommandName == "_Edit")
                    {
                        btnSubmit.Enabled = true;
                        Int32 RowLookupId = Convert.ToInt32(e.CommandArgument);
                        gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetLookupMasterById(RowLookupId);
                        hdnSelectLookupId.Value = mList[0].LookupId.ToString();
                        ddlFieldCaption.SelectedValue = mList[0].FieldId.ToString();
                        txtFieldCode.Value = mList[0].FieldCode;
                        txtFieldValue.Value = mList[0].FieldValue;
                        ddlLibrary.SelectedValue = mList[0].LibId.ToString();
                        //if (mList[0].LibId == 0)
                        //    btnSubmit.Enabled = false;
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }
        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                txtFieldCode.Value = "";
                txtFieldValue.Value = "";
                hdnSelectLookupId.Value = "";
                popup.Show();
                if (gdvLookupMaster.Rows.Count > 0)
                    gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.LookupMasterInfo dList;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                dList = new DAMServices.LookupMasterInfo();
                dList.LookupId = (hdnSelectLookupId.Value != "") ? Convert.ToInt32(hdnSelectLookupId.Value) : 0;
                dList.FieldId = Convert.ToInt32(ddlFieldCaption.SelectedValue);
                dList.FieldCode = Server.HtmlEncode(txtFieldCode.Value);
                dList.FieldValue = Server.HtmlEncode(txtFieldValue.Value);
                dList.LibId = Convert.ToInt32(ddlLibrary.SelectedValue);
                dList.CreatedBy = UserId;
                dList.IPAddress = GetIPAddress();
                if (dList.LookupId == 0)
                {
                    Int32 Returnval = obje.InsertLookupMaster(dList);
                    if (Returnval > 0)
                    {
                        PopulateLookupList(Convert.ToInt32(hdnFieldId.Value));
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerText = "";
                        errorMsg.InnerText = Constant.DUPLICATE;
                    }
                }
                else
                {
                    Int32 Returnval = obje.UpdateLookupMaster(dList);
                    if (Returnval > 0)
                    {
                        PopulateLookupList(Convert.ToInt32(hdnFieldId.Value));
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.DUPLICATE;
                    }
                }
                if (gdvLookupMaster.Rows.Count > 0)
                    gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }
        protected void ddlFieldCaption_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblValueCaption.InnerText = (Convert.ToInt32(ddlFieldCaption.SelectedValue) > 0) ? ddlFieldCaption.SelectedItem + " Value:" : "Value:";
            if (gdvLookupMaster.Rows.Count > 0)
                gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAttributeMasterLookupListSearch(Server.HtmlEncode(txtSearchTeam.Value)).Where(x => x.LibId == 0 || x.LibId == LibId);
                gdvLookupMaster.DataSource = mList.Where(x => x.FieldId == Convert.ToInt32(hdnFieldId.Value)).ToList();
                gdvLookupMaster.DataBind();
                if (gdvLookupMaster.Rows.Count > 0)
                    gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvLookupMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", ddlFieldCaption.SelectedItem.Text + ".xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvLookupMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvLookupMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvLookupMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvLookupMaster.HeaderRow.Cells.Count; i++)
                        gdvLookupMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvLookupMaster.Columns.Count; i++)
                    {
                        if (gdvLookupMaster.Columns[i].HeaderText == "Active" || gdvLookupMaster.Columns[i].HeaderText == "Edit")
                            gdvLookupMaster.Columns[i].Visible = false;
                        if (gdvLookupMaster.Columns[i].HeaderText == "IsActive")
                            gdvLookupMaster.Columns[i].Visible = true;
                    }
                    gdvLookupMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                    //HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    //HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    //HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {

            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}