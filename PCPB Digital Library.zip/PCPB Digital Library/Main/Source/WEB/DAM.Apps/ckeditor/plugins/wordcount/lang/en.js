﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'en', {
    WordCount: 'Words:',
    CharCount: 'Characters:',
    CharCountWithHTML: 'Characters (including HTML):',
    Paragraphs: 'Paragraphs:',
    title: 'Statistics'
});
