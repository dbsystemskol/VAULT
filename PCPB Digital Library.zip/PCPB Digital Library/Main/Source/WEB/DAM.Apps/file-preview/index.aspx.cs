﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
using System.Data;
using QueryStringEncryption;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Web.Configuration;
using Ionic.Zip;

namespace DAM.Apps.file_preview
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {

                //btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                Session.Remove("SearchResult");
                Session.Remove("Result");
                String encURL = "";
                encURL = Request.RawUrl;
                encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                if (!encURL.Equals(""))
                {
                    encURL = DecryptQueryString(encURL);
                    String[] queryStr = encURL.Split('&');

                    String[] docid = queryStr[1].Split('=');
                    hdnDocId.Value = docid[1].ToString();

                    BindFavorite(Convert.ToInt32(hdnDocId.Value), UserId);
                    BindFilePreviewSection(Convert.ToInt32(hdnDocId.Value));
                    BindFileVersionDropdown(Convert.ToInt32(hdnDocId.Value));
                    BindLinkedFiles(Convert.ToInt32(hdnDocId.Value), LibId);
                    BindFileDocumentDetails(Convert.ToInt32(hdnDocId.Value));
                    BindNotification(TeamId, UserId, LibId);
                    
                }
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var EditPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Edit" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                if (EditPrivilege[0].Permission == 0)
                {
                    btnEditMetadata.Attributes.Add("style", "display:none");
                    editInfo.Attributes.Add("style", "display:none");
                    btnEditLinkFiles.Attributes.Add("style", "display:none");
                    btnConfirmVersion.Attributes.Add("style", "display:none");
                }
                var UploadPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Upload" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                if (UploadPrivilege[0].Permission == 0)
                {
                    btnAddVersion.Attributes.Add("style", "display:none");
                    btnAddFiles.Attributes.Add("style", "display:none");
                }
                var DownloadPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Download" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                if (DownloadPrivilege[0].Permission == 0)
                {
                    foreach (DataListItem item in FileDataList.Items)
                    {
                        LinkButton btnDownload = (LinkButton)item.FindControl("btnDownload");
                        System.Web.UI.WebControls.Image imgDownload = (System.Web.UI.WebControls.Image)item.FindControl("imgDownload");
                        btnDownload.Visible = false;
                        imgDownload.Visible = false;
                    }
                }
                var DeletePrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Delete" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                if (DeletePrivilege[0].Permission == 0)
                {
                    btnDelete.Visible = false;
                    foreach (DataListItem item in FileDataList.Items)
                    {
                        LinkButton btnDeleteLink = (LinkButton)item.FindControl("btnDelete");
                        System.Web.UI.WebControls.Image imgDelete = (System.Web.UI.WebControls.Image)item.FindControl("imgDelete");
                        btnDeleteLink.Visible = false;
                        imgDelete.Visible = false;
                    }
                }
            }
        }
        private void PopulateTreeView(DirectoryInfo dirInfo, TreeNode treeNode)
        {
            foreach (DirectoryInfo directory in dirInfo.GetDirectories())
            {
                TreeNode directoryNode = new TreeNode
                {
                    Text = directory.Name,
                    Value = directory.FullName
                };

                if (treeNode == null)
                {
                    //If Root Node, add to TreeView.
                    trvFiles.Nodes.Add(directoryNode);
                }
                else
                {
                    //If Child Node, add to Parent Node.
                    treeNode.ChildNodes.Add(directoryNode);
                }

                //Get all files in the Directory.
                foreach (FileInfo file in directory.GetFiles())
                {
                    //Add each file as Child Node.
                    String url = String.Empty;
                    url = "../download-file.aspx?" + EncryptQueryString(String.Format("fname={0}&guid={1}", file.Name, file.FullName));
                    TreeNode fileNode = new TreeNode
                    {
                        Text = file.Name,
                        Value = file.FullName,
                        Target = "_blank",
                        NavigateUrl = url,
                        SelectAction = TreeNodeSelectAction.SelectExpand,
                    };
                    directoryNode.ChildNodes.Add(fileNode);
                }

                PopulateTreeView(directory, directoryNode);
            }
        }
        private void hideShowDetail()
        {
            foreach (DataListItem li in FileDataList.Items)
            {
                HiddenField hdnFileExtension = (HiddenField)li.FindControl("hdnFileExtension");
                LinkButton btnViewFiles = (LinkButton)li.FindControl("btnViewFiles");
                if (hdnFileExtension.Value.ToLower() == ".zip")
                    btnViewFiles.Visible = true;
                else
                    btnViewFiles.Visible = false;
            }
        }
        protected void FileDataList_DataBinding(object sender, DataListItemEventArgs e)
        {
            try
            {
                if (e.Item.ItemType == ListItemType.Item)
                {
                    HiddenField hdnFileExtension = (HiddenField)e.Item.FindControl("hdnFileExtension");
                    LinkButton btnViewFiles = (LinkButton)e.Item.FindControl("btnViewFiles");
                    if (hdnFileExtension.Value.ToLower() == ".zip")
                        btnViewFiles.Visible = true;
                    else
                        btnViewFiles.Visible = false;
                    
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }        
        protected void FileDataList_ItemCommand(object source, DataListCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                if (e.CommandName == "_Download")
                {
                    string[] arg = new string[2];
                    arg = e.CommandArgument.ToString().Split('^');
                    String GuidName = arg[0];
                    String FileName = arg[1];
                    String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName;
                    String ext = System.IO.Path.GetExtension(filePath);
                    ext = ext.TrimStart('.');
                    var mList = objDAM.GetFileExtensionMasterByExtension(ext);
                    System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                    response.ClearContent();
                    response.Clear();
                    response.ContentType = mList[0].Description;
                    response.AddHeader("Content-Disposition", "attachment; filename=" + FileName + ";");
                    response.TransmitFile(filePath);
                    response.Flush();
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
                else if (e.CommandName == "_View")
                {
                    string[] arg = new string[2];
                    arg = e.CommandArgument.ToString().Split('^');
                    String GuidName = arg[0];
                    String FileName = arg[1];
                    String FolderName = arg[0];
                    int fileExtPos = FolderName.LastIndexOf(".");
                    if (fileExtPos >= 0)
                        FolderName = FolderName.Substring(0, fileExtPos);
                    String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + FolderName;
                    popupViewFiles.Show();
                    trvFiles.Nodes.Clear();
                    DirectoryInfo rootInfo = new DirectoryInfo(filePath);
                    PopulateTreeView(rootInfo, null);
                }
                else if (e.CommandName == "_Delete")
                {
                    string[] arg = new string[3];
                    arg = e.CommandArgument.ToString().Split('^');
                    String GuidName = arg[0];
                    Int32 FileInfoId = Convert.ToInt32(arg[1]);
                    String FileName = arg[2];
                    Int32 r = objDAM.DeleteFile(FileInfoId, UserId);
                    if (r > 0)
                    {
                        String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
                        String path2 = String.Empty;
                        path2 = path1 + GuidName;

                        if (File.Exists(path2))
                        {
                            File.Delete(path2);
                            Email objEmail = new Email();
                            String strToEmail = String.Empty;
                            String strCCEmail = String.Empty;
                            var emails = objDAM.GetUserEmailByDocId(Convert.ToInt32(hdnDocId.Value));
                            if (emails.Count() > 0)
                            {
                                var toEmails = emails.Where(x => x.IsAppAdmin == false).ToList();
                                if (toEmails.Count() > 0)
                                {
                                    for (int i = 0; i < toEmails.Count(); i++)
                                    {
                                        strToEmail += toEmails[i].EmailId + "|";
                                    }
                                }
                            }
                            var OthersEmail = objDAM.GetAllUserInTeamList("");
                            var appAdminUsers = OthersEmail.Where(x => x.TeamName == "Application Administrator").ToList();
                            for (int i = 0; i < appAdminUsers.Count(); i++)
                            {
                                var user = objDAM.GetUserMasterById(appAdminUsers[i].UserId);
                                strCCEmail += user[0].EmailId + "|";
                            }

                            if (strToEmail != "")
                                strToEmail = strToEmail.Remove(strToEmail.Length - 1);
                            if (strCCEmail != "")
                                strCCEmail = strCCEmail.Remove(strCCEmail.Length - 1);
                            var template = objDAM.GetEventInTemplateSearch(LibId, "On File Delete");
                            if (template.Count() > 0)
                            {
                                if (template[0].IsActive == true)
                                {
                                    if (strToEmail.Length > 0 && strCCEmail.Length > 0)
                                        objEmail.SendOnDeleteFileEmail(strToEmail, strCCEmail, template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId, FileName);
                                    else if (strToEmail.Length == 0 && strCCEmail.Length > 0)
                                        objEmail.SendOnDeleteFileEmail(strCCEmail, "", template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId, FileName);
                                }
                            }
                        }
                        Response.Redirect("~/file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, hdnDocId.Value)));
                        //BindFilePreviewSection(Convert.ToInt32(hdnDocId.Value));
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);

            }
            finally
            {
                objDAM = null;
            }
        }        
        private void BindFavorite(Int32 DocId, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetFavouriteDocumentByDocId(DocId, UserId);
                if (mList.Count() > 0)
                {
                    if (mList[0].IsFavourite)
                    {
                        imgAddFav.Visible = true;
                        imgRemoveFav.Visible = false;
                    }
                    else
                    {
                        imgAddFav.Visible = false;
                        imgRemoveFav.Visible = true;
                    }
                }
                else
                {
                    imgAddFav.Visible = false;
                    imgRemoveFav.Visible = true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FileInfo mFileMaster;
            DAMServices.FileVersionInfo mFileVersion;
            DAMServices.DocumentInFileInfo mDocInFile;
            Int32 returnVal;
            
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";

            int flen = fileUpload.PostedFile.ContentLength;
            string FileName = fileUpload.FileName;
            string path = System.IO.Path.GetFullPath(fileUpload.PostedFile.FileName);
            String fext = CheckMimeType.getMimeFromFile(fileUpload.PostedFile);
            String ext = System.IO.Path.GetExtension(fileUpload.PostedFile.FileName);

            if (!CheckMimeType.IsValidExtension(ext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_INVALID;
                return;
            }
            if (!CheckMimeType.CheckExe(fext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_CORRUPT;
            }
            if (flen <= Convert.ToInt64(ConfigurationManager.AppSettings["MaxFileSize"]))
            {
                String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
                String path2 = String.Empty;
                String UniqueFileName = Guid.NewGuid().ToString() + ext;
                path2 = path1 + UniqueFileName;
                if (path2.Length < 260)
                {
                    try
                    {
                        objDAM = new DAMServices.ServiceContractClient();
                        mFileMaster = new DAMServices.FileInfo();
                        mFileVersion = new DAMServices.FileVersionInfo();
                        mDocInFile = new DAMServices.DocumentInFileInfo();

                        fileUpload.SaveAs(path2);
                        hdnFileName.Value = fileUpload.FileName;
                        lblFileName.Text = fileUpload.FileName;
                        hdnFileExtension.Value = ext;
                        hdnFileSize.Value = flen.ToString();
                        hdnGuidName.Value = UniqueFileName;

                        mFileMaster.ContentTypeId = Convert.ToInt32(hdnContentType.Value);
                        mFileMaster.FileName = hdnFileName.Value;
                        mFileMaster.GuidName = hdnGuidName.Value;
                        mFileMaster.FileExtension = hdnFileExtension.Value;
                        mFileMaster.CreatedBy = UserId;

                        mDocInFile.DocId = Convert.ToInt32(hdnDocId.Value);
                        mDocInFile.CreatedBy = UserId;

                        mFileVersion.DocId = Convert.ToInt32(hdnDocId.Value);
                        mFileVersion.VersionNo = 1;
                        mFileVersion.DefaultFlag = true;
                        mFileVersion.FileSize = Convert.ToInt32(hdnFileSize.Value);
                        mFileVersion.CreatedBy = UserId;

                        returnVal = objDAM.InsertFileVersion(mFileMaster, mDocInFile, mFileVersion);
                        if (returnVal > 0)
                        {
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                            BindFileVersionDropdown(Convert.ToInt32(hdnDocId.Value));
                            BindLinkedFiles(Convert.ToInt32(hdnDocId.Value), LibId);
                            BindFileDocumentDetails(Convert.ToInt32(hdnDocId.Value));
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideKey", "<script>HideProgress();</script>", false);
                        }
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex.Message);
                    }
                }
                else
                {
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_UPLOAD_FAILURE;
                    return;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_SIZE_FAILURE;
            }
        }
        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            Email objEmail;
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FileInfo mFileMaster;
            DAMServices.FileVersionInfo mFileVersion;
            DAMServices.DocumentInFileInfo mDocInFile;
            Int32 returnVal;

            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";

            int flen = fileUploadDoc.PostedFile.ContentLength;
            string FileName = fileUploadDoc.FileName;
            string path = System.IO.Path.GetFullPath(fileUploadDoc.PostedFile.FileName);
            String fext = CheckMimeType.getMimeFromFile(fileUploadDoc.PostedFile);
            String ext = System.IO.Path.GetExtension(fileUploadDoc.PostedFile.FileName);

            if (!CheckMimeType.IsValidExtension(ext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_INVALID;
                return;
            }
            if (!CheckMimeType.CheckExe(fext))
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_CORRUPT;
                return;
            }
            if (flen <= Convert.ToInt64(ConfigurationManager.AppSettings["MaxFileSize"]))
            {
                String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
                String path2 = String.Empty;
                String UniqueFileName = Guid.NewGuid().ToString() + ext;
                path2 = path1 + UniqueFileName;
                if (path2.Length < 260)
                {
                    try
                    {
                        objEmail = new Email();
                        objDAM = new DAMServices.ServiceContractClient();
                        mFileMaster = new DAMServices.FileInfo();
                        mFileVersion = new DAMServices.FileVersionInfo();
                        mDocInFile = new DAMServices.DocumentInFileInfo();

                        fileUploadDoc.SaveAs(path2);
                        mFileMaster.ContentTypeId = Convert.ToInt32(hdnContentType.Value);
                        mFileMaster.FileName = FileName;
                        mFileMaster.GuidName = UniqueFileName;
                        mFileMaster.FileExtension = ext;
                        mFileMaster.FileSize = flen;
                        mFileMaster.CreatedBy = UserId;

                        returnVal = objDAM.InsertFileToDocument(mFileMaster, Convert.ToInt32(hdnDocId.Value));
                        if (returnVal > 0)
                        {
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                            String strToEmail = String.Empty;
                            String strCCEmail = String.Empty;
                            var emails = objDAM.GetUserEmailByDocId(Convert.ToInt32(hdnDocId.Value));
                            if (emails.Count() > 0)
                            {
                                var toEmails = emails.Where(x => x.IsAppAdmin == false).ToList();
                                if (toEmails.Count() > 0)
                                {
                                    for (int i = 0; i < toEmails.Count(); i++)
                                    {
                                        strToEmail += toEmails[i].EmailId + "|";
                                    }
                                }
                            }
                            var OthersEmail = objDAM.GetAllUserInTeamList("");
                            var appAdminUsers = OthersEmail.Where(x => x.TeamName == "Application Administrator").ToList();
                            for (int i = 0; i < appAdminUsers.Count(); i++)
                            {
                                var user = objDAM.GetUserMasterById(appAdminUsers[i].UserId);
                                strCCEmail += user[0].EmailId + "|";
                            }

                            if (strToEmail != "")
                                strToEmail = strToEmail.Remove(strToEmail.Length - 1);
                            if (strCCEmail != "")
                                strCCEmail = strCCEmail.Remove(strCCEmail.Length - 1);
                            var template = objDAM.GetEventInTemplateSearch(LibId, "On File Upload");
                            if (template.Count() > 0)
                            {
                                if (template[0].IsActive == true)
                                {
                                    if (strToEmail.Length > 0 && strCCEmail.Length > 0)
                                        objEmail.SendOnAddFileEmail(strToEmail, strCCEmail, template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId, UniqueFileName);
                                    else if (strToEmail.Length == 0 && strCCEmail.Length > 0)
                                        objEmail.SendOnAddFileEmail(strCCEmail, "", template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId, UniqueFileName);
                                }
                            }
                            Response.Redirect("~/file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, hdnDocId.Value)));
                        }                        
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex.Message);
                    }
                }
                else
                {
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_UPLOAD_FAILURE;
                    return;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                errorMsg.InnerHtml = Constant.FILE_SIZE_FAILURE;
            }
        }        
        private double CalculateSquare(Int32 number)
        {
            return Math.Pow(number, 2);
        }
        private void BindFileVersionDropdown(Int32 DocId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetFileVersionByDocId(DocId);
                var defaultList = mList.Where(x => x.DefaultFlag == true).ToList();
                if (mList.Count() > 0)
                {
                    ddlVersion.DataSource = mList;
                    ddlVersion.DataValueField = "FileInfoId";
                    ddlVersion.DataTextField = "VersionName";
                    ddlVersion.DataBind();
                    ddlVersion.SelectedValue = defaultList[0].FileInfoId.ToString();
                    lblFileSize.Text = (defaultList[0].FileSize / CalculateSquare(1024)).ToString("0.000") + " MB";
                    //lblFileSize.Text = defaultList[0].FileSize.ToString() + " kb";
                    if (ddlVersion.SelectedItem.Text.ToLower().Contains("finalized"))
                    {
                        btnConfirmVersion.Visible = false;
                    }
                    else
                    {
                        btnConfirmVersion.Visible = true;
                    }
                    lblVersionName.Text = ddlVersion.SelectedItem.Text;
                }
                else
                {
                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void ddlVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (Convert.ToInt32(ddlVersion.SelectedValue) > 0)
            {
                lblVersionName.Text = ddlVersion.SelectedItem.Text;
                BindFilePreviewSection(Convert.ToInt32(ddlVersion.SelectedValue));
                BindLinkedFiles(Convert.ToInt32(ddlVersion.SelectedValue), LibId);
                if (ddlVersion.SelectedItem.Text.ToLower().Contains("finalized"))
                {
                    btnConfirmVersion.Visible = false;
                }
                else
                {
                    btnConfirmVersion.Visible = true;
                }
            }
        }
        protected void btnSaveCopy_Click(object sender, EventArgs e)
        {
            Int32 returnValue = 0;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            String encURL = String.Empty;
            StringBuilder strWhereClause = new StringBuilder();
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FileInfo mFileMaster;
            DAMServices.FileVersionInfo mFileVersion;
            DAMServices.DocomentMasterInfo mDocMaster;
            DAMServices.FreeTextSearchFiles dt;
            DataTable linkedFiles;
            try
            {
                if (gdvBrandCategory.Rows.Count > 0)
                {
                    foreach (GridViewRow dgrow in gdvBrandCategory.Rows)
                    {
                        HiddenField BrandId = (HiddenField)dgrow.FindControl("hdnBrandId");
                        Label lblBrand = (Label)dgrow.FindControl("lblBrand");
                        HiddenField hdnCategoryIds = (HiddenField)dgrow.FindControl("hdnCategoryIds");
                        Label lblCategory = (Label)dgrow.FindControl("lblCategory");
                        objDAM = new DAMServices.ServiceContractClient();
                        mFileMaster = new DAMServices.FileInfo();
                        mFileVersion = new DAMServices.FileVersionInfo();
                        mDocMaster = new DAMServices.DocomentMasterInfo();
                        dt = new DAMServices.FreeTextSearchFiles();
                        linkedFiles = new DataTable();
                        String strDocDetails = String.Empty;
                        String strFileLinks = String.Empty;
                        String strFileInfo = String.Empty;
                        var mList = objDAM.GetFileInfoByDocId(Convert.ToInt32(hdnDocId.Value));
                        for (int x = 0; x < mList.Count(); x++)
                        {
                            strFileInfo += hdnContentType.Value + "," + mList[x].FileName + "," + mList[x].GuidName + "," + mList[x].FileExtension + "," + mList
[x].FileSize + "," + UserId + "|";
                        }
                        if (strFileInfo != "")
                            strFileInfo = strFileInfo.Remove(strFileInfo.Length - 1);///remove last character(|)
                        ///
                        mFileVersion.VersionNo = 1;
                        mFileVersion.DefaultFlag = true;
                        mFileVersion.FileSize = 0;
                        mFileVersion.CreatedBy = UserId;

                        mDocMaster.ContentTypeId = Convert.ToInt32(hdnContentType.Value);
                        mDocMaster.Keywords = txtKeywords.Value;
                        mDocMaster.CreatedBy = UserId;

                        //for brand
                        strDocDetails += 1 + "," + BrandId.Value + "," + lblBrand.Text + "," + UserId + "|";
                        //for category
                        String[] strCategoryIdArray = hdnCategoryIds.Value.Split(',');
                        String[] strCategoryNameArray = lblCategory.Text.Split(',');
                        strDocDetails += 2 + "," + strCategoryIdArray[0] + "," + strCategoryNameArray[0].Trim() + "," + UserId + "|";

                        var docDetails = objDAM.GetFileDocumentDetailsByDocId(Convert.ToInt32(hdnDocId.Value));
                        for (int z = 1; z < docDetails.Count(); z++)
                        {
                            if (docDetails[z].FieldId == 1)
                            {
                            }
                            else if (docDetails[z].FieldId == 2)
                            {
                            }
                            else
                            {
                                strDocDetails += docDetails[z].FieldId + "," + docDetails[z].LoopupId + "," + docDetails[z].FieldValue + "," + UserId + "|";
                            }
                        }
                        String strCategory = String.Empty;
                        for (int y = 0; y < strCategoryIdArray.Length; y++)
                        {
                            strCategory += strCategoryIdArray[y] + "," + strCategoryNameArray[y] + "," + UserId + "|";
                        }
                        if (strCategory != "")
                                strCategory = strCategory.Remove(strCategory.Length - 1);


                        if (strDocDetails != "")
                            strDocDetails = strDocDetails.Remove(strDocDetails.Length - 1);///remove last character(|)
                        linkedFiles = (DataTable)Session["Result"];
                        if (linkedFiles != null)
                        {
                            foreach (DataRow row in linkedFiles.Rows)
                            {
                                strFileLinks += row["DocId"] + "," + UserId + "|";
                            }
                            if (strFileLinks != "")
                                strFileLinks = strFileLinks.Remove(strFileLinks.Length - 1);///remove last character(|)
                        }
                        returnValue = objDAM.InsertFileMasterNew(strFileInfo, mFileVersion, mDocMaster, strDocDetails, strFileLinks, strCategory, TeamId, LibId, "New Upload", GetIPAddress());
                    }
                    if (returnValue > 0)
                    {
                        encURL = "../dashboard/index.aspx";
                        Response.Redirect(encURL, false);
                    }
                }
                else
                {
                    lblcopyMsg.Text = "No brand category selected.";
                    popupCopy.Show();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnConfirmVersion_Click(object sender, EventArgs e)
        {
            Int32 returnValue;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                returnValue = objDAM.UpdateFileVersion(Convert.ToInt32(hdnDocId.Value), Convert.ToInt32(ddlVersion.SelectedValue), UserId);
                if (returnValue > 0)
                {
                    divConfirm.Attributes.Add("style", "display:block");
                    divError.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                    BindFileVersionDropdown(Convert.ToInt32(hdnDocId.Value));
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindFilePreviewSection(Int32 DocId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetFileInfoByDocId(DocId);
                var list = objDAM.GetContentTypeIdByDocId(DocId);
                hdnContentType.Value = list[0].ContentTypeId.ToString();
                hdnUploadedBy.Value = list[0].CreatedBy.ToString();
                lblUploadedBy.Text = list[0].UserName;
                lblUploadedOn.Text = list[0].CreatedOn.ToString("dd-MM-yyyy");
                lblDocSerialNo.Text = "Document No.: " + list[0].SerialNo.ToString();
                lblContentType.Text = list[0].ContentType;
                if (mList.Count() > 0)
                {                    
                    foreach (var m in mList)
                    {
                        m.ImgUrl = GetImgUrl(m.FileExtension, m.GuidName);
                    }
                    FileDataList.DataSource = null;
                    FileDataList.DataBind();
                    FileDataList.DataSource = mList;
                    FileDataList.DataBind();
                    hideShowDetail();
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "All files deleted.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }        
        private void BindFileDocumentDetails(Int32 DocId)
        {
            DAMServices.ServiceContractClient objDAM;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetFileDocumentDetailsByDocId(DocId);  //first item of the list is <keyword>
                if (mList.Count() > 0)
                {
                    lblKeywords.Text = mList[0].FieldValue;
                    txtKeywords.Value = mList[0].FieldValue;
                    html = "<table width='100%' border='0' cellspacing='2' cellpadding='0' id='searchResult' style='padding:4px;'> <tbody>";
                    for (int i = 1; i < mList.Count(); i++)
                    {
                        if (mList[i].FieldId == 1 || mList[i].FieldId == 2)
                        {
                            if (mList[i].FieldId == 1)
                                lblBrandView.Text = mList[i].FieldValue;
                            else if (mList[i].FieldId == 2)
                            {
                                var category = objDAM.GetDocumentCategoryDetailByDocId(DocId);
                                String strCategory = String.Empty;
                                if (category.Count() > 0)
                                {
                                    for (int x = 0; x < category.Count(); x++)
                                        strCategory += category[x].CategoryName + ", ";
                                    if (strCategory != "")
                                        strCategory = strCategory.Remove(strCategory.Length - 2);
                                }
                                else
                                    strCategory = mList[i].FieldValue;

                                lblCategoryView.Text = strCategory;
                            }
                        }
                        else
                        {
                            if (lblContentType.Text.ToLower() == "Market Research".ToLower() && mList[i].FieldId > 30)
                            {
                                if (mList[i].FieldValue == "Yes")
                                {
                                    html += "<tr>";
                                    html += "<td width='30%'><strong>";
                                    html += mList[i].FieldCaption;
                                    html += "</strong></td>";
                                    html += "<td>";
                                    if (mList[i].LookupValue == "Others")
                                        html += mList[i].LookupValue + " - " + mList[i].FieldValue;
                                    else
                                        html += mList[i].FieldValue;
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<tr>";
                                html += "<td width='30%'><strong>";
                                html += mList[i].FieldCaption;
                                html += "</strong></td>";
                                html += "<td>";
                                if (mList[i].LookupValue == "Others")
                                    html += mList[i].LookupValue + " - " + mList[i].FieldValue;
                                else
                                    html += mList[i].FieldValue;
                                html += "</td>";
                            }
                        }
                    }
                    html += "<tbody> </table>";
                    divDocumentDetailsView.InnerHtml = html;
                }
                else
                {
                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindLinkedFilesView(Int32 DocId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LinkedFile dt;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.GetLinkedFiles(DocId, LibId);
                if (dt.LinkedFileTable.Rows.Count > 0)
                {
                    html = "<table id='Table4' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.LinkedFileTable.Columns)
                    {
                        if (dcol.ColumnName == "GuidName" || dcol.ColumnName == "File Name" || dcol.ColumnName == "ContentTypeId")
                        { }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.LinkedFileTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.LinkedFileTable.Columns)
                        {
                            if (column.ColumnName == "GuidName" || column.ColumnName == "File Name" || column.ColumnName == "ContentTypeId")
                            { }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}' target='_blank'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    pnlLinkedFilesView.InnerHtml = "";
                    pnlLinkedFilesView.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindLinkedFiles(Int32 DocId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LinkedFile dt;
            DAMServices.LinkedFile dtUpdate;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.GetLinkedFiles(DocId, LibId);
                dtUpdate = objDAM.GetLinkedFilesForUpdate(DocId, LibId);
                if (dt.LinkedFileTable.Rows.Count > 0)
                {
                    Session["Result"] = dtUpdate.LinkedFileTable;
                    gdvLinkedFiles.DataSource = dtUpdate.LinkedFileTable;
                    gdvLinkedFiles.DataBind();
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                    html = "<table id='Table4' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.LinkedFileTable.Columns)
                    {
                        if (dcol.ColumnName == "LinkCount" || dcol.ColumnName == "DocId" || dcol.ColumnName == "File Name" || dcol.ColumnName == "ContentTypeId")
                        { }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    //html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.LinkedFileTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.LinkedFileTable.Columns)
                        {
                            if (column.ColumnName == "LinkCount" || column.ColumnName == "DocId" || column.ColumnName == "File Name" || column.ColumnName == 
"ContentTypeId")
                            { }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        //encURL = "../download-file.aspx?" + EncryptQueryString(String.Format("fname={0}&guid={1}", 0, row["GuidName"]));
                        //html += "<td>";
                        //html += String.Format("<a href='{0}' target='_blank'><img src='../img/nav-icons/icon_download.png' alt='download' ></a>", encURL);
                        //html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divLinkedFilesView.InnerHtml = "";
                    divLinkedFilesView.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[4];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 3:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
            }
            return privilegeArray;
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            DAMServices.FreeTextSearchFiles dtC;
            DAMServices.FreeTextSearchFiles dtG;
            String html = String.Empty;
            String resulthtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                dtC = new DAMServices.FreeTextSearchFiles();
                dtG = new DAMServices.FreeTextSearchFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < searchPrivilege.Count(); i++)
                {
                    dtC = new DAMServices.FreeTextSearchFiles();
                    dtG = new DAMServices.FreeTextSearchFiles();
                    string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                    dtC = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage
[1]),false);
                    dtG = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage
[3]),false);
                    if (i == 0)
                    {
                        dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                    else
                    {
                        dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                }
                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.FreeTextSearchTable.Rows)
                    {
                        if ((Int32)dr["DocId"] == Convert.ToInt32(hdnDocId.Value))
                            dr.Delete();
                    }
                    dt.FreeTextSearchTable.AcceptChanges();
                    Session["SearchResult"] = dt;
                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
                    gdvSearchResult.DataBind();
                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;                    
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
                else
                {
                    Session["SearchResult"] = dt;
                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
                    gdvSearchResult.DataBind();
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void gdvSearchResult_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "_View")
            {
                popup.Show();
                Int32 DocId = Convert.ToInt32(e.CommandArgument.ToString());
                BindLinkedFilesView(DocId, LibId);
                if(gdvSearchResult.Rows.Count>0)
                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                if(gdvLinkedFiles.Rows.Count>0)
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
        }
        protected void gdvSearchResult_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnLinkedDoc = (HiddenField)e.Row.FindControl("hdnLinkedDoc");
                    LinkButton btnLinkedDoc = (LinkButton)e.Row.FindControl("btnLinkedDoc");
                    btnLinkedDoc.Visible = (Convert.ToInt32(hdnLinkedDoc.Value) > 0) ? true : false;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
        protected void gdvSearchResult_RowCreated(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[19].Visible = false; // hides the first column
            e.Row.Cells[20].Visible = false; // hides the 12th column
        }
        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)gdvSearchResult.HeaderRow.FindControl("chkboxSelectAll");
            foreach (GridViewRow row in gdvSearchResult.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkSelect");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
            gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
            if(gdvLinkedFiles.Rows.Count>0)
                gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void btnAddLinkFile_Click(object sender, EventArgs e)
        {
            DAMServices.FreeTextSearchFiles master;
            List<int> values;
            try
            {
                values = new List<int>();
                master = (DAMServices.FreeTextSearchFiles)Session["SearchResult"];
                foreach (GridViewRow r in gdvSearchResult.Rows)
                {
                    CheckBox chkSelect = (CheckBox)r.FindControl("chkSelect");
                    if (chkSelect.Checked)
                    {
                        string value = r.Cells[GetColumnIndexByName(r, "DocId")].Text;
                        values.Add(Convert.ToInt32(value));
                    }
                }
                if (values.Count() > 0)
                {
                    var matchingRows = from row in master.FreeTextSearchTable.AsEnumerable()
                                       join value in values
                                       on row.Field<int>("DocId") equals value
                                       select row;
                    DataTable tblResult = matchingRows.CopyToDataTable();
                    if (Session["Result"] == null)
                    {
                        Session["Result"] = tblResult;
                        gdvLinkedFiles.DataSource = tblResult;
                        gdvLinkedFiles.DataBind();
                    }
                    else
                    {
                        DataTable dt = (DataTable)Session["Result"];
                        dt.PrimaryKey = new[] { dt.Columns["DocId"] };
                        dt.Merge(tblResult, true);
                        gdvLinkedFiles.DataSource = dt;
                        gdvLinkedFiles.DataBind();
                        Session["Result"] = dt;
                    }
                }
                if(gdvSearchResult.Rows.Count>0)
                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                if (gdvLinkedFiles.Rows.Count > 0)
                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                master = null;
                values = null;
            }
        }
        protected void gdvLinkedFiles_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Int32 DocId = Convert.ToInt32(e.CommandArgument);
            try
            {
                DataTable dt = (DataTable)Session["Result"];
                foreach (DataRow dr in dt.Rows)
                {
                    if ((Int32)dr["DocId"] == DocId)
                        dr.Delete();
                }
                dt.AcceptChanges();
                gdvLinkedFiles.DataSource = dt;
                gdvLinkedFiles.DataBind();
                Session["Result"] = dt;
                gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
                gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {

            }
        }
        protected void gdvLinkedFiles_RowCreated(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[1].Visible = false; // hides the first column
            e.Row.Cells[18].Visible = false; // hides the 12th column
            e.Row.Cells[19].Visible = false;

            GridViewRow row = e.Row;
            // Intitialize TableCell list
            List<TableCell> columns = new List<TableCell>();
            foreach (DataControlField column in gdvLinkedFiles.Columns)
            {
                //Get the first Cell /Column
                TableCell cell = row.Cells[0];
                // Then Remove it after
                row.Cells.Remove(cell);
                //And Add it to the List Collections
                columns.Add(cell);
            }

            // Add cells
            row.Cells.AddRange(columns.ToArray());
        }
        int GetColumnIndexByName(GridViewRow row, string SearchColumnName)
        {
            int columnIndex = 0;
            foreach (DataControlFieldCell cell in row.Cells)
            {
                if (cell.ContainingField is BoundField)
                {
                    if (((BoundField)cell.ContainingField).DataField.Equals(SearchColumnName))
                    {
                        break;
                    }
                }
                columnIndex++;
            }
            return columnIndex;
        }
        private string GetImgUrl(String Extension, String GuidName)
        {
            string imgUrl = "";
            switch (Extension.ToLower())
            {
                case ".png":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpg":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpeg":
                    imgUrl = GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                default:
                    DAMServices.ServiceContractClient objDAM;
                    objDAM = new DAMServices.ServiceContractClient();
                    var mlist = objDAM.GetFileExtensionMasterByExtension(Extension.Trim('.'));
                    if (mlist[0].PreviewImage != "")
                        imgUrl = "../img/file-icons/" + mlist[0].PreviewImage;
                    else
                        imgUrl = "../img/file-icons/noImageAvailable.jpg";
                    break;
            }
            return imgUrl;
        }
        private void BindFilePreview(String Extension, String GuidName)
        {
            switch (Extension.ToLower())
            {
                case ".png":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpg":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                case ".jpeg":
                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
                    break;
                default:
                    //DAMServices.ServiceContractClient objDAM;
                    //objDAM = new DAMServices.ServiceContractClient();
                    //var mlist = objDAM.GetFileExtensionMasterByExtension(Extension.Trim('.'));
                    //if (mlist[0].PreviewImage != "")
                    //    //imgFilePreview.ImageUrl = "../img/file-icons/" + mlist[0].PreviewImage;
                    //else
                    //    //imgFilePreview.ImageUrl = "../img/file-icons/noImageAvailable.jpg";
                    break;
            }
        }
        private string GenerateThumbnails(String path)
        {
            string imgUrl = "";
            System.Drawing.Image image = System.Drawing.Image.FromFile(path);
            using (System.Drawing.Image thumbnail = image.GetThumbnailImage(100, 100, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    thumbnail.Save(memoryStream, ImageFormat.Png);
                    Byte[] bytes = new Byte[memoryStream.Length];
                    memoryStream.Position = 0;
                    memoryStream.Read(bytes, 0, (int)bytes.Length);
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imgUrl = "data:image/png;base64," + base64String;
                }
            }
            return imgUrl;
        }
        public bool ThumbnailCallback()
        {
            return false;
        }
        protected void download_Click(object sender, EventArgs e)
        {
            String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
            String path2 = String.Empty;
            path2 = path1 + hdnGuidName.Value;
            if (File.Exists(path2))
            {
                String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + hdnGuidName.Value;
                System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                response.ClearContent();
                response.Clear();
                response.ContentType = ContentType;
                response.AddHeader("Content-Disposition", "attachment; filename=" + hdnFileName.Value + ";");
                response.TransmitFile(filePath);
                response.Flush();
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            Email objEmail;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                objEmail = new Email();
                Int32 r = objDAM.DeleteDocFile(Convert.ToInt32(hdnDocId.Value), UserId, GetIPAddress());
                if (r > 0)
                {
                    String strToEmail = String.Empty;
                    String strCCEmail = String.Empty;
                    var emails = objDAM.GetUserEmailByDocId(Convert.ToInt32(hdnDocId.Value));
                    if (emails.Count() > 0)
                    {
                        var toEmails = emails.Where(x => x.IsAppAdmin == false).ToList();
                        if (toEmails.Count() > 0)
                        {
                            for (int i = 0; i < toEmails.Count(); i++)
                            {
                                strToEmail += toEmails[i].EmailId + "|";
                            }
                        }
                    }
                    var OthersEmail = objDAM.GetAllUserInTeamList("");
                    var appAdminUsers = OthersEmail.Where(x => x.TeamName == "Application Administrator").ToList();
                    for (int i = 0; i < appAdminUsers.Count(); i++)
                    {
                        var user = objDAM.GetUserMasterById(appAdminUsers[i].UserId);
                        strCCEmail += user[0].EmailId + "|";
                    }
                    if (strToEmail != "")
                        strToEmail = strToEmail.Remove(strToEmail.Length - 1);
                    if (strCCEmail != "")
                        strCCEmail = strCCEmail.Remove(strCCEmail.Length - 1);
                    var template = objDAM.GetEventInTemplateSearch(LibId, "On Delete");
                    {
                        if (template.Count() > 0)
                        {
                            if (template[0].IsActive == true)
                            {
                                if (strToEmail.Length > 0 && strCCEmail.Length > 0)
                                    objEmail.SendOnDeleteEmail(strToEmail, strCCEmail, template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                                else if (strToEmail.Length == 0 && strCCEmail.Length > 0)
                                    objEmail.SendOnDeleteEmail(strCCEmail, "", template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session["Library"].ToString(), 
Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                            }
                        }
                    }
                    Response.Redirect("~/dashboard/index.aspx");
                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                objEmail = null;
            }
        }
        #region
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            BindControls();
        }
        private void BindControls()
        {
            if (Convert.ToInt32(hdnContentType.Value) > 0)
            {
                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(hdnContentType.Value));
                    //var mBrand = objDAM.GetUserBrandCategoryByFieldId(1, UserId);
                    var mBrand = objDAM.GetLookupMasterByFieldId(1, 1).Where(x => x.IsActive == true).ToList();
                    var mList = list.Where(x => x.IsActive == true);
                    var commonList = mList.Where(x => x.AttributeType != "MetaData").ToList();
                    var metadataList = mList.Where(x => x.AttributeType == "MetaData").ToList();
                    var mMetadataValues = objDAM.GetFileDocumentDetailsByDocId(Convert.ToInt32(hdnDocId.Value));
                    if (mBrand.Count() > 0 && ddlBrand.Items.Count == 0)
                    {
                        ddlBrand.DataSource = mBrand;
                        ddlBrand.DataValueField = "LookupId";
                        ddlBrand.DataTextField = "FieldValue";
                        ddlBrand.DataBind();
                        ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", "0"));

                        var brand = mMetadataValues.Where(x => x.FieldId == 1).ToList();
                        ddlBrand.SelectedValue = brand[0].LoopupId.ToString();
                        hdnBrandId.Value = brand[0].LoopupId.ToString();
                        var categoryValue = mMetadataValues.Where(x => x.FieldId == 2).ToList();
                        var categoryList = objDAM.GetCategoryByBrandId(Convert.ToInt32(brand[0].LoopupId));
                        gdvCategory.DataSource = categoryList;
                        gdvCategory.DataBind();
                        if(gdvCategory.Rows.Count > 0)
                            gdvCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
                        hdnCategoryIds.Value = "";
                        var category = objDAM.GetDocumentCategoryDetailByDocId(Convert.ToInt32(hdnDocId.Value));
                        for (int x = 0; x < category.Count(); x++)
                        {
                            hdnCategoryIds.Value = hdnCategoryIds.Value + category[x].CategoryId + ",";
                        }
                        foreach (GridViewRow row in gdvCategory.Rows)
                        {
                            CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                            HiddenField hdnCategoryId = (HiddenField)row.FindControl("hdnCategoryId");
                            chkAdd.Checked = false;
                            for (int x = 0; x < category.Count(); x++)
                            {
                                if (category[x].CategoryId.ToString() == hdnCategoryId.Value)
                                    chkAdd.Checked = true;
                            }
                            for (int y = 0; y < categoryList.Count(); y++)
                            {
                                if(categoryValue[0].LoopupId.ToString() == hdnCategoryId.Value)
                                    chkAdd.Checked = true;
                            }
                        }

                        //ddlBrandCopy.DataSource = mBrand.Where(x => x.LookupId.ToString() != hdnBrandId.Value).ToList();
                        ddlBrandCopy.DataSource = mBrand;
                        ddlBrandCopy.DataValueField = "LookupId";
                        ddlBrandCopy.DataTextField = "FieldValue";
                        ddlBrandCopy.DataBind();
                        ddlBrandCopy.Items.Insert(0, new ListItem("--Select Brand--", "0"));
                    }
                    
                   
                    if (commonList.Count() > 0)
                    {
                        for (int i = 0; i < commonList.Count(); i++)
                        {
                            var result = mMetadataValues.Where(x => x.FieldId == commonList[i].FieldId).ToList();
                            if (result.Count() > 0)
                                generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, 
commonList[i].IsMandatory, i % 2, result[0].FieldValue, result[0].LoopupId);
                            else
                                generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, 
commonList[i].IsMandatory, i % 2, "",0);
                        }
                    }
                    if (metadataList.Count() > 0)
                    {
                        for (int i = 0; i < metadataList.Count(); i++)
                        {
                            var result = mMetadataValues.Where(x => x.FieldId == metadataList[i].FieldId).ToList();
                            if (result.Count() > 0)
                                generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList
[i].FieldType, metadataList[i].IsMandatory, i % 2, result[0].FieldValue, result[0].LoopupId);
                            else
                                generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList
[i].FieldType, metadataList[i].IsMandatory, i % 2, "",0);
                        }
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
        }
        public void generateDynamicControls(String AttributeType, Int32 FieldId, String FieldName, String FieldType, Boolean IsRequired, int bgCss, String FieldValue, 
Int32 LookupId)
        {
            ViewState["control"] = FieldName + FieldId;
            switch (FieldType.ToLower())
            {
                case "texttype":
                    createDynamicTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, FieldValue);
                    break;
                case "listtype":
                    createDynamicDropDownList(AttributeType, FieldId, FieldName, IsRequired, bgCss, FieldValue, LookupId);
                    break;
                case "datetimetype":
                    createDynamicDateTime(AttributeType, FieldId, FieldName, IsRequired, bgCss, FieldValue);
                    break;
                case "textareatype":
                    createDynamicTextArea(AttributeType, FieldId, FieldName, IsRequired, bgCss, FieldValue);
                    break;
                case "numerictype":
                    createDynamicNumericTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, FieldValue);
                    break;
                default:
                    break;
            }
        }
        public void createDynamicTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String FieldValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            //txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = FieldValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            plcHldMetadata.Controls.Add(tr);
        }
        public void createDynamicDropDownList(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String FieldValue, Int32 LookupId)
        {
            if (FieldId > 2)
            {
                HtmlGenericControl tr = new HtmlGenericControl("tr");
                HtmlGenericControl td1 = new HtmlGenericControl("td");
                if (bgCss == 0)
                    tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
                else
                    tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
                Label lbl = new Label();
                lbl.ID = "lbl" + FieldId.ToString();
                lbl.Text = FieldName;
                td1.Controls.Add(lbl);
                tr.Controls.Add(td1);

                if (IsRequired)
                {
                    Label lbl1 = new Label();
                    lbl1.ID = "lbl" + FieldName;
                    lbl1.Text = "   *";
                    lbl1.ForeColor = System.Drawing.Color.Red;
                    td1.Controls.Add(lbl1);
                    tr.Controls.Add(td1);
                }

                HtmlGenericControl td2 = new HtmlGenericControl("td");
                DropDownList ddl = new DropDownList();
                ddl.ID = "ddl" + FieldId.ToString();
                ddl.Width = 265;
                ddl.CssClass = "my-class";

                TextBox txt = new TextBox();
                txt.ID = "txt" + FieldId.ToString();
                txt.Width = 200;
                txt.CssClass = "my-class";
                txt.Text = FieldValue;
                txt.Visible = false;
                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    var list = objDAM.GetLookupMasterByFieldId(FieldId, LibId);
                    if (FieldId == 1 || FieldId == 2)
                    {
                        var mList = objDAM.GetUserBrandCategoryByFieldId(FieldId, UserId).ToList();
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }
                    else
                    {
                        var mList = list.Where(x => x.IsActive == true);
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
                ddl.Items.Insert(0, new ListItem("--Select--", "0"));

                if (ddl.Items.FindByValue(LookupId.ToString()) != null)
                    ddl.Items.FindByValue(LookupId.ToString()).Selected = true;


                if (FieldName == "Confidential")
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var UploadPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Upload" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                    var EditPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Edit" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                    var DeletePrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Delete" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList();
                    var DownloadPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Download" && x.ContentTypeId == Convert.ToInt32(hdnContentType.Value)).ToList
();
                    CommonClass objCommon = new CommonClass();
                    int[] uploadprivilege = objCommon.DecimalToBase(UploadPrivilege[0].Permission, 2);
                    int[] editprivilege = objCommon.DecimalToBase(EditPrivilege[0].Permission, 2);
                    int[] deleteprivilege = objCommon.DecimalToBase(DeletePrivilege[0].Permission, 2);
                    int[] downloadprivilege = objCommon.DecimalToBase(DownloadPrivilege[0].Permission, 2);

                    if (FieldValue == "Yes" && hdnUploadedBy.Value == UserId.ToString())
                    {
                        if (editprivilege[0] == 0)
                        {
                            btnEditMetadata.Attributes.Add("style", "display:none");
                            editInfo.Attributes.Add("style", "display:none");
                            btnEditLinkFiles.Attributes.Add("style", "display:none");
                            btnConfirmVersion.Attributes.Add("style", "display:none");
                        }
                        if (uploadprivilege[0] == 0)
                        {
                            btnAddVersion.Attributes.Add("style", "display:none");
                            btnAddFiles.Attributes.Add("style", "display:none");
                        }
                        if (deleteprivilege[0] == 0)
                        {
                            btnDelete.Visible = false;
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDeleteLink = (LinkButton)item.FindControl("btnDelete");
                                System.Web.UI.WebControls.Image imgDelete = (System.Web.UI.WebControls.Image)item.FindControl("imgDelete");
                                btnDeleteLink.Visible = false;
                                imgDelete.Visible = false;
                            }
                        }
                        if (downloadprivilege[0] == 0)
                        {
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDownload = (LinkButton)item.FindControl("btnDownload");
                                System.Web.UI.WebControls.Image imgDownload = (System.Web.UI.WebControls.Image)item.FindControl("imgDownload");
                                btnDownload.Visible = false;
                                imgDownload.Visible = false;
                            }
                        }
                    }
                    else if (FieldValue == "Yes" && hdnUploadedBy.Value != UserId.ToString())
                    {
                        if (editprivilege[1] == 0)
                        {
                            btnEditMetadata.Attributes.Add("style", "display:none");
                            editInfo.Attributes.Add("style", "display:none");
                            btnEditLinkFiles.Attributes.Add("style", "display:none");
                            btnConfirmVersion.Attributes.Add("style", "display:none");
                        }
                        if (uploadprivilege[1] == 0)
                        {
                            btnAddVersion.Attributes.Add("style", "display:none");
                            btnAddFiles.Attributes.Add("style", "display:none");
                        }
                        if (deleteprivilege[1] == 0)
                        {
                            btnDelete.Visible = false;
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDeleteLink = (LinkButton)item.FindControl("btnDelete");
                                System.Web.UI.WebControls.Image imgDelete = (System.Web.UI.WebControls.Image)item.FindControl("imgDelete");
                                btnDeleteLink.Visible = false;
                                imgDelete.Visible = false;
                            }
                        }
                        if (downloadprivilege[1] == 0)
                        {
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDownload = (LinkButton)item.FindControl("btnDownload");
                                System.Web.UI.WebControls.Image imgDownload = (System.Web.UI.WebControls.Image)item.FindControl("imgDownload");
                                btnDownload.Visible = false;
                                imgDownload.Visible = false;
                            }
                        }
                    }
                    else if (FieldValue == "No" && hdnUploadedBy.Value == UserId.ToString())
                    {
                        if (editprivilege[2] == 0)
                        {
                            btnEditMetadata.Attributes.Add("style", "display:none");
                            editInfo.Attributes.Add("style", "display:none");
                            btnEditLinkFiles.Attributes.Add("style", "display:none");
                            btnConfirmVersion.Attributes.Add("style", "display:none");
                        }
                        if (uploadprivilege[2] == 0)
                        {
                            btnAddVersion.Attributes.Add("style", "display:none");
                            btnAddFiles.Attributes.Add("style", "display:none");
                        }
                        if (deleteprivilege[2] == 0)
                        {
                            btnDelete.Visible = false;
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDeleteLink = (LinkButton)item.FindControl("btnDelete");
                                System.Web.UI.WebControls.Image imgDelete = (System.Web.UI.WebControls.Image)item.FindControl("imgDelete");
                                btnDeleteLink.Visible = false;
                                imgDelete.Visible = false;
                            }
                        }
                        if (downloadprivilege[2] == 0)
                        {
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDownload = (LinkButton)item.FindControl("btnDownload");
                                System.Web.UI.WebControls.Image imgDownload = (System.Web.UI.WebControls.Image)item.FindControl("imgDownload");
                                btnDownload.Visible = false;
                                imgDownload.Visible = false;
                            }
                        }
                    }
                    else if (FieldValue == "No" && hdnUploadedBy.Value != UserId.ToString())
                    {
                        if (editprivilege[3] == 0)
                        {
                            btnEditMetadata.Attributes.Add("style", "display:none");
                            editInfo.Attributes.Add("style", "display:none");
                            btnEditLinkFiles.Attributes.Add("style", "display:none");
                            btnConfirmVersion.Attributes.Add("style", "display:none");
                        }
                        if (uploadprivilege[3] == 0)
                        {
                            btnAddVersion.Attributes.Add("style", "display:none");
                            btnAddFiles.Attributes.Add("style", "display:none");
                        }
                        if (deleteprivilege[3] == 0)
                        {
                            btnDelete.Visible = false;
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDeleteLink = (LinkButton)item.FindControl("btnDelete");
                                System.Web.UI.WebControls.Image imgDelete = (System.Web.UI.WebControls.Image)item.FindControl("imgDelete");
                                btnDeleteLink.Visible = false;
                                imgDelete.Visible = false;
                            }
                        }
                        if (downloadprivilege[3] == 0)
                        {
                            foreach (DataListItem item in FileDataList.Items)
                            {
                                LinkButton btnDownload = (LinkButton)item.FindControl("btnDownload");
                                System.Web.UI.WebControls.Image imgDownload = (System.Web.UI.WebControls.Image)item.FindControl("imgDownload");
                                btnDownload.Visible = false;
                                imgDownload.Visible = false;
                            }
                        }
                    }
                }
                if (ddl.SelectedItem.Text == "Others")
                    txt.Visible = true;
                td2.Controls.Add(ddl);
                td2.Controls.Add(txt);
                tr.Controls.Add(td2);
                ddl.SelectedIndexChanged += new EventHandler(ddl_SelectedIndexChanged);
                ddl.AutoPostBack = true;
                tr.EnableViewState = true;
                tr.ViewStateMode = ViewStateMode.Enabled;
                plcHldMetadata.Controls.Add(tr);
            }
        }
        protected void chkSelectAllCopy_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvCategoryCopy.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvCategoryCopy.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            if(gdvCategoryCopy.Rows.Count > 0)
                gdvCategoryCopy.HeaderRow.TableSection = TableRowSection.TableHeader;
            popupCopy.Show();
        }
        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvCategory.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvCategory.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            gdvCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "edit", "<script>EditMetadata();</script>", false);
        }
        protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetCategoryByBrandId(Convert.ToInt32(ddlBrand.SelectedValue));
                gdvCategory.DataSource = list;
                gdvCategory.DataBind();
                gdvCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "edit", "<script>EditMetadata();</script>", false);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void ddlBrandCopy_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetCategoryByBrandId(Convert.ToInt32(ddlBrandCopy.SelectedValue)).ToList();
                var category = objDAM.GetDocumentCategoryDetailByDocId(Convert.ToInt32(hdnDocId.Value)).ToList();
                var mList = objDAM.GetFileDocumentDetailsByDocId(Convert.ToInt32(hdnDocId.Value)).Where(x => x.FieldId == 2).ToList();
                for (int i = 0; i < category.Count(); i++)
                {
                    list = list.Where(x => x.CategoryId != category[i].CategoryId).ToList();
                }
                list = list.Where(x => x.CategoryId != mList[0].LoopupId).ToList();
                gdvCategoryCopy.DataSource = list;
                gdvCategoryCopy.DataBind();
                if(gdvCategoryCopy.Rows.Count > 0)
                    gdvCategoryCopy.HeaderRow.TableSection = TableRowSection.TableHeader;
                popupCopy.Show();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            string value = ((DropDownList)sender).SelectedItem.Text;
            string ddlId = ((DropDownList)sender).ID;
            if (value == "Others")
            {
                TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + ddlId.Remove(0, 3));
                txt.Visible = true;
                txt.Text = "";
            }
            else
            {
                TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + ddlId.Remove(0, 3));
                txt.Visible = false;
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>EditMetadata();</script>", false);
        }
        public void createDynamicDateTime(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String FieldValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.CssClass = "date";
            txtBox.Attributes.Add("style", "background-image: url('../img/nav-icons/calender.png');background-position: right center;background-repeat: no-repeat");
            //txtBox.Attributes.Add("disabled", "");
            txtBox.Text = FieldValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            plcHldMetadata.Controls.Add(tr);
        }
        public void createDynamicTextArea(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String FieldValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.TextMode = TextBoxMode.MultiLine;
            //txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = FieldValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            plcHldMetadata.Controls.Add(tr);
        }
        public void createDynamicNumericTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String FieldValue)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);
            if (IsRequired)
            {
                Label lbl1 = new Label();
                lbl1.ID = "lbl" + FieldName;
                lbl1.Text = "   *";
                lbl1.ForeColor = System.Drawing.Color.Red;
                td1.Controls.Add(lbl1);
                tr.Controls.Add(td1);
            }

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.Attributes.Add("onkeypress", "return allowOnlyNumber(event);");
            //txtBox.Attributes.Add("disabled", "");
            txtBox.CssClass = "my-class";
            txtBox.Text = FieldValue;
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            plcHldMetadata.Controls.Add(tr);
        }
        #endregion
        protected void btnCancelMetadata_Click(object sender, EventArgs e)
        {
            plcHldMetadata.Controls.Clear();
            BindControls();
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            List<brandCategory> bList;
            lblcopyMsg.Text = "";
            try
            {
                bList = new List<brandCategory>();
                String strCategoryIds = String.Empty;
                String strCategoryName = String.Empty;
                for (int p = 0; p < gdvCategoryCopy.Rows.Count; p++)
                {
                    CheckBox chkAdd = (CheckBox)gdvCategoryCopy.Rows[p].FindControl("chkAdd");
                    Label lblCategory = (Label)gdvCategoryCopy.Rows[p].FindControl("lblCategory");
                    HiddenField hdnCategoryId = (HiddenField)gdvCategoryCopy.Rows[p].FindControl("hdnCategoryId");
                    if (chkAdd.Checked)
                    {
                        strCategoryIds += hdnCategoryId.Value + ",";
                        strCategoryName += lblCategory.Text + ", ";
                    }
                }
                if (strCategoryIds != "")
                        strCategoryIds = strCategoryIds.Remove(strCategoryIds.Length - 1);
                if (strCategoryName != "")
                    strCategoryName = strCategoryName.Remove(strCategoryName.Length - 2);
                if (strCategoryIds.Length > 0 && ddlBrandCopy.SelectedIndex > 0)
                {
                    if (Session["BrandCategory"] == null)
                    {
                        bList.Add(new brandCategory
                        {
                            BrandId = ddlBrandCopy.SelectedValue.ToString(),
                            BrandName = ddlBrandCopy.SelectedItem.Text,
                            CategoryIds = strCategoryIds,
                            CategoryName = strCategoryName,
                        });
                        Session["BrandCategory"] = bList;
                    }
                    else
                    {
                        bList = (List<brandCategory>)Session["BrandCategory"];
                        var list = bList.Where(x => x.BrandId == ddlBrandCopy.SelectedValue.ToString() && x.CategoryIds == strCategoryIds).ToList();
                        if (list.Count() == 0)
                        {
                            bList.Add(new brandCategory
                            {
                                BrandId = ddlBrandCopy.SelectedValue.ToString(),
                                BrandName = ddlBrandCopy.SelectedItem.Text,
                                CategoryIds = strCategoryIds,
                                CategoryName = strCategoryName,
                            });
                            Session["BrandCategory"] = bList;
                        }
                        else
                        {
                            lblcopyMsg.Text = "This Brand category is already selected.";
                        }
                    }
                    gdvBrandCategory.DataSource = bList;
                    gdvBrandCategory.DataBind();
                    if (gdvBrandCategory.Rows.Count > 0)
                        gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
                else
                {
                    lblcopyMsg.Text = "Brand or category not selected.";
                }
                popupCopy.Show();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            
        }
        protected void gdvBrandCategory_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            List<brandCategory> bList;
            try
            {
                String BrandId = e.CommandArgument.ToString();
                if (e.CommandName == "_Remove")
                {
                    bList = new List<brandCategory>();
                    bList = (List<brandCategory>)Session["BrandCategory"];
                    bList.RemoveAll(s => s.BrandId == BrandId);
                    if (bList.Count() > 0)
                    {
                        Session["BrandCategory"] = bList;
                        gdvBrandCategory.DataSource = bList;
                        gdvBrandCategory.DataBind();
                        if (gdvBrandCategory.Rows.Count > 0)
                            gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }
                    else
                    {
                        Session["BrandCategory"] = null;
                        gdvBrandCategory.DataSource = null;
                        gdvBrandCategory.DataBind();
                    }
                    popupCopy.Show();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
        }
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            popupCopy.Show();
            Session["BrandCategory"] = null;
            ddlBrandCopy.SelectedIndex = -1;
            gdvBrandCategory.DataSource = null;
            gdvBrandCategory.DataBind();
            gdvCategoryCopy.DataSource = null;
            gdvCategoryCopy.DataBind();
            lblcopyMsg.Text = "";
        }
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            plcHldMetadata.Controls.Clear();
            BindControls();
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "edit", "<script>EditMetadata();</script>", false);
        }
        private class brandCategory
        {
            public String BrandId { get; set; }
            public String BrandName { get; set; }
            public String CategoryIds { get; set; }
            public String CategoryName { get; set; }
        }
        protected void btnUpdateMetadata_Click(object sender, EventArgs e)
        {
            Int32 returnValue;
            String IPAddress = String.Empty;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";            
            DAMServices.ServiceContractClient objDAM;
            try
            {
                if (Convert.ToInt32(hdnDocId.Value)>0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    if (Convert.ToInt32(ddlBrand.SelectedValue) < 1)
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = "Brand is required.";
                        return;
                    }
                    if (gdvCategory.Rows.Count == 0)
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = "No category is mapped to selected brand.";
                        return;
                    }
                    Boolean isCategorySelected = false;
                    for (int i = 0; i < gdvCategory.Rows.Count; i++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvCategory.Rows[i].FindControl("chkAdd");
                        if (chkAdd.Checked)
                        {
                            isCategorySelected = true;
                            break;
                        }
                    }
                    if (!isCategorySelected)
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = "Select atleast one category.";
                        return;
                    }
                    String strDocDetails = String.Empty;
                    IPAddress = GetIPAddress();
                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(hdnContentType.Value));
                    var mList = list.Where(x => x.IsActive == true).ToList();
                    for (int i = 0; i < mList.Count(); i++)
                    {
                        if (mList[i].FieldId > 2)
                        {
                            switch (mList[i].FieldType.ToLower())
                            {
                                case "texttype":
                                case "textareatype":
                                case "numerictype":
                                    TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                    if (txt.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
                                    {
                                        divConfirm.Attributes.Add("style", "display:none");
                                        divError.Attributes.Add("style", "display:block");
                                        confirmMsg.InnerHtml = "";
                                        errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>EditMetadata();</script>", false);
                                        return;
                                    }
                                    strDocDetails += hdnDocId.Value + "^" + mList[i].FieldId + "^" + 0 + "^" + txt.Text + "^" + UserId + "^" + IPAddress + "|";
                                    break;
                                case "datetimetype":
                                    TextBox txtExpiryDate = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                    if (txtExpiryDate.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
                                    {
                                        divConfirm.Attributes.Add("style", "display:none");
                                        divError.Attributes.Add("style", "display:block");
                                        confirmMsg.InnerHtml = "";
                                        errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                        return;
                                    }
                                    else if (txtExpiryDate.Text.Trim().Length > 0 && mList[i].FieldName == "ExpiryDate")
                                    {
                                        //CommonClass objCommon = new CommonClass();
                                        //Boolean IsValid = objCommon.ValidateExpiryDate(txtExpiryDate.Text,Convert.ToInt32(mList[i].DefaultValue));
                                        //if (!IsValid)
                                        //{
                                        //    divConfirm.Attributes.Add("style", "display:none");
                                        //    divError.Attributes.Add("style", "display:block");
                                        //    confirmMsg.InnerHtml = "";
                                        //    errorMsg.InnerHtml = mList[i].FieldName + " is invalid.";
                                        //    return;
                                        //}
                                    }
                                    strDocDetails += hdnDocId.Value + "^" + mList[i].FieldId + "^" + 0 + "^" + txtExpiryDate.Text + "^" + UserId + "^" + IPAddress + 
"|";
                                    break;
                                case "listtype":
                                    DropDownList ddl = (DropDownList)plcHldMetadata.FindControl("ddl" + mList[i].FieldId.ToString());
                                    TextBox txtOther = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                    if (Convert.ToInt32(ddl.SelectedValue) == 0 && mList[i].IsMandatory == true)
                                    {
                                        divConfirm.Attributes.Add("style", "display:none");
                                        divError.Attributes.Add("style", "display:block");
                                        confirmMsg.InnerHtml = "";
                                        errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>EditMetadata();</script>", false);
                                        return;
                                    }
                                    else if (ddl.SelectedItem.Text == "Others" && mList[i].IsMandatory == true && txtOther.Text.Trim() == "")
                                    {
                                        divConfirm.Attributes.Add("style", "display:none");
                                        divError.Attributes.Add("style", "display:block");
                                        confirmMsg.InnerHtml = "";
                                        errorMsg.InnerHtml = mList[i].FieldCaption + " is required.";
                                        return;
                                    }
                                    else if (ddl.SelectedItem.Text == "Others")
                                    {
                                        strDocDetails += hdnDocId.Value + "^" + mList[i].FieldId + "^" + ddl.SelectedValue + "^" + txtOther.Text + "^" + UserId + "^" + 
IPAddress + "|";
                                    }
                                    else if (Convert.ToInt32(ddl.SelectedValue) == 0)
                                        strDocDetails += hdnDocId.Value + "^" + mList[i].FieldId + "^" + ddl.SelectedValue + "^" + "" + "^" + UserId + "^" + IPAddress 
+ "|";
                                    else
                                        strDocDetails += hdnDocId.Value + "^" + mList[i].FieldId + "^" + ddl.SelectedValue + "^" + ddl.SelectedItem.Text + "^" + UserId 
+ "^" + IPAddress + "|";
                                    break;
                            }
                        }
                    }
                    //for brand
                    strDocDetails += hdnDocId.Value + "^" + 1 + "^" + ddlBrand.SelectedValue + "^" + ddlBrand.SelectedItem.Text + "^" + UserId + "^" + IPAddress + "|";
                    //for category
                    String strCategory = String.Empty;
                    for (int p = 0; p < gdvCategory.Rows.Count; p++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvCategory.Rows[p].FindControl("chkAdd");
                        Label lblCategory = (Label)gdvCategory.Rows[p].FindControl("lblCategory");
                        HiddenField hdnCategoryId = (HiddenField)gdvCategory.Rows[p].FindControl("hdnCategoryId");
                        if (chkAdd.Checked)
                        {
                            strCategory += hdnDocId.Value + "^" + hdnCategoryId.Value + "^" + lblCategory.Text + "^" + UserId + "|";
                        }
                    }
                    if (strCategory != "")
                        strCategory = strCategory.Remove(strCategory.Length - 1);///remove last character(|)
                    if (strCategory.Length > 0)
                    {
                        String[] strCategoryArray = strCategory.Split('|');
                        String[] category = strCategoryArray[0].Split('^');
                        strDocDetails += hdnDocId.Value + "^" + 2 + "^" + category[1] + "^" + category[2] + "^" + UserId + "^" + IPAddress + "|";
                    }

                    if (strDocDetails != "")
                        strDocDetails = strDocDetails.Remove(strDocDetails.Length - 1);///remove last character(|)
                    returnValue = objDAM.DocumentInfoDetailUpdate(strDocDetails);
                    objDAM.DeactivateAllDocumentCategory(Convert.ToInt32(hdnDocId.Value));
                    int returnVal1 = objDAM.DocumentCategoryDetailUpdate(strCategory);
                    if (returnValue > 0 || returnVal1 > 0)
                    {
                        objDAM.InsertUserNotification(UserId, TeamId, Convert.ToInt32(hdnDocId.Value), LibId, "Update");
                        BindFileDocumentDetails(Convert.ToInt32(hdnDocId.Value));
                        ////
                        Email objEmail = new Email();
                        String strToEmail = String.Empty;
                        String strCCEmail = String.Empty;
                        var emails = objDAM.GetUserEmailByDocId(Convert.ToInt32(hdnDocId.Value));
                        if (emails.Count() > 0)
                        {
                            var toEmails = emails.Where(x => x.IsAppAdmin == false).ToList();
                            if (toEmails.Count() > 0)
                            {
                                for (int i = 0; i < toEmails.Count(); i++)
                                {
                                    strToEmail += toEmails[i].EmailId + "|";
                                }
                            }
                        }
                        var OthersEmail = objDAM.GetAllUserInTeamList("");
                        var appAdminUsers = OthersEmail.Where(x => x.TeamName == "Application Administrator").ToList();
                        for (int i = 0; i < appAdminUsers.Count(); i++)
                        {
                            var user = objDAM.GetUserMasterById(appAdminUsers[i].UserId);
                            strCCEmail += user[0].EmailId + "|";
                        }

                        if (strToEmail != "")
                            strToEmail = strToEmail.Remove(strToEmail.Length - 1);
                        if (strCCEmail != "")
                            strCCEmail = strCCEmail.Remove(strCCEmail.Length - 1);
                        var template = objDAM.GetEventInTemplateSearch(LibId, "On Update");
                        if (template.Count() > 0)
                        {
                            if (template[0].IsActive == true)
                            {
                                if (strToEmail.Length > 0 && strCCEmail.Length > 0)
                                    objEmail.SendOnUpdateEmail(strToEmail, strCCEmail, template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                                else if (strToEmail.Length == 0 && strCCEmail.Length > 0)
                                    objEmail.SendOnUpdateEmail(strCCEmail, "", template[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session["Library"].ToString(), 
Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId);
                            }
                        }
                        var updatedList = objDAM.GetUpdatedDocumentDetailsForMail(Convert.ToInt32(hdnDocId.Value));
                        var otherList = updatedList.Where(x => x.FieldValue == "Others" && x.NewValue != "").ToList();
                        if (otherList.Count() > 0)
                        {
                            var OthersTemplate = objDAM.GetEventInTemplateSearch(LibId, "On Others");
                            {
                                if (OthersTemplate.Count() > 0)
                                {
                                    if (OthersTemplate[0].IsActive == true)
                                    {
                                        if (strCCEmail.Length > 0)
                                            objEmail.SendOnOthersEmail(strCCEmail, "", OthersTemplate[0].TemplateId, Convert.ToInt32(hdnDocId.Value), Session
["Library"].ToString(), Session["FirstName"].ToString() + " " + Session["LastName"].ToString(), UserId, "Update");
                                    }
                                }
                            }
                        }
                        ////
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.EDIT_FAIL;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnUpdateKeyword_Click(object sender, EventArgs e)
        {
            Int32 returnValue;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                returnValue = objDAM.UpdateDocomentInfoMaster(Convert.ToInt32(hdnDocId.Value), txtKeywords.Value, UserId ,GetIPAddress());
                if (returnValue > 0)
                {
                    objDAM.InsertUserNotification(UserId, TeamId, Convert.ToInt32(hdnDocId.Value), LibId, "Update");
                    divConfirm.Attributes.Add("style", "display:block");
                    divError.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                    BindFileDocumentDetails(Convert.ToInt32(hdnDocId.Value));
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtSearch.Value = "";
            Session["SearchResult"] = null;
            gdvSearchResult.DataSource = null;
            gdvSearchResult.DataBind();
            BindLinkedFiles(Convert.ToInt32(hdnDocId.Value), LibId);
        }
        protected void btnUpdateLinkFile_Click(object sender, EventArgs e)
        {
            Int32 deactiveConfirmation;
            Int32 returnValue;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DataTable linkedFiles;
            DAMServices.ServiceContractClient objDAM;
            try
            {
                String strFileLinks = String.Empty;
                linkedFiles = new DataTable();
                objDAM = new DAMServices.ServiceContractClient();
                deactiveConfirmation = objDAM.DeactivateFileLinkDetail(Convert.ToInt32(hdnDocId.Value));

                if (deactiveConfirmation > 0)
                {
                    linkedFiles = (DataTable)Session["Result"];

                    foreach (DataRow row in linkedFiles.Rows)
                    {
                        strFileLinks += row["DocId"] + "," + UserId + "|";
                    }
                    if (strFileLinks != "")
                        strFileLinks = strFileLinks.Remove(strFileLinks.Length - 1);///remove last character(|)
                    returnValue = objDAM.UpdateFileLinkDetail(Convert.ToInt32(hdnDocId.Value), strFileLinks, GetIPAddress());
                    objDAM.InsertUserNotification(UserId, TeamId, Convert.ToInt32(hdnDocId.Value), LibId, "Update");
                    divConfirm.Attributes.Add("style", "display:block");
                    divError.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                    BindLinkedFiles(Convert.ToInt32(hdnDocId.Value), LibId);
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>hideEditLinkFiles();</script>", false);
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void imgAddFav_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                objDAM.AddRemoveFavourite(Convert.ToInt32(hdnDocId.Value),false,Convert.ToInt32(Session["UserId"].ToString()));
                BindFavorite(Convert.ToInt32(hdnDocId.Value), UserId);
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void imgRemoveFav_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                objDAM.AddRemoveFavourite(Convert.ToInt32(hdnDocId.Value), true, Convert.ToInt32(Session["UserId"].ToString()));
                BindFavorite(Convert.ToInt32(hdnDocId.Value), UserId);
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
    }
}