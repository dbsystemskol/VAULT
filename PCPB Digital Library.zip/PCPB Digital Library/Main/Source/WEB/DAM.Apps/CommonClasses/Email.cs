﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Text;
using System.Configuration;
using System.IO;
using System.Web.Configuration;
using System.Web.Mail;
using System.Web.Services;
//using System.Net.Mail;
//using System.Net;

namespace DAM.Apps.CommonClasses
{
    public class Email
    {
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public String[] GetEmailTemplateById(Int32 TemplateId, Int32 DocId, String LibName, String UserName)
        {
            String[] email = new String[2];
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllEmailTemplateById(TemplateId);
                email[0] = ReplaceTemplateValue(HttpContext.Current.Server.HtmlDecode(mList[0].Subject), DocId, LibName, UserName);
                email[1] = ReplaceTemplateValue(HttpContext.Current.Server.HtmlDecode(HttpContext.Current.Server.HtmlDecode(mList[0].Body)), DocId, LibName, UserName);
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }

            return email;
        }

        public String ReplaceTemplateValue(String TemplateValue, Int32 DocId, String LibName, String UserName)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllTemplateFieldMapping();
                var docDetails = objDAM.GetFileDocumentDetailsByDocId(DocId);
                var contenttype = objDAM.GetContentTypeIdByDocId(DocId);
                for (Int32 i = 0; i < mList.Count(); i++)
                {
                    var fieldValue = docDetails.Where(x => x.FieldId == mList[i].FieldId).ToList();
                    if(fieldValue.Count() > 0)
                        TemplateValue = TemplateValue.Replace(mList[i].TemplateField, fieldValue[0].FieldValue);
                }
                var user = objDAM.GetUserMasterById(docDetails[0].CreatedBy);
                TemplateValue = TemplateValue.Replace("<<Library Name>>", LibName);
                TemplateValue = TemplateValue.Replace("<<Uploaded By>>", user[0].FirstName + " " + user[0].LastName);
                TemplateValue = TemplateValue.Replace("<<Deleted By>>", UserName);
                TemplateValue = TemplateValue.Replace("<<Modified By>>", UserName);
                TemplateValue = TemplateValue.Replace("<<Content Type>>", contenttype[0].ContentType);
                TemplateValue = TemplateValue.Replace("<<Uploaded Date>>", contenttype[0].CreatedOn.ToString());
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }

            return TemplateValue;
        }

        private Int16 SendMail(String RecipientToEmails, String RecipientCCEmails, String FileContents, String subject, Int32 DocId, Int32 UserId, String EventName)
        {
            DAMServices.ServiceContractClient objDAM ;
            DAMServices.EmailLogInfo dList;
            String toEmails = "";
            String ccEmails = "";
            Int16 ReturnValue=0;
            String[] RecipientToEmail = RecipientToEmails.Split('|');
            String[] RecipientCCEmail = RecipientCCEmails.Split('|');
            for (int i = 0; i < RecipientToEmail.Length; i++)
            {
                if(RecipientToEmail[i].Length > 0)
                    toEmails += RecipientToEmail[i] + "; ";
            }

            for (int i = 0; i < RecipientCCEmail.Length; i++)
            {
                if(RecipientCCEmail[i].Length>0)
                    ccEmails += RecipientCCEmail[i] + "; ";
            }

            String fromAddress = ConfigurationManager.AppSettings["smtpUser"].ToString();
            MailMessage NewEmail = new MailMessage();
            NewEmail.From = fromAddress;
            NewEmail.To = toEmails;
            NewEmail.Cc = ccEmails;
            NewEmail.Body = FileContents;
            NewEmail.Subject = subject;
            NewEmail.BodyFormat = MailFormat.Html;
            SmtpMail.SmtpServer = ConfigurationManager.AppSettings["smtpServer"].ToString();

            //////

            //String fromAddress = "barunroy562@gmail.com";
            //String fromPassword = "****";
            //MailMessage NewEmail = new MailMessage();
            //NewEmail.From = new MailAddress(fromAddress);
            //for (int i = 0; i < RecipientToEmail.Length; i++)
            //{
            //    if (RecipientToEmail[i].Length > 0)
            //    {
            //        toEmails += RecipientToEmail[i] + ",";
            //        NewEmail.To.Add(new MailAddress(RecipientToEmail[i]));
            //    }
            //}
            //for (int i = 0; i < RecipientCCEmail.Length; i++)
            //{
            //    if (RecipientCCEmail[i].Length > 0)
            //    {
            //        ccEmails += RecipientCCEmail[i] + ",";
            //        NewEmail.CC.Add(new MailAddress(RecipientCCEmail[i]));
            //    }
            //}
            //NewEmail.Body = FileContents;
            //NewEmail.Subject = subject;
            //NewEmail.IsBodyHtml = true;


            //var smtp = new System.Net.Mail.SmtpClient();
            //{
            //    smtp.Host = "smtp.gmail.com";
            //    smtp.Port = 587;
            //    smtp.EnableSsl = true;
            //    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            //    smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
            //    smtp.Timeout = 20000;
            //}

            //////
            try
            {
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsMailActive"].ToString()))
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    dList = new DAMServices.EmailLogInfo();
                    SmtpMail.Send(NewEmail);
                    dList.DocId = DocId;
                    dList.SentTo = toEmails;
                    dList.SentCc = ccEmails;
                    dList.Subject = subject;
                    dList.Body = FileContents;
                    dList.EmailEvent = EventName;
                    dList.CreatedBy = UserId;
                    objDAM.InsertEmailLog(dList);
                    ReturnValue = 1;
                }
            }
            catch (Exception ex)
            {
                ReturnValue = 0;
                log.Error(ex);
                //throw ex;
            }
            return ReturnValue;
        }

        public Int16 SendOnUploadEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                FileNames += "<li>" +  uploadedFiles[i].FileName + "</li>";
            }
            FileNames += "</ul>";
            
            ////
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td>");
            html.AppendFormat("<td>{0}</td></tr>", FileNames);

            var updatedFields = objDAM.GetFileDocumentDetailsByDocId(DocId);
            for (int i = 1; i < updatedFields.Count(); i++)
            {
                html.Append("<tr>");
                html.AppendFormat("<td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td><td>{1}</td>",updatedFields[i].FieldCaption,updatedFields[i].FieldValue);
                html.Append("</tr>");
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On Upload");
            return returnVal;
        }

        public Int16 SendOnDeleteEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                FileNames += "<li>" + uploadedFiles[i].FileName + "</li>";
            }
            FileNames += "</ul>";

            ////
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td>");
            html.AppendFormat("<td>{0}</td></tr>", FileNames);

            var updatedFields = objDAM.GetFileDocumentDetailsByDocId(DocId);
            for (int i = 1; i < updatedFields.Count(); i++)
            {
                html.Append("<tr>");
                html.AppendFormat("<td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td><td>{1}</td>", updatedFields[i].FieldCaption, updatedFields[i].FieldValue);
                html.Append("</tr>");
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On Delete");
            return returnVal;
        }

        public Int16 SendOnUpdateEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                FileNames += "<li>" + uploadedFiles[i].FileName + "</li>";
            }
            FileNames += "</ul>";

            ////
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td><td colspan='2'>{0}</td></tr>",FileNames);

            html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> Caption </strong></td><td style='background-color:#ccc;' width='30%'><strong> Old Value </strong></td>");
            html.Append("<td style='background-color:#ccc;' width='30%'><strong> New Value </strong></td></tr>");

            var updatedFields = objDAM.GetUpdatedDocumentDetailsForMail(DocId);
            //html += "<p style='margin-left:10px'> <table width='100%' border='1' cellspacing='0' cellpadding='5' style='font-size: 12px;'> <tbody>";
            for (int i = 0; i < updatedFields.Count(); i++)
            {
                html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td>",updatedFields[i].FieldCaption);
                html.AppendFormat("<td><a style='color:#000;background:#ccc;'>{1}</a></td><td>{0}</td>", updatedFields[i].NewValue, updatedFields[i].OldValue);
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On Update");
            objDAM.UpdateDocumentInfoDetailClone(DocId);
            return returnVal;
        }

        public Int16 SendOnOthersEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId, String MailFiredFrom)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                FileNames += "<li>" + uploadedFiles[i].FileName + "</li>";
            }
            FileNames += "</ul>";
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td><td colspan='2'>{0}</td></tr>", FileNames);

            if (MailFiredFrom == "Update")
            {
                html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> Caption </strong></td><td style='background-color:#ccc;' width='30%'><strong> Old Value </strong></td>");
                html.Append("<td style='background-color:#ccc;' width='30%'><strong> New Value </strong></td></tr>");
                var updatedFields = objDAM.GetUpdatedDocumentDetailsForMail(DocId);
                for (int i = 0; i < updatedFields.Count(); i++)
                {
                    html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td>", updatedFields[i].FieldCaption);
                    html.AppendFormat("<td>{1}</td><td>{0}</td>", updatedFields[i].NewValue, updatedFields[i].OldValue);
                }
            }
            else if (MailFiredFrom == "Upload")
            {
                html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> Caption </strong></td>");
                html.Append("<td style='background-color:#ccc;' colspan='2'><strong> Value </strong></td></tr>");
                var updatedFields = objDAM.GetUpdatedDocumentDetailsForMail(DocId);
                for (int i = 0; i < updatedFields.Count(); i++)
                {
                    html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td>", updatedFields[i].FieldCaption);
                    html.AppendFormat("<td colspan='2'>{0}</td>", updatedFields[i].OldValue);
                }
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On Others");
            if (returnVal > 0)
            {
                objDAM.UpdateDocumentInfoDetailClone(DocId);
            }
            return returnVal;
        }

        public Int16 SendOnAddFileEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId, String GuidName)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                if (GuidName == uploadedFiles[i].GuidName)
                {
                    
                    FileNames += "<li><a style='color:#000;background:#ccc;'>" + uploadedFiles[i].FileName + " (Recently uploaded file) </a></li>";
                }
                else
                    FileNames += "<li>" + uploadedFiles[i].FileName + "</li>";
            }
            FileNames += "</ul>";

            ////
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td><td colspan='2'>{0}</td></tr>", FileNames);

            html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> Caption </strong></td>");
            html.Append("<td colspan='2' style='background-color:#ccc;'><strong> Value </strong></td></tr>");

            var updatedFields = objDAM.GetUpdatedDocumentDetailsForMail(DocId);
            //html += "<p style='margin-left:10px'> <table width='100%' border='1' cellspacing='0' cellpadding='5' style='font-size: 12px;'> <tbody>";
            for (int i = 0; i < updatedFields.Count(); i++)
            {
                html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td>", updatedFields[i].FieldCaption);
                if(updatedFields[i].NewValue == "")
                    html.AppendFormat("<td colspan='2'>{0}</td>", updatedFields[i].OldValue);
                else if (updatedFields[i].NewValue != "")
                    html.AppendFormat("<td colspan='2'>{0}</td>", updatedFields[i].NewValue);
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On File Upload");
            objDAM.UpdateDocumentInfoDetailClone(DocId);
            return returnVal;
        }

        public Int16 SendOnDeleteFileEmail(String RecipientToEmails, String RecipientCCEmails, Int32 TemplateId, Int32 DocId, String LibName, String UserName, Int32 UserId, String FileName)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            Int16 returnVal = 0;
            String[] mailContent = new String[2];
            mailContent = GetEmailTemplateById(TemplateId, DocId, LibName, UserName);
            String FileNames = String.Empty;
            StringBuilder html = new StringBuilder();
            var uploadedFiles = objDAM.GetFileInfoByDocId(DocId);
            FileNames += "<ul style='margin:0;padding:0 0 0 10px;'>";
            for (int i = 0; i < uploadedFiles.Count(); i++)
            {
                FileNames += "<li>" + uploadedFiles[i].FileName + "</li>";
            }
            
            FileNames += "<li><a style='color:#000;background:#ccc;'>" + FileName + " (Recently deleted file) </a></li>";
            FileNames += "</ul>";

            ////
            html.Append("<p style='margin-left:10px,'> <table width='100%' border='1' cellspacing='0' cellpadding='4' style='font-size: 12px;'> <tbody>");
            html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong> File(s) </strong></td><td colspan='2'>{0}</td></tr>", FileNames);

            html.Append("<tr><td style='background-color:#ccc;' width='30%'><strong> Caption </strong></td>");
            html.Append("<td colspan='2' style='background-color:#ccc;'><strong> Value </strong></td></tr>");

            var updatedFields = objDAM.GetUpdatedDocumentDetailsForMail(DocId);
            //html += "<p style='margin-left:10px'> <table width='100%' border='1' cellspacing='0' cellpadding='5' style='font-size: 12px;'> <tbody>";
            for (int i = 0; i < updatedFields.Count(); i++)
            {
                html.AppendFormat("<tr><td style='background-color:#ccc;' width='30%'><strong>{0}</strong></td>", updatedFields[i].FieldCaption);
                if (updatedFields[i].NewValue == "")
                    html.AppendFormat("<td colspan='2'>{0}</td>", updatedFields[i].OldValue);
                else if (updatedFields[i].NewValue != "")
                    html.AppendFormat("<td colspan='2'>{0}</td>", updatedFields[i].NewValue);
            }
            html.Append("</tbody> </table></p>");
            mailContent[1] = mailContent[1].Replace("<<Meta Data>>", html.ToString());
            returnVal = SendMail(RecipientToEmails, RecipientCCEmails, mailContent[1], mailContent[0], DocId, UserId, "On File Delete");
            objDAM.UpdateDocumentInfoDetailClone(DocId);
            return returnVal;
        }
    }
}