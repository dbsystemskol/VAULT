﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;
using System.Data.SqlClient;

namespace DAMServices
{
    public class FileMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(FileMaster));

        public Int32[] InsertFileMaster(FileInfo mFileMaster, 
                                      FileVersionInfo mFileVersion,
                                      DocomentMasterInfo mDocMaster,
                                      List<DocumentDetailInfo> mDocDetails,
                                      List<FileLinkDetailInfo> mFileLink, Int32 TeamId, Int32 LibId, String NotificationType)
        {
            Int32[] returnValues;
            Int32 _ReturnValue = 0;
            Int32 _SecondReturnValue = 0;
            Int32 DocId = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileInfoInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 100, mFileMaster.ContentTypeId);
            mCmd.AddParameter("@FileName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileMaster.FileName);
            mCmd.AddParameter("@GuidName", SqlDbType.VarChar, DataParameterDirection.Input, 200, mFileMaster.GuidName);
            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, mFileMaster.FileExtension);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileMaster.CreatedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                returnValues = new Int32[2];
                returnValues[0] = _ReturnValue;
                if (_ReturnValue > 0)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileVersionInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@VersionNo", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.VersionNo);
                    mCmd.AddParameter("@DefaultFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, mFileVersion.DefaultFlag);
                    mCmd.AddParameter("@FileSize", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileVersion.FileSize);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");

                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInfoMasterInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@ContentTypeId", SqlDbType.BigInt, DataParameterDirection.Input, 8, mDocMaster.ContentTypeId);
                    mCmd.AddParameter("@Keywords", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mDocMaster.Keywords);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    DocId = mCmd.GetParameterValue<Int32>("@ReturnValue");
                    returnValues[1] = DocId;

                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "UserNotificationInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
                    mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                    mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);
                    mCmd.ExecuteNonQuery();

                    foreach (DocumentDetailInfo item in mDocDetails)
                    {
                        mCmd = null;
                        mCmd = new DataCommand();
                        mCmd.CommandText = "DocumentInfoDetailInsert";
                        mCmd.CommandType = DataCommandType.StoredProcedure;
                        mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                        mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                        mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, item.FieldId);
                        if(item.LoopupId>0)
                            mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LoopupId);
                        else
                            mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, null);
                        mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.FieldValue);
                        mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
                        mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mDocMaster.IPAddress);
                        mCmd.ExecuteNonQuery();
                        _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                    }

                    foreach (FileLinkDetailInfo item in mFileLink)
                    {
                        mCmd = null;
                        mCmd = new DataCommand();
                        mCmd.CommandText = "FileLinkDetailInsert";
                        mCmd.CommandType = DataCommandType.StoredProcedure;
                        mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                        mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                        mCmd.AddParameter("@LinkedFileId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedFileId);
                        mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.CreatedBy);
                        mCmd.ExecuteNonQuery();
                        _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return returnValues;
        }

        public Int32 InsertFileMasterNew(List<FileInfo> mFileMaster,
                                      FileVersionInfo mFileVersion,
                                      DocomentMasterInfo mDocMaster,
                                      List<DocumentDetailInfo> mDocDetails,
                                      List<FileLinkDetailInfo> mFileLink,
                                      List<DocumentCategoryDetailInfo> mCategory, Int32 TeamId, Int32 LibId, String NotificationType)
        {
            Int32 _ReturnValue = 0;
            Int32 _DocIdReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DocumentInfoMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.BigInt, DataParameterDirection.Input, 8, mDocMaster.ContentTypeId);
            mCmd.AddParameter("@Keywords", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mDocMaster.Keywords);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
            try
            {
                mCmd.ExecuteNonQuery();
                _DocIdReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                foreach (FileInfo files in mFileMaster)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileInfoInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
                    mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 100, files.ContentTypeId);
                    mCmd.AddParameter("@FileName", SqlDbType.VarChar, DataParameterDirection.Input, 100, files.FileName);
                    mCmd.AddParameter("@GuidName", SqlDbType.VarChar, DataParameterDirection.Input, 200, files.GuidName);
                    mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, files.FileExtension);
                    mCmd.AddParameter("@FileSize", SqlDbType.BigInt, DataParameterDirection.Input, 8, files.FileSize);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, files.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");

                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileVersionInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@VersionNo", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.VersionNo);
                    mCmd.AddParameter("@DefaultFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, mFileVersion.DefaultFlag);
                    mCmd.AddParameter("@FileSize", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileVersion.FileSize);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
                    mCmd.ExecuteNonQuery();


                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInFileInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
                    mCmd.ExecuteNonQuery();
                }

                mCmd = null;
                mCmd = new DataCommand();
                mCmd.CommandText = "UserNotificationInsert";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);
                mCmd.ExecuteNonQuery();

                foreach (DocumentDetailInfo item in mDocDetails)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInfoDetailInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
                    mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, item.FieldId);
                    if (item.LoopupId > 0)
                        mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LoopupId);
                    else
                        mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, null);
                    mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.FieldValue);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mDocMaster.IPAddress);
                    mCmd.ExecuteNonQuery();
                }

                foreach (FileLinkDetailInfo item in mFileLink)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileLinkDetailInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
                    mCmd.AddParameter("@LinkedFileId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedFileId);
                    mCmd.AddParameter("@LinkedDocId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedDocId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.CreatedBy);
                    mCmd.ExecuteNonQuery();
                }

                foreach (DocumentCategoryDetailInfo item in mCategory)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentCategoryDetailInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
                    mCmd.AddParameter("@CategoryId", SqlDbType.Int, DataParameterDirection.Input, 4, item.CategoryId);
                    mCmd.AddParameter("@CategoryName", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.CategoryName);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.CreatedBy);
                    mCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _DocIdReturnValue;
        }




        //public Int32 InsertFileMasterNew(List<FileInfo> mFileMaster,
        //                              FileVersionInfo mFileVersion,
        //                              DocomentMasterInfo mDocMaster,
        //                              List<DocumentDetailInfo> mDocDetails,
        //                              List<FileLinkDetailInfo> mFileLink, Int32 TeamId, Int32 LibId, String NotificationType)
        //{
        //    Int32 _ReturnValue = 0;
        //    Int32 _DocIdReturnValue = 0;
        //    DataCommand mCmd = null;
        //    try
        //    {
        //        mCmd = new DataCommand();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    mCmd.CommandText = "DocumentInfoMasterInsert";
        //    mCmd.CommandType = DataCommandType.StoredProcedure;
        //    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
        //    mCmd.AddParameter("@ContentTypeId", SqlDbType.BigInt, DataParameterDirection.Input, 8, mDocMaster.ContentTypeId);
        //    mCmd.AddParameter("@Keywords", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mDocMaster.Keywords);
        //    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
        //    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
        //    try
        //    {
        //        mCmd.ExecuteNonQuery();
        //        _DocIdReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
        //        foreach (FileInfo files in mFileMaster)
        //        {
        //            mCmd = null;
        //            mCmd = new DataCommand();
        //            mCmd.CommandText = "FileInfoInsert";
        //            mCmd.CommandType = DataCommandType.StoredProcedure;
        //            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
        //            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 100, files.ContentTypeId);
        //            mCmd.AddParameter("@FileName", SqlDbType.VarChar, DataParameterDirection.Input, 100, files.FileName);
        //            mCmd.AddParameter("@GuidName", SqlDbType.VarChar, DataParameterDirection.Input, 200, files.GuidName);
        //            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, files.FileExtension);
        //            mCmd.AddParameter("@FileSize", SqlDbType.BigInt, DataParameterDirection.Input, 8, files.FileSize);
        //            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, files.CreatedBy);
        //            mCmd.ExecuteNonQuery();
        //            _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");

        //            mCmd = null;
        //            mCmd = new DataCommand();
        //            mCmd.CommandText = "FileVersionInsert";
        //            mCmd.CommandType = DataCommandType.StoredProcedure;
        //            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
        //            mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
        //            mCmd.AddParameter("@VersionNo", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.VersionNo);
        //            mCmd.AddParameter("@DefaultFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, mFileVersion.DefaultFlag);
        //            mCmd.AddParameter("@FileSize", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileVersion.FileSize);
        //            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
        //            mCmd.ExecuteNonQuery();


        //            mCmd = null;
        //            mCmd = new DataCommand();
        //            mCmd.CommandText = "DocumentInFileInsert";
        //            mCmd.CommandType = DataCommandType.StoredProcedure;
        //            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
        //            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
        //            mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);                    
        //            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
        //            mCmd.ExecuteNonQuery();
        //        }              

        //        mCmd = null;
        //        mCmd = new DataCommand();
        //        mCmd.CommandText = "UserNotificationInsert";
        //        mCmd.CommandType = DataCommandType.StoredProcedure;
        //        mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
        //        mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
        //        mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
        //        mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
        //        mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
        //        mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);
        //        mCmd.ExecuteNonQuery();

        //        foreach (DocumentDetailInfo item in mDocDetails)
        //        {
        //            mCmd = null;
        //            mCmd = new DataCommand();
        //            mCmd.CommandText = "DocumentInfoDetailInsert";
        //            mCmd.CommandType = DataCommandType.StoredProcedure;
        //            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
        //            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
        //            mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, item.FieldId);
        //            if (item.LoopupId > 0)
        //                mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LoopupId);
        //            else
        //                mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, null);
        //            mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.FieldValue);
        //            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocMaster.CreatedBy);
        //            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mDocMaster.IPAddress);
        //            mCmd.ExecuteNonQuery();
        //        }

        //        foreach (FileLinkDetailInfo item in mFileLink)
        //        {
        //            mCmd = null;
        //            mCmd = new DataCommand();
        //            mCmd.CommandText = "FileLinkDetailInsert";
        //            mCmd.CommandType = DataCommandType.StoredProcedure;
        //            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
        //            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, _DocIdReturnValue);
        //            mCmd.AddParameter("@LinkedFileId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedFileId);
        //            mCmd.AddParameter("@LinkedDocId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedDocId);
        //            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.CreatedBy);
        //            mCmd.ExecuteNonQuery();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        mCmd.Dispose();
        //        mCmd = null;
        //    }
        //    return _DocIdReturnValue;
        //}

        public Int32 InsertFileToDocument(FileInfo mFileMaster, Int32 DocId)
        {
            Int32 _ReturnValue = 0;
            Int32 _SecondReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileInfoInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 100, mFileMaster.ContentTypeId);
            mCmd.AddParameter("@FileName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileMaster.FileName);
            mCmd.AddParameter("@GuidName", SqlDbType.VarChar, DataParameterDirection.Input, 200, mFileMaster.GuidName);
            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, mFileMaster.FileExtension);
            mCmd.AddParameter("@FileSize", SqlDbType.BigInt, DataParameterDirection.Input, 8, mFileMaster.FileSize);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileMaster.CreatedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                if (_ReturnValue > 0)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInFileInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@DocId", SqlDbType.BigInt, DataParameterDirection.Input, 4, DocId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileMaster.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }


        public DataTable GetDashboardNewFiles(String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DashboardNewFiles";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@BrandCategoryFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, IsUserMapped);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public DataTable GetDashboardRecentFiles(String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DashboardRecentFiles";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@BrandCategoryFlag", SqlDbType.Int, DataParameterDirection.Input, 4, IsUserMapped);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public DataTable GetFreeTextSearchFiles(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FreeTextSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 250, SearchText);
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@BrandCategoryFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, IsUserMapped);

                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public DataTable GetFreeTextSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FreeTextSearchByContentType";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 250, SearchText);
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@BrandCategoryFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, IsUserMapped);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public DataTable GetLinkedFilesForUpdate(Int32 DocId, Int32 LibId)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetLinkedFilesForUpdateByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public List<FileInfo> GetFileInfoById(Int32 FileInfoId)
        {
            List<FileInfo> mList = new List<FileInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileInfoById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, FileInfoId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileInfo
                        {
                            FileInfoId = mCmd.GetFieldValue<Int32>("FileInfoId"),
                            FileName = mCmd.GetFieldValue<String>("FileName"),
                            GuidName = mCmd.GetFieldValue<String>("GuidName"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<FileInfo> GetFileInfoByDocId(Int32 DocId)
        {
            List<FileInfo> mList = new List<FileInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileInfoByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileInfo
                        {
                            FileInfoId = mCmd.GetFieldValue<Int32>("FileInfoId"),
                            FileName = mCmd.GetFieldValue<String>("FileName"),
                            GuidName = mCmd.GetFieldValue<String>("GuidName"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            FileSize = mCmd.GetFieldValue<Int64>("FileSize"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<DocumentDetailInfo> GetFileDocumentDetailsByDocId(Int32 DocId)
        {
            List<DocumentDetailInfo> mList = new List<DocumentDetailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileDocumentInfoByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocumentDetailInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            LoopupId = mCmd.GetFieldValue<Int32>("LoopupId"),
                            LookupValue = mCmd.GetFieldValue<String>("LookupValue"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<DocumentDetailInfo> GetUpdatedDocumentDetailsForMail(Int32 DocId)
        {
            List<DocumentDetailInfo> mList = new List<DocumentDetailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetUpdatedDocumentDetailsForMail";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocumentDetailInfo
                        {

                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            OldValue = mCmd.GetFieldValue<String>("OldValue"),
                            NewValue = mCmd.GetFieldValue<String>("NewValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public DataTable GetLinkedFiles(Int32 DocId, Int32 LibId)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetLinkedFilesByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public Int32 InsertFileVersion(FileInfo mFileMaster,
                                       DocumentInFileInfo mDocumentInFile,
                                      FileVersionInfo mFileVersion)
        {
            Int32 _ReturnValue = 0;
            Int32 _SecondReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileInfoInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 100, mFileMaster.ContentTypeId);
            mCmd.AddParameter("@FileName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileMaster.FileName);
            mCmd.AddParameter("@GuidName", SqlDbType.VarChar, DataParameterDirection.Input, 200, mFileMaster.GuidName);
            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, mFileMaster.FileExtension);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileMaster.CreatedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                if (_ReturnValue > 0)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInFileInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@DocId", SqlDbType.BigInt, DataParameterDirection.Input, 4, mDocumentInFile.DocId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mDocumentInFile.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");

                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileVersionFromPreviewInsert";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 8, 5, 0);
                    mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, _ReturnValue);
                    mCmd.AddParameter("@VersionNo", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.VersionNo);
                    mCmd.AddParameter("@DefaultFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, mFileVersion.DefaultFlag);
                    mCmd.AddParameter("@FileSize", SqlDbType.VarChar, DataParameterDirection.Input, 100, mFileVersion.FileSize);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mFileVersion.CreatedBy);
                    mCmd.AddParameter("@DocId", SqlDbType.BigInt, DataParameterDirection.Input, 4, mFileVersion.DocId);
                    mCmd.ExecuteNonQuery();
                    _SecondReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");                   

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }


        public Int32 DeactivateFileLinkDetail(Int32 DocId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileLinkDetailDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }


        public Int32 UpdateFileLinkDetail(Int32 DocId, List<FileLinkDetailInfo> mFileLink, String IPAddress)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }            
            try
            {
                foreach (FileLinkDetailInfo item in mFileLink)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FileLinkDetailUpdate";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                    mCmd.AddParameter("@LinkedFileId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedFileId);
                    mCmd.AddParameter("@LinkedDocId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LinkedDocId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, IPAddress);
                    mCmd.ExecuteNonQuery();
                    _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                    _ReturnValue = _ReturnValue + 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public DataTable AdvanceSearch(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AdvanceSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 4000, SearchText);
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@IsUserMapped", SqlDbType.Bit, DataParameterDirection.Input, 1, IsUserMapped);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public DataTable AdvanceSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AdvanceSearchByContentType";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 4000, SearchText);
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@IsUserMapped", SqlDbType.Bit, DataParameterDirection.Input, 1, IsUserMapped);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public Int32 DeleteFile(Int32 FileInfoId, Int32 UserId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileInfoDelete";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, FileInfoId);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 DeleteDocFile(Int32 FileInfoId, Int32 UserId, String IPAddress)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DocumentInfoMasterDelete";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, FileInfoId);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 100, IPAddress);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        //
        public List<DocumentCategoryDetailInfo> GetDocumentCategoryDetailByDocId(Int32 DocId)
        {
            List<DocumentCategoryDetailInfo> mList = new List<DocumentCategoryDetailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DocumentCategoryDetailByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocumentCategoryDetailInfo
                        {
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            CategoryName = mCmd.GetFieldValue<String>("CategoryName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public DataTable GetMarketResearchFiles(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean BrandCategoryFlag)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ExportMarketResearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 250, SearchText);
                mCmd.AddParameter("@SearchCondition", SqlDbType.VarChar, DataParameterDirection.Input, 4, IsConfidential);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@BrandCategoryFlag", SqlDbType.Bit, DataParameterDirection.Input, 1, BrandCategoryFlag);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }


    }
}
