﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DAMServices.Configuration
{
    public class SMTPConfiguration
    {
        public static readonly ConfigHandler mCfg = (ConfigHandler)ConfigurationManager.GetSection("ITC.Data");

        public DatabaseElement SMTPMail
        {
            get
            {
                return mCfg.Smtpmail;
            }
        }
    }
}
