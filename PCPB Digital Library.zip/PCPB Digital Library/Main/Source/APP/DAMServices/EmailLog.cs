﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class EmailLog
    {
        protected static ILog log = LogManager.GetLogger(typeof(EmailSettingsMaster));
        public Int32 InsertEmailLog(EmailLogInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EmailLogInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DocId);
            mCmd.AddParameter("@SentTo", SqlDbType.VarChar, DataParameterDirection.Input, 500, mData.SentTo);
            mCmd.AddParameter("@SentCc", SqlDbType.VarChar, DataParameterDirection.Input, 500, mData.SentCc);
            mCmd.AddParameter("@Subject", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mData.Subject);
            mCmd.AddParameter("@Body", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mData.Body);
            mCmd.AddParameter("@EmailEvent", SqlDbType.VarChar, DataParameterDirection.Input, 50, mData.EmailEvent);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<EmailLogInfo> EmailLogSearch(String EmailEvent, String FromDate, String ToDate)
        {
            List<EmailLogInfo> mList = new List<EmailLogInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailLogSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                if(EmailEvent != "All")
                    mCmd.AddParameter("@EmailEvent", SqlDbType.VarChar, DataParameterDirection.Input, 20, EmailEvent);
                else
                    mCmd.AddParameter("@EmailEvent", SqlDbType.VarChar, DataParameterDirection.Input, 20, null);
                if(FromDate != "")
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, FromDate);
                else
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                if(ToDate != "")
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, ToDate);
                else
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailLogInfo
                        {
                            EmailLogId = mCmd.GetFieldValue<Int32>("EmailLogId"),
                            Title = mCmd.GetFieldValue<String>("Title"),
                            SentTo = mCmd.GetFieldValue<String>("SentTo"),
                            SentCc = mCmd.GetFieldValue<String>("SentCc"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            EmailEvent = mCmd.GetFieldValue<String>("EmailEvent"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EmailLogInfo> EmailLogById(Int32 EmailLogId)
        {
            List<EmailLogInfo> mList = new List<EmailLogInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailLogById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@EmailLogId", SqlDbType.Int, DataParameterDirection.Input, 4, EmailLogId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailLogInfo
                       {
                           EmailLogId = mCmd.GetFieldValue<Int32>("EmailLogId"),
                           Subject = mCmd.GetFieldValue<String>("Subject"),
                           Body = mCmd.GetFieldValue<String>("Body"),
                       });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<ExpiryReportInfo> ExpiryReport(String FromDate, String ToDate)
        {
            List<ExpiryReportInfo> mList = new List<ExpiryReportInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ExpiryReport";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                if (FromDate != "")
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, FromDate);
                else
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                if (ToDate != "")
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, ToDate);
                else
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ExpiryReportInfo
                        {
                            DocId = mCmd.GetFieldValue<Int32>("DocId"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            ContentType = mCmd.GetFieldValue<String>("ContentType"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            Title = mCmd.GetFieldValue<String>("Title"),
                            ExpiryDate = mCmd.GetFieldValue<String>("ExpiryDate"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            NoOfDaysLeft = mCmd.GetFieldValue<Int32>("NoOfDaysLeft"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
