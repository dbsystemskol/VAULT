﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;

namespace DAMServices.Configuration
{
    public class ConfigHandler : ConfigurationSection
    {
        [ConfigurationProperty(@"database")]
        public DatabaseElement Database
        {
            get { return (DatabaseElement)this[@"database"]; }
        }

        [ConfigurationProperty(@"smtpmail")]
        public DatabaseElement Smtpmail
        {
            get { return (DatabaseElement)this[@"smtpmail"]; }

        }
    }

    public class DefaultsElement : ConfigurationElement
    {

    }

    public class DatabaseElement : ConfigurationElement
    {
        [ConfigurationProperty(@"connStr")]
        public String ConnectionString
        {
            get { return (String)this[@"connStr"]; }
            set { this[@"connStr"] = value; }
        }

        [ConfigurationProperty(@"ccemailid")]
        public String CCemailid
        {
            get { return (String)this[@"ccemailid"]; }
            set { this[@"ccemailid"] = value; }
        }

        [ConfigurationProperty(@"emailid")]
        public String eMailid
        {
            get { return (String)this[@"emailid"]; }
            set { this[@"emailid"] = value; }
        }

        [ConfigurationProperty(@"password")]
        public String eMailpassword
        {
            get { return (String)this[@"password"]; }
            set { this[@"password"] = value; }
        }

        [ConfigurationProperty(@"smtpport")]
        public Int32 SMTPport
        {
            get { return (Int32)this[@"smtpport"]; }
            set { this[@"smtpport"] = value; }
        }

        [ConfigurationProperty(@"smtphost")]
        public String SMTPhost
        {
            get { return (String)this[@"smtphost"]; }
            set { this[@"smtphost"] = value; }
        }

        [ConfigurationProperty(@"sslenable")]
        public Boolean SSLEnable
        {
            get { return (Boolean)this[@"sslenable"]; }
            set { this[@"sslenable"] = value; }
        }
    }    
}
