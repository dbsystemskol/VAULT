﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.Security.Cryptography;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration; 

namespace DAM.Apps.dashboard
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                    else
                    {

                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                BindNotification(TeamId, UserId, LibId);
                PopulateFileNew(LibId, UserId);
                PopulateFileRecent(LibId, UserId);

                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
            }
        }

        protected void imgUpload_Click(object sender, EventArgs e)
        {
            Session["IsConfirm"] = 0;
            //Response.Redirect("~/document-upload/index.aspx");
            Response.Redirect("~/document-upload-new/index.aspx");
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");                    
                    
                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private int GetSelfPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 3:
                    privilegeValue = 1;                    
                    break;                
                case 8:
                case 12:
                    privilegeValue = 2;
                    break;
                case 10:
                case 11:
                case 14:
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        private int GetOtherPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 10:
                case 8:
                    privilegeValue = 0;
                    break;
                case 3:
                case 11:
                    privilegeValue = 1;
                    break;
                case 12:
                case 14:
                    privilegeValue = 2;
                    break;
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        private void PopulateFileNew(Int32 LibId, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardNewFiles dt;
            DAMServices.DashboardNewFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardNewFiles();
                
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardNewFiles();
                    String confidential = String.Empty;
                    Boolean BrandCategoryFlag = false;
                    switch (GetSelfPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            BrandCategoryFlag = false;
                            break;
                        case 1:
                            confidential = "No";
                            BrandCategoryFlag = false;
                            break;
                        case 2:
                            confidential = "Yes";
                            BrandCategoryFlag = false;
                            break;
                        case 3:
                            confidential = "";
                            BrandCategoryFlag = false;
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardNewFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, BrandCategoryFlag);
                        if (count == 0)
                        {
                            dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardNewFilesTable.Merge(dtTemp.DashboardNewFilesTable);
                    }
                }
                
                if (dt.DashboardNewFilesTable.Rows.Count > 0)
                {
                    dt.DashboardNewFilesTable = dt.DashboardNewFilesTable.AsEnumerable().Take(Convert.ToInt32(ConfigurationManager.AppSettings["DashboardRecordCount"].ToString())).CopyToDataTable();
                    html = "<table id='tblNew' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.DashboardNewFilesTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "DocId")
                        { }
                        else if (dcol.ColumnName == "SerialNo")
                        {
                            html += String.Format("<th>{0}</th>", "Doc No.");
                        }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.DashboardNewFilesTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.DashboardNewFilesTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "DocId")
                            { }
                            else if (column.ColumnName == "SerialNo")
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                            else if(column.ColumnName == "Title")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}",0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divNew.InnerHtml = html;
                }
                else
                {
                    //divConfirm.Attributes.Add("style", "display:none");
                    //divError.Attributes.Add("style", "display:block");
                    //confirmMsg.InnerHtml = "";
                    //errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        private void PopulateFileRecent(Int32 LibId, Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardRecentFiles dt;
            DAMServices.DashboardRecentFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardRecentFiles();
                
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardRecentFiles();
                    String confidential = String.Empty;
                    Boolean BrandCategoryFlag = false;
                    switch (GetOtherPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            BrandCategoryFlag = false;
                            break;
                        case 1:
                            confidential = "No";
                            BrandCategoryFlag = false;
                            break;
                        case 2:
                            confidential = "Yes";
                            BrandCategoryFlag = false;
                            break;
                        case 3:
                            confidential = "";
                            BrandCategoryFlag = false;
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardRecentFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, BrandCategoryFlag);
                        if(count == 0)
                        {
                            dt.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardRecentFilesTable.Merge(dtTemp.DashboardRecentFilesTable);                            
                    }
                }
                
                if (dt.DashboardRecentFilesTable.Rows.Count > 0)
                {
                    dt.DashboardRecentFilesTable = dt.DashboardRecentFilesTable.AsEnumerable().Take(Convert.ToInt32(ConfigurationManager.AppSettings["DashboardRecordCount"].ToString())).CopyToDataTable();
                    String encURL = String.Empty;
                    html = "<table id='tblRecent' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.DashboardRecentFilesTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "DocId")
                        { }
                        else if (dcol.ColumnName == "SerialNo")
                        {
                            html += String.Format("<th>{0}</th>", "Doc No.");
                        }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th width='5px'>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    foreach (DataRow row in dt.DashboardRecentFilesTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.DashboardRecentFilesTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "DocId")
                            { }
                            else if (column.ColumnName == "SerialNo")
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                            else if (column.ColumnName == "Title")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divRecent.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Value.Trim().Length == 0)
                return;
            Session["SearchText"] = txtSearch.Value.Trim();
            Response.Redirect("~/search-result/index.aspx?", false);
        }

        protected void btnExportMy_Click(Object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardNewFiles dt;
            DAMServices.DashboardNewFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardNewFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardNewFiles();
                    String confidential = String.Empty;
                    Boolean BrandCategoryFlag = false;
                    switch (GetSelfPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            BrandCategoryFlag = false;
                            break;
                        case 1:
                            confidential = "No";
                            BrandCategoryFlag = false;
                            break;
                        case 2:
                            confidential = "Yes";
                            BrandCategoryFlag = true;
                            break;
                        case 3:
                            confidential = "";
                            BrandCategoryFlag = true;
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardNewFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, BrandCategoryFlag);
                        if (count == 0)
                        {
                            dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardNewFilesTable.Merge(dtTemp.DashboardNewFilesTable);
                    }
                }

                if (dt.DashboardNewFilesTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";                    
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.DashboardNewFilesTable.Columns.Count;
                    foreach (DataColumn column in dt.DashboardNewFilesTable.Columns)
                    {
                        if (column.ColumnName == "DocId")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else 
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.DashboardNewFilesTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        for (int i = 1; i < dt.DashboardNewFilesTable.Columns.Count; i++)
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write(row[i].ToString());
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
                else
                {
                    //divConfirm.Attributes.Add("style", "display:none");
                    //divError.Attributes.Add("style", "display:block");
                    //confirmMsg.InnerHtml = "";
                    //errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExportOther_Click(Object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardRecentFiles dt;
            DAMServices.DashboardRecentFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardRecentFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardRecentFiles();
                    String confidential = String.Empty;
                    Boolean BrandCategoryFlag = false;
                    switch (GetOtherPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            BrandCategoryFlag = false;
                            break;
                        case 1:
                            confidential = "No";
                            BrandCategoryFlag = false;
                            break;
                        case 2:
                            confidential = "Yes";
                            BrandCategoryFlag = true;
                            break;
                        case 3:
                            confidential = "";
                            BrandCategoryFlag = true;
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardRecentFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, BrandCategoryFlag);
                        if (count == 0)
                        {
                            dt.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardRecentFilesTable.Merge(dtTemp.DashboardRecentFilesTable);
                    }
                }

                if (dt.DashboardRecentFilesTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.DashboardRecentFilesTable.Columns.Count;
                    foreach (DataColumn column in dt.DashboardRecentFilesTable.Columns)
                    {
                        if (column.ColumnName == "DocId")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.DashboardRecentFilesTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        for (int i = 1; i < dt.DashboardRecentFilesTable.Columns.Count; i++)
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write(row[i].ToString());
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[5];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    privilegeArray[4] = "true";
                    break;
                case 3:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    privilegeArray[4] = "true";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    privilegeArray[4] = "true";
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    privilegeArray[4] = "true";
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    privilegeArray[4] = "true";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    privilegeArray[4] = "true";
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    privilegeArray[4] = "true";
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    privilegeArray[4] = "true";
                    break;
            }
            return privilegeArray;
        }
        protected void btnExportMarket_Click(Object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            DAMServices.FreeTextSearchFiles dtC;
            DAMServices.FreeTextSearchFiles dtG;

            String html = String.Empty;
            String tagHtml = String.Empty;

            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];

                var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.Description.ToLower() == "Market Research".ToLower()).ToList();
                for (int i = 0; i < searchPrivilege.Count(); i++)
                {
                    dtC = new DAMServices.FreeTextSearchFiles();
                    dtG = new DAMServices.FreeTextSearchFiles();
                    string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                    dtC = objDAM.GetMarketResearchFiles("a", privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), false);
                    dtG = objDAM.GetMarketResearchFiles("a", privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), false);
                    if (i == 0)
                    {
                        dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                    else
                    {
                        dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                        dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                    }
                }


                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";
                    //HttpContext.Current.Response.ContentType = "application/ms-word";
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=MarketResearch.xls");
                    //HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.doc");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.FreeTextSearchTable.Columns.Count;
                    foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                    {
                        if (column.ColumnName == "DocId")
                        {

                        }

                        else if (column.ColumnName == "ContentTypeId")
                        {

                        }
                        else if (column.ColumnName == "LinkCount")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "DocId")
                            {

                            }

                            else if (column.ColumnName == "ContentTypeId")
                            {

                            }
                            else if (column.ColumnName == "LinkCount")
                            {

                            }
                            else if (column.ColumnName == "SerialNo")
                            {
                                HttpContext.Current.Response.Write("<Td>");
                                HttpContext.Current.Response.Write(row[column].ToString());
                                HttpContext.Current.Response.Write("</Td>");
                            }
                            else
                            {
                                HttpContext.Current.Response.Write("<Td>");
                                HttpContext.Current.Response.Write(row[column].ToString());
                                HttpContext.Current.Response.Write("</Td>");
                            }
                        }

                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
    }
}