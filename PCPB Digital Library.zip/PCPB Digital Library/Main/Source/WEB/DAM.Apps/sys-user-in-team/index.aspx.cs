﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Text;
using QueryStringEncryption;
using System.Web.Configuration;

namespace DAM.Apps.sys_user_in_team
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {                
                BindMenu(LibId);                
                PopulateActiveUserInTeamList();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateActiveUserInTeamList()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllActiveTeamMasterUserList();
                gdvUserInTeam.DataSource = list.Where(x => x.TeamName != "System Administrator").ToList();
                gdvUserInTeam.DataBind();
                if (gdvUserInTeam.Rows.Count > 0)
                    gdvUserInTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateTeamListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllActiveTeamMaster();
                ddlTeam.DataSource = list.Where(x => x.TeamName != "System Administrator").ToList();
                ddlTeam.DataValueField = "TeamId";
                ddlTeam.DataTextField = "TeamName";
                ddlTeam.DataBind();
                ddlTeam.Items.Insert(0, new ListItem("---- Select Team ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }


        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-with-category/index.aspx'>Brand With Category</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../document-log/index.aspx'>Document Log</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void gdvUserInTeam_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvUserInTeam_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.UserInTeamInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.UserInTeamInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowTeamId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        mData.UserInTeamId = RowTeamId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateUserInTeam(mData);
                        if (r > 0)
                        {
                            PopulateActiveUserInTeamList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateTeamListDropDown();
            ddlTeam.SelectedValue = "0";
            gdvUserList.DataSource = null;
            gdvUserList.DataBind();
            if (gdvUserInTeam.Rows.Count > 0)
                gdvUserInTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlTeam.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvUserList.DataSource = objDAM.GetUserListNotInParticularTeam(Convert.ToInt32(ddlTeam.SelectedValue));
                    gdvUserList.DataBind();
                    if (gdvUserList.Rows.Count > 0)
                        gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    if (gdvUserInTeam.Rows.Count > 0)
                        gdvUserInTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvUserList.DataSource = null;
                gdvUserList.DataBind();
                popup.Show();
            }
        }

        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvUserList.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvUserList.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            if (gdvUserList.Rows.Count > 0)
                gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvUserList.Rows.Count > 0)
            {
                try
                {
                    String strUsrInTmDetails = String.Empty;
                    for (int i = 0; i < gdvUserList.Rows.Count; i++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvUserList.Rows[i].FindControl("chkAdd");
                        HiddenField hdnUserId = (HiddenField)gdvUserList.Rows[i].FindControl("hdnUserId");
                        if (chkAdd.Checked)
                        {
                            strUsrInTmDetails += hdnUserId.Value + "," + ddlTeam.SelectedValue + "," + UserId + "," + GetIPAddress() + "|";
                        }
                    }
                    if (strUsrInTmDetails != "")
                    {
                        strUsrInTmDetails = strUsrInTmDetails.Remove(strUsrInTmDetails.Length - 1);
                        if (strUsrInTmDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertUserInTeam(strUsrInTmDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        PopulateActiveUserInTeamList();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllUserInTeamList(Server.HtmlEncode(txtSearchTeam.Value));
                gdvUserInTeam.DataSource = list.Where(x => x.TeamName != "System Administrator").ToList();
                gdvUserInTeam.DataBind();
                if (gdvUserInTeam.Rows.Count > 0)
                    gdvUserInTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvUserInTeam.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "UserWithTeam.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvUserInTeam.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvUserInTeam.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvUserInTeam.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvUserInTeam.HeaderRow.Cells.Count; i++)
                        gdvUserInTeam.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvUserInTeam.Columns.Count; i++)
                    {
                        if (gdvUserInTeam.Columns[i].HeaderText == "Active")
                            gdvUserInTeam.Columns[i].Visible = false;
                        if (gdvUserInTeam.Columns[i].HeaderText == "IsActive")
                            gdvUserInTeam.Columns[i].Visible = true;
                    }
                    gdvUserInTeam.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}