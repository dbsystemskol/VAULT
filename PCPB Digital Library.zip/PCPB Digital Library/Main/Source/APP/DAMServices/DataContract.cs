﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Data;

namespace DAMServices
{
    #region FileExtensionInfo
    [DataContract]
    public class FileExtensionInfo
    {
        [DataMember]
        public Int32 FileExtensionId;
        [DataMember]
        public String FileExtension;
        [DataMember]
        public String Description;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String PreviewImage;
    }
    #endregion

    #region LibraryMasterInfo
    [DataContract]
    public class LibraryMasterInfo
    {
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public String LibName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Name;
        [DataMember]
        public String IPAddress;

        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String FieldCategory;

        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public String Description;

        [DataMember]
        public Int32 LibraryAttributeSetId;
        [DataMember]
        public String AttributeType;
    }
    #endregion

    #region TeamMasterInfo
    [DataContract]
    public class TeamMasterInfo
    {
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public String TeamName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region TeamInLibraryInfo
    [DataContract]
    public class TeamInLibraryInfo
    {
        [DataMember]
        public Int32 TeamInLibraryId;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public String TeamName;
        [DataMember]
        public String LibName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region ContentTypeInfo
    [DataContract]
    public class ContentTypeInfo
    {
        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public String Description;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region ContentTypeMasterInfo
    [DataContract]
    public class ContentTypeMasterInfo
    {
        [DataMember]
        public Int32 ContentTypeMasterId;
        [DataMember]
        public String Description;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region AttributeFieldsInfo
    [DataContract]
    public class AttributeFieldsInfo
    {
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String FieldType;
        [DataMember]
        public Int32 FieldWidth;
        [DataMember]
        public String FieldCategory;
        [DataMember]
        public String DefaultValue;
        [DataMember]
        public Boolean AutoPopulate;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public Boolean IsMandatory;
    }
    #endregion

    #region LibraryAttributeSetInfo
    [DataContract]
    public class LibraryAttributeSetInfo
    {
        [DataMember]
        public Int32 LibraryAttributeSetId;
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public String AttributeType;
        [DataMember]
        public Boolean IsMandatory;
        [DataMember]
        public Int32 ColumnOrder;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String FieldType;
        [DataMember]
        public String DefaultValue;
    }
    #endregion

    #region LookupMasterInfo
    [DataContract]
    public class LookupMasterInfo
    {
        [DataMember]
        public Int32 LookupId;
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String FieldType;
        [DataMember]
        public String FieldCode;
        [DataMember]
        public String FieldValue;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String FieldCaption;
    }
    #endregion


    #region FileInfo
    [DataContract]
    public class FileInfo
    {
        [DataMember]
        public Int32 FileInfoId;
        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public String FileName;
        [DataMember]
        public String GuidName;
        [DataMember]
        public String FileExtension;
        [DataMember]
        public Int64 FileSize;
        [DataMember]
        public Boolean DeleteFlag;
        [DataMember]
        public Int32 DeletedBy;
        [DataMember]
        public DateTime DeletedOn;
        [DataMember]
        public Boolean PhysicallyDeleteFlag;
        [DataMember]
        public Int32 PhysicallyDeletedBy;
        [DataMember]
        public DateTime PhysicallyDeletedOn;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String UserName;
        [DataMember]
        public String ImgUrl;
    }
    #endregion

    #region FileVersionInfo
    [DataContract]
    public class FileVersionInfo
    {
        [DataMember]
        public Int32 FileVersionId;
        [DataMember]
        public Int32 FileInfoId;
        [DataMember]
        public Int32 VersionNo;
        [DataMember]
        public String VersionName;
        [DataMember]
        public Boolean DefaultFlag;
        [DataMember]
        public Int32 FileSize;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public Int32 DocId;
    }
    #endregion

    #region DocomentMasterInfo
    [DataContract]
    public class DocomentMasterInfo
    {
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public String Keywords;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String UserName;
        [DataMember]
        public Int64 SerialNo;
        [DataMember]
        public String ContentType;
    }
    #endregion

    #region DocumentInFileInfo
    [DataContract]
    public class DocumentInFileInfo
    {
        [DataMember]
        public Int32 DocumentInFileId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 FileInfoId;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region DocumentDetailInfo
    [DataContract]
    public class DocumentDetailInfo
    {
        [DataMember]
        public Int32 DocumentInfoDetailId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public Int32 LoopupId;
        [DataMember]
        public String FieldValue;
        [DataMember]
        public String LookupValue;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String OldValue;
        [DataMember]
        public String NewValue;
    }
    #endregion

    #region FileLinkDetailInfo
    [DataContract]
    public class FileLinkDetailInfo
    {
        [DataMember]
        public Int32 FileLinkDetailId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 LinkedFileId;
        [DataMember]
        public Int32 LinkedDocId;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region UserMasterInfo
    [DataContract]
    public class UserMasterInfo
    {
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public String UserName;
        [DataMember]
        public String FirstName;
        [DataMember]
        public String LastName;
        [DataMember]
        public String EmailId;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public Int32 LocationId;
        [DataMember]
        public String Location;
        [DataMember]
        public Int32 DepartmentId;
        [DataMember]
        public String Department;
        [DataMember]
        public Int32 DesignationId;
        [DataMember]
        public String Designation;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region TeamInPrivilege
    [DataContract]
    public class TeamInPrivilegeInfo
    {
        [DataMember]
        public Int32 TeamInPrivilegeId;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public Int32 PrivilegeId;
        [DataMember]
        public String PrivilegeName;
        [DataMember]
        public String TeamName;
        [DataMember]
        public Int32 Permission;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public Int32 ContentTypeId;
        [DataMember]
        public String  Description;
        [DataMember]
        public Boolean IsBrandCategoryMapped;
    }
    #endregion
    #region AttributeMaster
    [DataContract]
    public class AttributeMasterInfo
    {
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String FieldType;
        [DataMember]
        public Int32 FieldWidth;
        [DataMember]
        public String FieldCategory;
        [DataMember]
        public String DefaultValue;
        [DataMember]
        public Boolean AutoPopulate;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    [DataContract]
    public class DashboardNewFiles
    {
        [DataMember]
        public DataTable DashboardNewFilesTable
        {
            get;
            set;
        }
    }

    [DataContract]
    public class DashboardRecentFiles
    {
        [DataMember]
        public DataTable DashboardRecentFilesTable
        {
            get;
            set;
        }
    }

    [DataContract]
    public class FreeTextSearchFiles
    {
        [DataMember]
        public DataTable FreeTextSearchTable
        {
            get;
            set;
        }
    }

    [DataContract]
    public class LinkedFile
    {
        [DataMember]
        public DataTable LinkedFileTable
        {
            get;
            set;
        }
    }

    [DataContract]
    public class FavouriteDocumentList
    {
        [DataMember]
        public DataTable FavouriteDocumentTable
        {
            get;
            set;
        }
    }


    #region PrivilegeMasterInfo
    [DataContract]
    public class PrivilegeMasterInfo
    {
        [DataMember]
        public Int32 PrivilegeId;
        [DataMember]
        public String PrivilegeName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region UserInTeam
    [DataContract]
    public class UserInTeamInfo
    {
        [DataMember]
        public Int32 UserInTeamId;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Name;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public String TeamName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
        [DataMember]
        public Boolean InTeam;
    }
    #endregion

    [DataContract]
    public class FavouriteDocumentInfo
    {
        [DataMember]
        public Int32 FavouriteDocumentId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public String Label;
        [DataMember]
        public Boolean IsFavourite;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }

    [DataContract]
    public class UserNotificationInfo
    {
        [DataMember]
        public Int64 UserNotificationId;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public String NotificationType;
        [DataMember]
        public Int32 VisiterUserId;
        [DataMember]
        public Boolean IsVisited;
        [DataMember]
        public DateTime ActivityDate;
    }

    [DataContract]
    public class SaveSearchInfo
    {
        [DataMember]
        public Int32 SaveSearchId;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public String WhereText;
        [DataMember]
        public String SearchText;
        [DataMember]
        public String BindText;
        [DataMember]
        public DateTime SearchOn;        
    }

    [DataContract]
    public class LabelMasterInfo
    {
        [DataMember]
        public Int32 LabelMasterId;
        [DataMember]
        public String Label;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public DateTime CreatedOn;
    }

    #region LocationMasterInfo
    [DataContract]
    public class LocationMasterInfo
    {
        [DataMember]
        public Int32 LocationId;
        [DataMember]
        public String Location;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region DepartmentMasterInfo
    [DataContract]
    public class DepartmentMasterInfo
    {
        [DataMember]
        public Int32 DepartmentId;
        [DataMember]
        public String Department;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region DesignationMasterInfo
    [DataContract]
    public class DesignationMasterInfo
    {
        [DataMember]
        public Int32 DesignationId;
        [DataMember]
        public String Designation;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    #region EmailSettingsInfo
    [DataContract]
    public class EmailSettingsInfo
    {
        [DataMember]
        public Int32 EmailSettingsId;
        [DataMember]
        public Int32 AppAdminId;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Name;
        [DataMember]
        public String EmailId;
        [DataMember]
        public Int32 TeamId;
        [DataMember]
        public Boolean IsUpload;
        [DataMember]
        public Boolean IsEdit;
        [DataMember]
        public Boolean IsDelete;
        [DataMember]
        public Boolean IsOnExpiry;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
        [DataMember]
        public String IPAddress;
    }
    #endregion

    [DataContract]
    public class DocSerialNoInfo
    {
        [DataMember]
        public Int64 DocSerialNoId;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public Int64 NextSerialNo;
    }
    [DataContract]
    public class EmailTemplateInfo
    {
        [DataMember]
        public Int32 TemplateId;        
        [DataMember]
        public String TemplateName;
        [DataMember]
        public String Subject;
        [DataMember]
        public String Body;
    }

    [DataContract]
    public class EventMasterInfo
    {
        [DataMember]
        public Int32 EventId;
        [DataMember]
        public String EventName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    [DataContract]
    public class EventInTemplateInfo
    {
        [DataMember]
        public Int32 EventInTemplateId;
        [DataMember]
        public Int32 EventId;
        [DataMember]
        public String EventName;
        [DataMember]
        public Int32 TemplateId;
        [DataMember]
        public String TemplateName;
        [DataMember]
        public Int32 LibId;
        [DataMember]
        public String LibraryName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    [DataContract]
    public class EventObjectMappingInfo
    {
        [DataMember]
        public Int32 EventObjectId;
        [DataMember]
        public Int32 EventId;
        [DataMember]
        public String EventName;
        [DataMember]
        public Int32 FieldId;
        [DataMember]
        public String FieldCaption;
        [DataMember]
        public String FieldType;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    [DataContract]
    public class EventTriggerInfo
    {
        [DataMember]
        public Int32 EventTriggerId;
        [DataMember]
        public Int32 EventId;
        [DataMember]
        public String EventName;
        [DataMember]
        public Int32 Duration;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    [DataContract]
    public class TemplateFieldMappingInfo
    {
        [DataMember]
        public Int32 TemplateFieldId;
        [DataMember]
        public String TemplateField;
        [DataMember]
        public Int32 FieldId;
    }

    [DataContract]
    public class ExpiryMailInfo
    {
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public String LibName;
        [DataMember]
        public String UserName;
    }

    [DataContract]
    public class BrandCategoryMappingInfo
    {
        [DataMember]
        public Int32 BrandCategoryId;
        [DataMember]
        public Int32 BrandCategoryMappingId;
        [DataMember]
        public Int32 BrandId;
        [DataMember]
        public String Brand;
        [DataMember]
        public Int32 CategoryId;
        [DataMember]
        public String Category;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Name;
        [DataMember]
        public Int32 UserId;
        [DataMember]
        public String EmailId;
        [DataMember]
        public Int16 Permission;
        [DataMember]
        public Boolean IsAppAdmin;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    [DataContract]
    public class EmailLogInfo
    {
        [DataMember]
        public Int64 EmailLogId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public String SentTo;
        [DataMember]
        public String SentCc;
        [DataMember]
        public String EmailEvent;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public String Title;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Subject;
        [DataMember]
        public String Body;
    }

    #region ActivityLog
    public class ActivityLogInfo
    {
        public Int64 ActivityLogId { get; set; }
        public String AcitvityName { get; set; }
        public DateTime ActivityDate { get; set; }
        public Int32 UserId { get; set; }
        public Int64 OriginalReferenceId { get; set; }
        public Int64 ChangedReferenceId { get; set; }
        public String ActivityIP { get; set; }
        public String ActivityType { get; set; }
        public String TableName { get; set; }
    }
    #endregion

    #region ExpiryReport
    public class ExpiryReportInfo
    {
        public Int32 DocId { get; set; }
        public Int32 ContentTypeId { get; set; }
        public String ContentType { get; set; }
        public DateTime CreatedOn { get; set; }
        public String UserName { get; set; }
        public String Title { get; set; }
        public String ExpiryDate { get; set; }
        public Int32 NoOfDaysLeft { get; set; }
    }
    #endregion

    [DataContract]
    public class DocLogDetailsInfo
    {
        [DataMember]
        public Int64 DocLogId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 DocNo;
        [DataMember]
        public String Title;
        [DataMember]
        public String UserName;
        [DataMember]
        public String ChangedById;
        [DataMember]
        public String ChangedByName;
        [DataMember]
        public String ChangeField;
        [DataMember]
        public String FieldName;
        [DataMember]
        public String ValueBefore;
        [DataMember]
        public String ValueAfter;
        [DataMember]
        public DateTime ChangedOn;
    }

    [DataContract]
    public class UserBrandCategoryMappingInfo
    {
        [DataMember]
        public Int32 UserBrandCategoryMappingId;
        [DataMember]
        public Int32 BrandId;
        [DataMember]
        public String Brand;
        [DataMember]
        public Int32 CategoryId;
        [DataMember]
        public String Category;
        [DataMember]
        public String UserName;
        [DataMember]
        public String Name;
        [DataMember]
        public Int32 UserId;        
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }

    #region DocumentCategoryDetailInfo
    [DataContract]
    public class DocumentCategoryDetailInfo
    {
        [DataMember]
        public Int32 DocumentCategoryDetailId;
        [DataMember]
        public Int32 DocId;
        [DataMember]
        public Int32 CategoryId;
        [DataMember]
        public String CategoryName;
        [DataMember]
        public Boolean IsActive;
        [DataMember]
        public Int32 CreatedBy;
        [DataMember]
        public DateTime CreatedOn;
        [DataMember]
        public Int32 ModifiedBy;
        [DataMember]
        public DateTime ModifiedOn;
    }
    #endregion
}