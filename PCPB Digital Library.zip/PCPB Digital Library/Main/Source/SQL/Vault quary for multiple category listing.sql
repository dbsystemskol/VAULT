USE [VAULT]
GO

/****** Object:  View [dbo].[vGetRecentFiles]    Script Date: 01/13/2017 12:12:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[vGetRecentFiles]
AS


	SELECT t2.DocId,t2.SerialNo,
			 t2.FieldValue,t1.FieldCaption,
			t2.CreatedOn,t1.TeamId,t2.CreatedBy,t1.LibId,t1.FieldCategory,t1.FieldName,t2.ContentTypeId,t1.[Content Type]
	FROM
		(SELECT a.FieldId,a.FieldName,a.FieldCaption,a.FieldCategory,
				a.FieldType,b.ContentTypeId,b.AttributeType,d.TeamId,c.LibId,c.Description as [Content Type]
		FROM AttributeFields AS a
			INNER JOIN LibraryAttributeSet AS b
				ON a.FieldId = b.FieldId
			INNER JOIN ContentType AS c
				ON b.ContentTypeId = c.ContentTypeId
			INNER JOIN TeamInLibrary AS d
				ON d.LibId = c.LibId
		WHERE b.AttributeType IN ( 'Common','Other')
			 ) t1 
INNER JOIN
		(SELECT b.DocId,a.ContentTypeId,a.SerialNo,
		Convert(varchar(10),a.CreatedOn,105) CreatedOn,
		a.CreatedBy,
		b.FieldId,b.FieldValue 
		FROM  DocomentInfoMaster AS a
			INNER JOIN DocumentInfoDetail AS b
					ON a.DocId = b.DocId 
					Where a.IsActive=1 and b.FieldId <> 2
			union
		SELECT x.DocId,x.ContentTypeId,x.SerialNo,
		Convert(varchar(10),x.CreatedOn,105) CreatedOn,
		x.CreatedBy,
		2,dbo.fnGetDocCategory(x.DocId) FieldValue 
		FROM  DocomentInfoMaster AS x
					Where x.IsActive=1
					) t2
ON t1.ContentTypeId = t2.ContentTypeId
AND t1.FieldId = t2.FieldId

GO


CREATE FUNCTION dbo.fnGetDocCategory (@DocId int)
RETURNS VarChar(MAX)
AS BEGIN
Declare @NameList VarChar(MAX) = ''

select @NameList = 
    case when @NameList = ''
        then coalesce(CategoryName, '')
        else @NameList + coalesce(', ' + CategoryName, '')
    end
from (
select FieldValue as CategoryName from DocumentInfoDetail where DocId=@DocId and FieldId =2
union
select CategoryName from DocumentCategoryDetail where DocId = @DocId) as x

    RETURN @NameList
END

GO

USE [VAULT]
GO

/****** Object:  View [dbo].[vFreeTextSearch]    Script Date: 01/13/2017 12:29:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [dbo].[vFreeTextSearch]
AS
	SELECT t2.DocId,t2.SerialNo,
			 t2.FieldValue,t1.FieldCaption,
			t2.CreatedOn,t1.TeamId,t2.CreatedBy,t1.LibId,t2.Keywords,t1.ContentType,t1.FieldId,t1.FieldName,t2.ContentTypeId
			,t3.CategoryName
			
	FROM
		(SELECT a.FieldId,a.FieldName,a.FieldCaption,
				a.FieldType,b.ContentTypeId,b.AttributeType,d.TeamId,c.LibId,c.Description as ContentType
		FROM AttributeFields AS a
			INNER JOIN LibraryAttributeSet AS b
				ON a.FieldId = b.FieldId
			INNER JOIN ContentType AS c
				ON b.ContentTypeId = c.ContentTypeId
			INNER JOIN TeamInLibrary AS d
				ON d.LibId = c.LibId
			 ) t1 
INNER JOIN
		(SELECT b.DocId,a.ContentTypeId,a.SerialNo,
		Convert(varchar(10),a.CreatedOn,105) CreatedOn,
		a.CreatedBy,
		b.FieldId,b.FieldValue,a.Keywords
		FROM  DocomentInfoMaster AS a
			INNER JOIN DocumentInfoDetail AS b
					ON a.DocId = b.DocId
					Where a.IsActive=1 and b.FieldId <> 2
			union
		SELECT x.DocId,x.ContentTypeId,x.SerialNo,
		Convert(varchar(10),x.CreatedOn,105) CreatedOn,
		x.CreatedBy,
		2,dbo.fnGetDocCategory(x.DocId) FieldValue,x.Keywords
		FROM  DocomentInfoMaster AS x
					Where x.IsActive=1) t2
ON t1.ContentTypeId = t2.ContentTypeId
AND t1.FieldId = t2.FieldId

LEFT OUTER JOIN DocumentCategoryDetail as t3
ON t2.DocId = t3.DocId


GO


