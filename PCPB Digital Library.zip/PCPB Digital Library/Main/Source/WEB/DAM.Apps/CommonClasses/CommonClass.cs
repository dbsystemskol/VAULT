﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DAM.Apps.CommonClasses
{
    public class CommonClass
    {
        public int[] DecimalToBase(int iDec, int numbase)
        {
            int[] result = new int[4];
            int MaxBit = 4;
            for (; iDec > 0; iDec /= numbase)
            {
                int rem = iDec % numbase;
                result[--MaxBit] = rem;
            }
            return result;
        }

        public Int32 BinaryToInteger(String BinaryCode)
        {
            Int32 Result = 0;
            Result = Convert.ToInt32(BinaryCode, 2);
            return Result;
        }

        public Boolean ValidateExpiryDate(String ExpiryDate, Int32 DefaultValue)
        {
            Boolean IsValid = true;
            if (Convert.ToDateTime(ExpiryDate) <= System.DateTime.Now)
                IsValid = false;
            else if (Convert.ToDateTime(ExpiryDate) > System.DateTime.Now.AddDays(DefaultValue))
                IsValid = false;
            return IsValid;
        }

        public String DecimalToBinary(Int32 num)
        {
            String Result = String.Empty;
            Result = Convert.ToString(num, 2);
            Result = new string('0', 4 - Result.Length) + Result;
            return Result;
        }
    }
}