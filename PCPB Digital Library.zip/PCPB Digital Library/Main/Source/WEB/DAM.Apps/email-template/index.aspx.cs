﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Text;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;
using QueryStringEncryption;

namespace DAM.Apps.email_template
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                HeaderFieldName.InnerText = "Email Templates";
                //BindMenu(LibId);
                PopulateEmailTemplateList();
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-with-category/index.aspx'>Brand With Category</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void PopulateEmailTemplateList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvEmailTemplate.DataSource = obje.GetAllEmailTemplate();
                gdvEmailTemplate.DataBind();
                if (gdvEmailTemplate.Rows.Count > 0)
                    gdvEmailTemplate.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                //gdvEmailTemplate.DataSource = objDAM.GetDepartmentMasterSearch(Server.HtmlEncode(txtSearch.Value.Trim()));
                //gdvEmailTemplate.DataBind();
                //gdvEmailTemplate.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtTemplateName.Value = "";
            txtSubject.Value = "";
            txtBody.Value = "";
            hdnSelectedId.Value = "";
            popup.Show();
        }
        protected void gdvEmailTemplate_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();

                if (e.CommandName == "_Edit")
                {
                    Int32 RowTemplateId = Convert.ToInt32(e.CommandArgument);
                    gdvEmailTemplate.HeaderRow.TableSection = TableRowSection.TableHeader;
                    var mList = objDAM.GetAllEmailTemplateById(RowTemplateId);
                    hdnSelectedId.Value = mList[0].TemplateId.ToString();
                    txtTemplateName.Value = Server.HtmlDecode(mList[0].TemplateName);
                    txtSubject.Value = Server.HtmlDecode(mList[0].Subject);
                    txtBody.Value = Server.HtmlDecode(mList[0].Body);
                    popup.Show();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Int32 Returnval = 0;
            DAMServices.ServiceContractClient obje;
            try
            {
                    obje = new DAMServices.ServiceContractClient();
                    if (hdnSelectedId.Value == "")
                    {
                        Returnval = obje.InsertEmailTemplate(Server.HtmlEncode(txtTemplateName.Value), Server.HtmlEncode(txtSubject.Value), Server.HtmlEncode(txtBody.Value));
                        if (Returnval > 0)
                        {
                            PopulateEmailTemplateList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.DUPLICATE;
                        }
                    }
                    else
                    {
                        Returnval = obje.UpdateEmailTemplate(Convert.ToInt32(hdnSelectedId.Value),Server.HtmlEncode(txtTemplateName.Value), Server.HtmlEncode(txtSubject.Value), Server.HtmlEncode(txtBody.Value));
                        if (Returnval > 0)
                        {
                            PopulateEmailTemplateList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvEmailTemplate.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "EmailTemplate.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvEmailTemplate.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvEmailTemplate.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvEmailTemplate.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvEmailTemplate.HeaderRow.Cells.Count; i++)
                        gdvEmailTemplate.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvEmailTemplate.Columns.Count; i++)
                    {
                        if (gdvEmailTemplate.Columns[i].HeaderText == "Edit")
                            gdvEmailTemplate.Columns[i].Visible = false;
                    }
                    gdvEmailTemplate.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
    }
}