﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DAMServices.Configuration;
using QueryStringEncryption;

namespace DAMServices
{
    internal enum DataCommandType
    {
        Text = 1,
        StoredProcedure = 2
    }

    internal enum DataParameterDirection
    {
        Input = 1,
        Output = 2,
        ReturnValue = 3
    }

    internal class DataCommand : IDisposable
    {
        private static readonly ConfigHandler mCfg = (ConfigHandler)ConfigurationManager.GetSection("ITC.Data");

        private SqlConnection mConn = null;
        private SqlCommand mCmd = null;
        private SqlDataReader mReader = null;

        public DataCommand()
        {
            mConn = new SqlConnection(DecryptQueryString(this.Configuration.ConnectionString));
            mCmd = new SqlCommand();
        }

        private DatabaseElement Configuration
        {
            get
            {
                return mCfg.Database;
            }
        }

        public SqlConnection Connection
        {
            get
            {
                return mConn;
            }
        }

        public SqlCommand Command
        {
            get
            {
                return mCmd;
            }
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecrypt objEDQueryString = new EncryptDecrypt();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
        public DataCommandType CommandType { get; set; }

        public String CommandText { get; set; }

        public void ClearParameters()
        {
            mCmd.Parameters.Clear();
        }

        public void AddParameter(String name, SqlDbType type, DataParameterDirection direction, Int32 length, Object value)
        {
            SqlParameter mParam = new SqlParameter();

            mParam.ParameterName = name;
            mParam.SqlDbType = type;
            mParam.Size = length;
            mParam.Value = value;
            switch (direction)
            {
                case DataParameterDirection.Input:
                    mParam.Direction = ParameterDirection.Input; break;
                case DataParameterDirection.Output:
                    mParam.Direction = ParameterDirection.Output; break;
                case DataParameterDirection.ReturnValue:
                    mParam.Direction = ParameterDirection.ReturnValue; break;
            }

            mCmd.Parameters.Add(mParam);
        }

        public void AddParameter(String name, SqlDbType type, DataParameterDirection direction, Int32 length, Byte precision, Byte scale, Object value)
        {
            SqlParameter mParam = new SqlParameter();

            mParam.ParameterName = name;
            mParam.SqlDbType = type;
            mParam.Size = length;
            mParam.Precision = precision;
            mParam.Scale = scale;
            mParam.Value = value;
            switch (direction)
            {
                case DataParameterDirection.Input:
                    mParam.Direction = ParameterDirection.Input; break;
                case DataParameterDirection.Output:
                    mParam.Direction = ParameterDirection.Output; break;
                case DataParameterDirection.ReturnValue:
                    mParam.Direction = ParameterDirection.ReturnValue; break;
            }

            mCmd.Parameters.Add(mParam);
        }

        public void AddParameter(String name, SqlDbType type, DataParameterDirection direction, Int32 length, Byte precision, Byte scale)
        {
            SqlParameter mParam = new SqlParameter();

            mParam.ParameterName = name;
            mParam.SqlDbType = type;
            mParam.Size = length;
            mParam.Precision = precision;
            mParam.Scale = scale;
            switch (direction)
            {
                case DataParameterDirection.Input:
                    mParam.Direction = ParameterDirection.Input; break;
                case DataParameterDirection.Output:
                    mParam.Direction = ParameterDirection.Output; break;
                case DataParameterDirection.ReturnValue:
                    mParam.Direction = ParameterDirection.ReturnValue; break;
            }

            mCmd.Parameters.Add(mParam);
        }

        public void AddParameter(String name, SqlDbType type, DataParameterDirection direction, Int32 length)
        {
            SqlParameter mParam = new SqlParameter();

            mParam.ParameterName = name;
            mParam.SqlDbType = type;
            mParam.Size = length;
            switch (direction)
            {
                case DataParameterDirection.Input:
                    mParam.Direction = ParameterDirection.Input; break;
                case DataParameterDirection.Output:
                    mParam.Direction = ParameterDirection.Output; break;
                case DataParameterDirection.ReturnValue:
                    mParam.Direction = ParameterDirection.ReturnValue; break;
            }

            mCmd.Parameters.Add(mParam);
        }

        public void Open()
        {
            mConn.Open();
        }

        public void Close()
        {
            if (mReader != null)
            {
                if (!mReader.IsClosed)
                {
                    mReader.Close();
                }
            }
            if (mConn != null)
            {
                if (mConn.State == ConnectionState.Open)
                {
                    mConn.Close();
                } mConn = null;
            }
        }

        private bool PrepareQuery()
        {
            if (mConn.State != ConnectionState.Open)
            {
                this.Open();
            }

            if (this.CommandType == DataCommandType.Text)
            {
                mCmd.CommandType = System.Data.CommandType.Text;
            }
            else
            {
                mCmd.CommandType = System.Data.CommandType.StoredProcedure;
            }

            mCmd.CommandText = this.CommandText;
            mCmd.Connection = this.Connection;

            return true;
        }

        public void ExecuteNonQuery()
        {
            if (this.PrepareQuery())
            {
                mCmd.ExecuteNonQuery();
            }
        }

        public void ExecuteNonQuery(Boolean bInTransaction)
        {
            SqlTransaction mTrx = null;
            if (this.PrepareQuery())
            {
                // start transaction
                if (bInTransaction == true)
                {
                    mTrx = mConn.BeginTransaction(IsolationLevel.ReadCommitted);
                    mCmd.Transaction = mTrx;
                }
                try
                {
                    mCmd.ExecuteNonQuery();
                    if (mTrx != null)
                    {
                        mTrx.Commit();
                    }
                }
                catch (Exception ex)
                {
                    if (mTrx != null)
                    {
                        mTrx.Rollback();
                    } throw ex;
                }
            }
        }

        public Object ExecuteScaler()
        {
            Object _Val = null;
            if (this.PrepareQuery())
            {
                _Val = mCmd.ExecuteScalar();
            }
            return _Val;
        }

        public Object ExecuteScaler(Boolean bInTransaction)
        {
            Object mVal = null;
            SqlTransaction mTrx = null;

            if (this.PrepareQuery())
            {
                if (bInTransaction == true)
                {
                    mTrx = mConn.BeginTransaction(IsolationLevel.ReadCommitted);
                    mCmd.Transaction = mTrx;
                }

                try
                {
                    mVal = mCmd.ExecuteScalar();
                    if (mTrx != null)
                    {
                        mTrx.Commit();
                    }
                }
                catch (Exception ex)
                {
                    if (mTrx != null)
                    {
                        mTrx.Rollback();
                    } throw ex;
                }
            }

            return mVal;
        }

        public T ExecuteScaler<T>() where T : IConvertible
        {
            Object _Val = null;
            if (this.PrepareQuery())
            {
                _Val = mCmd.ExecuteScalar();
            }
            return (T)Convert.ChangeType(_Val, typeof(T));
        }

        public T ExecuteScaler<T>(Boolean bInTransaction) where T : IConvertible
        {
            Object mVal = null;
            SqlTransaction mTrx = null;

            if (this.PrepareQuery())
            {
                if (bInTransaction)
                {
                    mTrx = mConn.BeginTransaction(IsolationLevel.ReadCommitted);
                }

                try
                {
                    mVal = mCmd.ExecuteScalar();
                    if (mTrx != null)
                    {
                        mTrx.Commit();
                    }
                }
                catch (Exception ex)
                {
                    if (mTrx != null)
                    {
                        mTrx.Rollback();
                    } throw ex;
                }
            }

            return (T)Convert.ChangeType(mVal, typeof(T));
        }

        public void ExecuteReader()
        {
            if (mReader != null)
            {
                mReader.Dispose(); mReader = null;
            }
            if (this.PrepareQuery())
            {
                mReader = mCmd.ExecuteReader();
            }
        }

        public SqlDataReader ExecuteReaderWithSqlReader()
        {
            if (mReader != null)
            {
                mReader.Dispose(); mReader = null;
            }
            if (this.PrepareQuery())
            {
                mReader = mCmd.ExecuteReader();
            }
            return mReader;
        }
        // indexer
        public SqlParameter this[Int32 id]
        {
            get
            {
                return mCmd.Parameters[id];
            }
        }

        // indexer (overload)
        public SqlParameter this[String name]
        {
            get
            {
                return mCmd.Parameters[name];
            }
        }

        public T GetParameterValue<T>(Int32 id) where T : IConvertible
        {
            try
            {
                return (T)Convert.ChangeType(this[id].Value, typeof(T));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public T GetParameterValue<T>(String name) where T : IConvertible
        {
            SqlParameter mParam = this[name];
            try
            {
                return (T)Convert.ChangeType(mParam.Value, typeof(T));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public Boolean ReadNext()
        {
            Boolean b = false;
            if (mReader != null)
            {
                b = mReader.Read();
                if (b == false)
                {
                    mReader.Close();
                }
            } return b;
        }

        public T GetFieldValue<T>(String name) where T : IConvertible
        {
            Object val = null;
            if (typeof(T) == typeof(Double))
            {
                val = mReader.GetDouble(mReader.GetOrdinal(name));
            }
            else
            {
                try
                {
                    val = (T)Convert.ChangeType(mReader[name], typeof(T));
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return (T)val;
        }

        public T GetFieldValue<T>(String name, T defaultValue) where T : IConvertible
        {
            try
            {
                return (T)Convert.ChangeType(mReader[name], typeof(T));
            }
            catch
            {
                return defaultValue;
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (mReader != null)
            {
                mReader.Dispose(); mReader = null;
            }
            if (mCmd != null)
            {
                mCmd.Dispose(); mCmd = null;
            }
            if (mConn != null)
            {
                if (mConn.State != ConnectionState.Closed)
                    mConn.Close();
                mConn.Dispose(); mConn = null;
            }
        }

        #endregion
    }
}
