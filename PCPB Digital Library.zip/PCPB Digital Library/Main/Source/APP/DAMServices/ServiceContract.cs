﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Data;

namespace DAMServices
{
    [ServiceContract]
    public interface IServiceContract
    {
        #region FileExtensionMaster
        [OperationContract]
        List<FileExtensionInfo> GetAllFileExtension();

        [OperationContract]
        Int32 InsertFileExtensionMaster(FileExtensionInfo mData);

        [OperationContract]
        Int32 UpdateFileExtensionMaster(FileExtensionInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateFileExtensionMaster(FileExtensionInfo mData);

        [OperationContract]
        List<FileExtensionInfo> GetAllActiveFileExtensionMaster();

        [OperationContract]
        List<FileExtensionInfo> GetFileExtensionMasterById(Int32 FileExtensionId);

        [OperationContract]
        List<FileExtensionInfo> GetFileExtensionMasterSearch(String FileExtensionName);
        #endregion

        [OperationContract]
        List<LibraryMasterInfo> GetAllLibraryMaster();

        [OperationContract]
        List<LibraryMasterInfo> GetLibraryMasterById(Int32 LibId);

        [OperationContract]
        List<TeamMasterInfo> GetAllTeamMaster();

        [OperationContract]
        List<TeamMasterInfo> GetTeamMasterById(Int32 TeamId);

        [OperationContract]
        List<ContentTypeInfo> GetContentTypeByLibId(Int32 LibId);

        [OperationContract]
        List<ContentTypeInfo> GetContentTypeById(Int32 ContentTypeId);

        [OperationContract]
        List<LibraryAttributeSetInfo> GetLibraryAttributeSetByContentTypeId(Int32 ContentTypeId);

        [OperationContract]
        List<LookupMasterInfo> GetLookupMasterByFieldId(Int32 FieldId, Int32 LibId);

        [OperationContract]
        Int32[] InsertFileMaster(FileInfo mFileMaster, FileVersionInfo mFileVersion, DocomentMasterInfo mDocMaster, String strDocDetails, String strFileLinks, Int32 TeamId, Int32 LibId, String NotificationType);

        [OperationContract]
        DashboardNewFiles GetDashboardNewFiles(String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped);

        [OperationContract]
        DashboardRecentFiles GetDashboardRecentFiles(String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped);

        [OperationContract]
        FreeTextSearchFiles GetFreeTextSearchFiles(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped);

        [OperationContract]
        FreeTextSearchFiles GetFreeTextSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped);

        [OperationContract]
        List<FileInfo> GetFileInfoById(Int32 FileInfoId);

        [OperationContract]
        List<DocumentDetailInfo> GetFileDocumentDetailsByDocId(Int32 DocId);

        [OperationContract]
        LinkedFile GetLinkedFiles(Int32 DocId, Int32 LibId);

        [OperationContract]
        LinkedFile GetLinkedFilesForUpdate(Int32 DocId, Int32 LibId);

        [OperationContract]
        List<FileExtensionInfo> GetPreviewImageByFileExtension(String FileExtension);

        #region UserMaster
        [OperationContract]
        Int32 InsertUserMaster(UserMasterInfo mData);

        [OperationContract]
        Int32 UpdateUserMaster(UserMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateUserMaster(UserMasterInfo mData);

        [OperationContract]
        List<UserMasterInfo> GetAllUserMaster(String LoginUserTeam);

        [OperationContract]
        List<UserMasterInfo> GetAllActiveUserMaster();

        [OperationContract]
        List<UserMasterInfo> GetUserMasterById(Int32 UserId);

        [OperationContract]
        List<UserMasterInfo> GetUserMasterSearch(String UserName, String LoginUserTeam);
        #endregion

        [OperationContract]
        List<FileVersionInfo> GetFileVersionByDocId(Int32 DocId);

        [OperationContract]
        Int32 InsertFileVersion(FileInfo mFileMaster, DocumentInFileInfo mDocumentInFile, FileVersionInfo mFileVersion);

        [OperationContract]
        Int32 DocumentInfoDetailUpdate(String strDocDetails);

        #region TeamMaster
        [OperationContract]
        Int32 InsertTeamMaster(TeamMasterInfo mData);

        [OperationContract]
        Int32 UpdateTeamMaster(TeamMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateTeamMaster(TeamMasterInfo mData);

        [OperationContract]
        List<TeamMasterInfo> GetAllActiveTeamMaster();

        [OperationContract]
        List<TeamMasterInfo> GetTeamMasterSearch(String TeamName);
        #endregion

        #region PrivilegeMaster
        [OperationContract]
        Int32 InsertPrivilegeMaster(PrivilegeMasterInfo mData);

        [OperationContract]
        Int32 UpdatePrivilegeMaster(PrivilegeMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivatePrivilegeMaster(PrivilegeMasterInfo mData);

        [OperationContract]
        List<PrivilegeMasterInfo> GetAllPrivilegeMaster();

        [OperationContract]
        List<PrivilegeMasterInfo> GetAllActivePrivilegeMaster();

        [OperationContract]
        List<PrivilegeMasterInfo> GetPrivilegeMasterById(Int32 PrivilegeId);

        [OperationContract]
        List<PrivilegeMasterInfo> GetPrivilegeMasterSearch(String PrivilegeName);
        #endregion

        #region UserInTeam
        [OperationContract]
        List<UserInTeamInfo> GetTeamMasterUserList(Int32 TeamId);

        [OperationContract]
        List<UserInTeamInfo> GetUserListNotInParticularTeam(Int32 TeamId);

        [OperationContract]
        void InsertUserInTeam(String UsrTmDtl);

        [OperationContract]
        Int32 ActivateDeactivateUserInTeam(UserInTeamInfo mData);
        #endregion

        #region AttributeMaster
        [OperationContract]
        Int32 InsertAttributeMaster(AttributeFieldsInfo mData);

        [OperationContract]
        Int32 UpdateAttributeMaster(AttributeFieldsInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateAttributeMaster(AttributeFieldsInfo mData);

        [OperationContract]
        List<AttributeFieldsInfo> GetAllAttributeMaster();

        [OperationContract]
        List<AttributeFieldsInfo> GetAllActiveAttributeMaster();

        [OperationContract]
        List<AttributeFieldsInfo> GetAttributeMasterById(Int32 AttributeId);

        [OperationContract]
        List<AttributeFieldsInfo> GetAttributeMasterSearch(String AttributeName);
        #endregion

        #region LookupMaster
        [OperationContract]
        List<LookupMasterInfo> GetAttributeMasterLookupList(Int32 FieldId);

        [OperationContract]
        List<LibraryMasterInfo> GetAllActiveLibraryMaster();

        [OperationContract]
        List<AttributeFieldsInfo> GetAllActiveListTypeAttributeMaster();

        [OperationContract]
        Int32 InsertLookupMaster(LookupMasterInfo mData);

        [OperationContract]
        Int32 UpdateLookupMaster(LookupMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateLookupMaster(LookupMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateLookupMasterAll(LookupMasterInfo mData);

        [OperationContract]
        List<LookupMasterInfo> GetLookupMasterById(Int32 LookupId);
        #endregion

        #region TeamInPrivilege
        [OperationContract]
        List<TeamInPrivilegeInfo> GetAllActiveTeamInPrivilege(Int32 ContentTypeId);

        [OperationContract]
        List<TeamInPrivilegeInfo> GetAllTeamMasterRowsNotInTeamInPrivilegeServ();

        [OperationContract]
        List<TeamInPrivilegeInfo> GetAllPrivilegeMasterRowsNotInTeamInPrivilegeServ(Int32 ContentTypeId, Int32 TeamId);

        [OperationContract]
        void InsertTeamInPrivilege(String TmPrvDtl);
        #endregion
        [OperationContract]
        Int32 UpdateFileVersion(Int32 DocId, Int32 FileInfoId, Int32 ModifiedBy);

        [OperationContract]
        Int32 UpdateDocomentInfoMaster(Int32 DocId, String Keywords, Int32 ModifiedBy, String IPAddress);

        [OperationContract]
        Int32 DeactivateFileLinkDetail(Int32 DocId);

        [OperationContract]
        Int32 UpdateFileLinkDetail(Int32 DocId, String strFileLinks, String IPAddress);

        [OperationContract]
        Int32 InsertUserLoginHistory(Int32 UserId);

        [OperationContract]
        List<LibraryMasterInfo> GetLibraryMasterByUserId(Int32 UserId, Int32 TeamId);

        [OperationContract]
        List<UserMasterInfo> GetUserMasterByUserName(String UserName);

        [OperationContract]
        List<TeamMasterInfo> GetTeamMasterByUserId(Int32 UserId);

        [OperationContract]
        Int32 AddRemoveFavourite(Int32 DocId, Boolean IsFavourite, Int32 CreatedBy);

        [OperationContract]
        List<FavouriteDocumentInfo> GetFavouriteDocumentByDocId(Int32 DocId, Int32 CreatedBy);

        [OperationContract]
        FavouriteDocumentList GetFavouriteDocumentByUserId(Int32 LibraryId, Int32 UserId);

        [OperationContract]
        Int32 UpdateFavouriteDocument(String strFavList);

        [OperationContract]
        List<LookupMasterInfo> GetAllActiveAttributeMasterLookupList();

        [OperationContract]
        List<UserInTeamInfo> GetAllActiveTeamMasterUserList();

        [OperationContract]
        List<LibraryMasterInfo> GetLibraryMasterSearch(String LibraryName);

        [OperationContract]
        List<LibraryMasterInfo> GetLibraryMasterRowDetailsById(Int32 LibId, Int32 ContentTypeId);

        [OperationContract]
        List<FileExtensionInfo> GetFileExtensionMasterByExtension(String FileExtension);

        [OperationContract]
        Int32 ActivateDeactivateLibraryMaster(LibraryMasterInfo mData);

        [OperationContract]
        List<LibraryMasterInfo> GetAllLibraryMasterContentType();

        [OperationContract]
        Int32 InsertLibraryMaster(LibraryMasterInfo lMaster, ContentTypeInfo cType, String laSet);

        [OperationContract]
        List<ContentTypeInfo> GetContentTypeAutoComplete(String Description);

        [OperationContract]
        List<AttributeFieldsInfo> GetAllActiveAttributeMasterForLibrary();

        [OperationContract]
        List<TeamInPrivilegeInfo> GetTeamInPrivilegeByTeamId(Int32 TeamId, Int32 LibId);

        [OperationContract]
        FreeTextSearchFiles AdvanceSearch(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped);

        [OperationContract]
        void InsertTeamInLibraryMaster(String UsrTmDtl);

        [OperationContract]
        List<TeamInLibraryInfo> GetAllActiveTeamInLibrary();

        [OperationContract]
        FreeTextSearchFiles AdvanceSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped);

        [OperationContract]
        List<UserNotificationInfo> GetUserNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId);

        [OperationContract]
        List<TeamInPrivilegeInfo> GetTeamInPrivilegePrivilegeAllTeamId(Int32 TeamId, Int32 LibId, Int32 ContentTypeId);

        [OperationContract]
        Int32 InsertUserNotification(Int32 UserId, Int32 TeamId, Int32 DocId, Int32 LibId, String NotificationType);

        [OperationContract]
        FreeTextSearchFiles UserNotificationList(Int32 LibId, Int32 UserId, String NotificationType);

        [OperationContract]
        Int32 UpdateUserNotification(Int32 UserId, Int32 TeamId, Int32 LibId, String NotificationType);

        [OperationContract]
        List<TeamInLibraryInfo> GetAllTeamInLibrary();

        [OperationContract]
        Int32 ActivateDeactivateTeamInLibrary(TeamInLibraryInfo mObj);

        [OperationContract]
        List<TeamInLibraryInfo> GetTeamInLibrarySearch(String SearchString);

        [OperationContract]
        List<UserInTeamInfo> GetAllUserInTeamList(String SearchString);

        [OperationContract]
        List<TeamMasterInfo> GetAllTeamNotInLibraryById(Int32 LibId);

        [OperationContract]
        List<LookupMasterInfo> GetAttributeMasterLookupListSearch(String SearchString);

        [OperationContract]
        Int32 InsertSaveSearch(SaveSearchInfo mObj);

        [OperationContract]
        List<SaveSearchInfo> GetSaveSearch(Int32 UserId, Int32 LibId, Int32 TeamId);

        [OperationContract]
        List<LabelMasterInfo> GetLabelByUserId(Int32 UserId);

        [OperationContract]
        Int32 InsertLabelMaster(String Label, Int32 UserId);

        [OperationContract]
        Int32 DeleteSaveSearch(Int32 SaveSearchId);

        [OperationContract]
        Int32 DeleteFile(Int32 FileInfoId, Int32 UserId);

        #region LocationMaster
        [OperationContract]
        List<LocationMasterInfo> GetAllLocationMaster();

        [OperationContract]
        Int32 InsertLocationMaster(LocationMasterInfo mData);

        [OperationContract]
        Int32 UpdateLocationMaster(LocationMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateLocationMaster(LocationMasterInfo mData);

        [OperationContract]
        List<LocationMasterInfo> GetAllActiveLocationMaster();

        [OperationContract]
        List<LocationMasterInfo> GetLocationMasterById(Int32 LocationId);

        [OperationContract]
        List<LocationMasterInfo> GetLocationMasterSearch(String Location);
        #endregion

        #region DesignationMaster
        [OperationContract]
        List<DesignationMasterInfo> GetAllDesignationMaster();

        [OperationContract]
        Int32 InsertDesignationMaster(DesignationMasterInfo mData);

        [OperationContract]
        Int32 UpdateDesignationMaster(DesignationMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateDesignationMaster(DesignationMasterInfo mData);

        [OperationContract]
        List<DesignationMasterInfo> GetAllActiveDesignationMaster();

        [OperationContract]
        List<DesignationMasterInfo> GetDesignationMasterById(Int32 DesignationId);

        [OperationContract]
        List<DesignationMasterInfo> GetDesignationMasterSearch(String Designation);
        #endregion

        #region DepartmentMaster
        [OperationContract]
        List<DepartmentMasterInfo> GetAllDepartmentMaster();

        [OperationContract]
        Int32 InsertDepartmentMaster(DepartmentMasterInfo mData);

        [OperationContract]
        Int32 UpdateDepartmentMaster(DepartmentMasterInfo mData);

        [OperationContract]
        Int32 ActivateDeactivateDepartmentMaster(DepartmentMasterInfo mData);

        [OperationContract]
        List<DepartmentMasterInfo> GetAllActiveDepartmentMaster();

        [OperationContract]
        List<DepartmentMasterInfo> GetDepartmentMasterById(Int32 DepartmentId);

        [OperationContract]
        List<DepartmentMasterInfo> GetDepartmentMasterSearch(String Department);
        #endregion

        [OperationContract]
        Int32 ActivateDeactivateAttributeMasterAll(AttributeFieldsInfo mData);

        [OperationContract]
        Int32 InsertFileMasterNew(String strFileMaster,
                                      FileVersionInfo mFileVersion,
                                      DocomentMasterInfo mDocMaster,
                                      String strDocDetails,
                                      String strFileLinks, String strCategory, Int32 TeamId, Int32 LibId, String NotificationType, String IPAddress);

        [OperationContract]
        List<FileInfo> GetFileInfoByDocId(Int32 DocId);

        [OperationContract]
        List<DocomentMasterInfo> GetContentTypeIdByDocId(Int32 DocId);

        #region EmailSettingsMaster
        [OperationContract]
        List<EmailSettingsInfo> GetAllEmailSettingsMaster(Int32 TeamId);

        [OperationContract]
        void InsertEmailSettingsMaster(String EmSetDtl, Int32 TeamId);

        [OperationContract]
        List<EmailSettingsInfo> GetEmailSettingsMasterSearch(String SearchText);
        #endregion

        [OperationContract]
        Int32 DeleteDocFile(Int32 FileInfoId, Int32 UserId, String IPAddress);

        [OperationContract]
        Int32 InsertFileToDocument(FileInfo mFileMaster, Int32 DocId);

        [OperationContract]
        List<DocSerialNoInfo> GetNextSerialNoByLibId(Int32 LibId);

        [OperationContract]
        List<ContentTypeInfo> GetContentTypeNotInTeamPrivilegeByLibId(Int32 TeamId, Int32 LibId);

        [OperationContract]
        Int32 InsertEmailTemplate(String TemplateName, String Subject, String Body);

        [OperationContract]
        Int32 UpdateEmailTemplate(Int32 TemplateId, String TemplateName, String Subject, String Body);

        [OperationContract]
        List<EmailTemplateInfo> GetAllEmailTemplate();

        [OperationContract]
        List<EmailTemplateInfo> GetAllEmailTemplateById(Int32 TemplateId);

        [OperationContract]
        List<ContentTypeMasterInfo> GetContentTypeMaster();

        [OperationContract]
        Int32 InsertEventMaster(String EventName, Int32 CreatedBy);

        [OperationContract]
        Int32 UpdateEventMaster(Int32 EventId, String EventName, Int32 ModifiedBy);

        [OperationContract]
        Int32 ActivateDeactivateEventMaster(Int32 EventId, Boolean IsActive, Int32 ModifiedBy);

        [OperationContract]
        List<EventMasterInfo> GetAllActiveEventMaster();

        [OperationContract]
        List<EventMasterInfo> GetAllEventMaster();

        [OperationContract]
        List<EventMasterInfo> GetAllEventMasterById(Int32 EventId);

        [OperationContract]
        List<EventMasterInfo> SearchEvent(String SearchText);

        [OperationContract]
        Int32 InsertEventInTemplate(Int32 EventId, Int32 TemplateId, Int32 LibId, Int32 CreatedBy);

        [OperationContract]
        List<EventInTemplateInfo> GetAllActiveEventInTemplate();

        [OperationContract]
        List<EventInTemplateInfo> GetAllEventInTemplate();

        [OperationContract]
        List<EventInTemplateInfo> GetEventInTemplateSearch(Int32 LibId, String SearchText);

        [OperationContract]
        Int32 ActivateDeactivateEventInTemplate(Int32 EventInTemplateId, Boolean IsActive, Int32 ModifiedBy);


        [OperationContract]
        void InsertEventObjectMapping(String UsrTmDtl);

        [OperationContract]
        List<EventObjectMappingInfo> GetAllActiveEventObjectMapping();

        [OperationContract]
        List<EventObjectMappingInfo> GetAllEventObjectMapping();

        [OperationContract]
        List<EventObjectMappingInfo> GetEventObjectMappingSearch(String SearchString);

        [OperationContract]
        Int32 ActivateDeactivateEventObjectMapping(Int32 EventObjectId, Boolean IsActive, Int32 ModifiedBy);

        [OperationContract]
        Int32 InsertEventTrigger(Int32 EventId, Int32 Duration, Int32 CreatedBy);

        [OperationContract]
        Int32 UpdateEventTrigger(Int32 EventTriggerId, Int32 EventId, Int32 Duration, Int32 ModifiedBy);

        [OperationContract]
        Int32 ActivateDeactivateEventTrigger(Int32 EventTriggerId, Boolean IsActive, Int32 ModifiedBy);

        [OperationContract]
        List<EventTriggerInfo> GetAllActiveEventTrigger();

        [OperationContract]
        List<EventTriggerInfo> GetAllEventTrigger();

        [OperationContract]
        List<EventTriggerInfo> GetAllEventTriggerById(Int32 EventTriggerId);

        [OperationContract]
        List<EventTriggerInfo> SearchEventTrigger(String SearchText);

        [OperationContract]
        List<TemplateFieldMappingInfo> GetAllTemplateFieldMapping();

        [OperationContract]
        List<EventObjectMappingInfo> GetEventObjectMappingByEventId(Int32 EventId);

        [OperationContract]
        List<ExpiryMailInfo> GetOnExpiryDocumentList(String CurrentDate);

        [OperationContract]
        List<ExpiryMailInfo> GetOn30DaysExpiryDocumentList(String CurrentDate);

        [OperationContract]
        List<DocumentDetailInfo> GetUpdatedDocumentDetails(Int32 DocId);

        [OperationContract]
        Int32 UpdateDocumentInfoDetailClone(Int32 DocId);

        [OperationContract]
        List<BrandCategoryMappingInfo> GetBrandCategoryMapping(Int32 BrandId, Int32 CategoryId);

        [OperationContract]
        List<BrandCategoryMappingInfo> GetUserNotInBrandCategory(Int32 BrandId, Int32 CategoryId);

        [OperationContract]
        void InsertBrandCategoryMapping(String brndCatgDtl);

        [OperationContract]
        Int32 ActivateDeactivateBrandCategoryMapping(BrandCategoryMappingInfo mObj);

        [OperationContract]
        List<BrandCategoryMappingInfo> GetAllBrandCategoryMapping();

        [OperationContract]
        List<BrandCategoryMappingInfo> BrandCategoryMappingInfoSearch(String SearchString);

        [OperationContract]
        List<BrandCategoryMappingInfo> GetUserEmailByDocId(Int32 DocId);

        [OperationContract]
        List<LibraryAttributeSetInfo> GetLibraryAttributeSetByLibId(Int32 LibId);

        [OperationContract]
        Int32 InsertEmailLog(EmailLogInfo mObj);

        [OperationContract]
        List<DocumentDetailInfo> GetUpdatedDocumentDetailsForMail(Int32 DocId);

        [OperationContract]
        List<EmailLogInfo> EmailLogSearch(String EmailEvent, String FromDate, String ToDate);

        [OperationContract]
        void InsertLookupMasterOther(String details);

        [OperationContract]
        List<LookupMasterInfo> GetAllOthersValue();

        [OperationContract]
        List<ActivityLogInfo> GetActivityInfo(Int32 UserId, DateTime FromDate, DateTime ToDate);

        [OperationContract]
        String GetActivityDetail(Int64 ReferenceId, Boolean IsOriginal, String TableName);

        [OperationContract]
        List<ExpiryReportInfo> ExpiryReport(String FromDate, String ToDate);

        [OperationContract]
        List<EmailLogInfo> EmailLogById(Int32 EmailLogId);

        [OperationContract]
        Int32 UpdateBrandCategoryMapping(BrandCategoryMappingInfo mObj);

        [OperationContract]
        Int32 UpdateUserLogoutHistory(Int32 UserId);

        [OperationContract]
        List<DocLogDetailsInfo> DocLogDetailsSearch(String FromDate, String ToDate);


        /// <summary>
        /// New Added
        /// </summary>
        /// <returns></returns>
        
        [OperationContract]
        List<UserBrandCategoryMappingInfo> GetUserForBrandCategoryMapping();
        [OperationContract]
        List<UserBrandCategoryMappingInfo> GetUserBrandCategoryMappingByUserId(Int32 UserId);
        [OperationContract]
        Int32 ActivateDeactivateUserBrandCategoryMapping(UserBrandCategoryMappingInfo mObj);
        [OperationContract]
        void InsertUserBrandCategoryMapping(String brndCatgDtl);
        [OperationContract]
        List<UserBrandCategoryMappingInfo> GetAllUserBrandCategoryMapping();
        [OperationContract]
        List<UserBrandCategoryMappingInfo> UserBrandCategoryMappingSearch(String SearchString);

        [OperationContract]
        List<LookupMasterInfo> GetUserBrandCategoryByFieldId(Int32 FieldId, Int32 UserId);


        #region "Content Type"

        [OperationContract]
        List<ContentTypeMasterInfo> GetAllContentType();

        [OperationContract]
        List<ContentTypeMasterInfo> GetContentTypeSearch(String ContentType);

        [OperationContract]
        Int32 InsertContentType(ContentTypeMasterInfo mObj);

        [OperationContract]
        Int32 UpdateContentType(ContentTypeMasterInfo mObj);

        [OperationContract]
        List<ContentTypeMasterInfo> GetContentTypeMasterById(Int32 ContentTypeId);

        [OperationContract]
        Int32 ActivateDeactivateContentType(ContentTypeMasterInfo mObj);

        #endregion

        ///
        [OperationContract]
        List<BrandCategoryMappingInfo> GetCategoryByBrandId(Int32 BrandId);

        [OperationContract]
        List<BrandCategoryMappingInfo> GetAllBrandWithCategoryMapping();

        [OperationContract]
        List<BrandCategoryMappingInfo> BrandCategoryMappingSearch(String SearchString);

        [OperationContract]
        Int32 ActivateDeactivateBrandWithCategoryMapping(BrandCategoryMappingInfo mObj);

         [OperationContract]
        List<BrandCategoryMappingInfo> GetBrandCategoryMappingByBrandId(Int32 BrandId);

        [OperationContract]
         void BrandCategoryMappingInsert(String brndCatgDtl);

        [OperationContract]
        Int32 DeactivateAllDocumentCategory(Int32 DocId);

        [OperationContract]
        Int32 DocumentCategoryDetailUpdate(String strDocCategory);

        [OperationContract]
        List<DocumentCategoryDetailInfo> GetDocumentCategoryDetailByDocId(Int32 DocId);

         [OperationContract]
        FreeTextSearchFiles GetMarketResearchFiles(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 TeamId, Int32 UserId, Boolean BrandCategoryFlag);
    }
}