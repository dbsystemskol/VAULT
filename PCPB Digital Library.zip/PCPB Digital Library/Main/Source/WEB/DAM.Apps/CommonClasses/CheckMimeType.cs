﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.InteropServices;
using System.IO;

namespace DAM.Apps.CommonClasses
{
    public class CheckMimeType
    {
        private static CheckMimeType _settings = null;

        [DllImport("urlmon.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = false)]
        static extern int FindMimeFromData(IntPtr pBC,
            [MarshalAs(UnmanagedType.LPWStr)] string pwzUrl,
            [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.I1, SizeParamIndex = 3)] byte[] pBuffer,
            int cbSize,
            [MarshalAs(UnmanagedType.LPWStr)] string pwzMimeProposed,
            int dwMimeFlags, out IntPtr ppwzMimeOut, int dwReserved);

        public static string getMimeFromFile(HttpPostedFile file)
        {
            IntPtr mimeout;

            int MaxContent = (int)file.ContentLength;
            if (MaxContent > 4096) MaxContent = 4096;

            byte[] buf = new byte[MaxContent];
            file.InputStream.Read(buf, 0, MaxContent);
            int result = FindMimeFromData(IntPtr.Zero, file.FileName, buf, MaxContent, null, 0, out mimeout, 0);

            if (result != 0)
            {
                Marshal.FreeCoTaskMem(mimeout);
                return "";
            }

            string mime = Marshal.PtrToStringUni(mimeout);
            Marshal.FreeCoTaskMem(mimeout);

            return mime.ToLower();
        }

        public static bool IsValidExtension(string ext)
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            var mList = objDAM.GetAllFileExtension();
            var validList = mList.Where(x => x.IsActive == true).ToList();
            var isvalid = validList.Where(x => "." + x.FileExtension.ToLower() == ext.ToLower());
            if (isvalid.Count() > 0)
                return true;
            else
                return false;
        }

        public static bool CheckExe(string contantType)
        {
            if (contantType == "application/x-msdownload")
            {

                return false;
            }
            else
                return true;
        }

        public static List<MimeType> PopulateMimeType()
        {
            List<MimeType> mList = new List<MimeType>();
            mList.Add(new MimeType
            {
                ext = ".doc",
                mimeType = "application/msword"
            });
            mList.Add(new MimeType
            {
                ext = ".docx",
                mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            });
            mList.Add(new MimeType
            {
                ext = ".pdf",
                mimeType = "application/pdf"
            });
            mList.Add(new MimeType
            {
                ext = ".zip",
                mimeType = "application/x-zip-compressed"
            });
            mList.Add(new MimeType
            {
                ext = ".xls",
                mimeType = "application/vnd.ms-excel"
            });
            mList.Add(new MimeType
            {
                ext = ".xlsx",
                mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            });
            mList.Add(new MimeType
            {
                ext = ".txt",
                mimeType = "text/plain"
            });
            mList.Add(new MimeType
            {
                ext = ".png",
                mimeType = "image/png"
            });
            mList.Add(new MimeType
            {
                ext = ".jpeg",
                mimeType = "image/jpeg"
            });

            return mList;
        }
        public static CheckMimeType filetype
        {
            get
            {
                if (_settings == null)
                {
                    _settings = new CheckMimeType();
                }
                return _settings;
            }
        }
        public string GetValue()
        {
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            var mList = objDAM.GetAllFileExtension();
            var valid = mList.Where(x => x.IsActive == true).ToList();
            string value = "";
            for (int i = 0; i < valid.Count(); i++)
            {
                if (i == valid.Count() - 1)
                    value = value + valid[i].FileExtension + " )";
                else if (i == 0)
                    value = "( " + valid[i].FileExtension + " , ";
                else
                    value = value + valid[i].FileExtension + " , ";
            }
            return value;
        }
        public String ValidExtensions { get { return GetValue() ?? String.Empty; } }
    }
    public class MimeType
    {
        public String ext { get; set; }
        public String mimeType { get; set; }
    }
}