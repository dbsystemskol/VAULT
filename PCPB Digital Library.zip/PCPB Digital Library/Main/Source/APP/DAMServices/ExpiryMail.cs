﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class ExpiryMail
    {
        protected static ILog log = LogManager.GetLogger(typeof(ExpiryMail));

        public List<ExpiryMailInfo> GetOnExpiryDocumentList(String CurrentDate)
        {
            List<ExpiryMailInfo> mList = new List<ExpiryMailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetOnExpiryDocuments";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@CurrentDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, CurrentDate);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ExpiryMailInfo
                        {
                            DocId = mCmd.GetFieldValue<Int32>("DocId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<ExpiryMailInfo> GetOn30DaysExpiryDocumentList(String CurrentDate)
        {
            List<ExpiryMailInfo> mList = new List<ExpiryMailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetOn30DayExpiryDocuments";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@CurrentDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, CurrentDate);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ExpiryMailInfo
                        {
                            DocId = mCmd.GetFieldValue<Int32>("DocId"),
                            LibName = mCmd.GetFieldValue<String>("LibName"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }


    }
}
