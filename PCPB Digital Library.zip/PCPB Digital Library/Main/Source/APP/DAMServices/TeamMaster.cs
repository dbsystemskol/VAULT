﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class TeamMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(TeamMaster));

        public List<TeamMasterInfo> GetAllTeamMaster()
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamMasterInfo> GetTeamMasterById(Int32 TeamId)
        {
            List<TeamMasterInfo> mList = new List<TeamMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamMasterById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamMasterInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
