﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using System.Text;
using DAM.Apps.CommonClasses;
using QueryStringEncryption;
using System.Web.Configuration;

namespace DAM.Apps.team_in_privilege
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateLibraryListDropDown();
                PopulateContentTypeByLibraryListDropDown();
                PopulateTeamInPrivilegeList();
                String encURL = "";
                encURL = Request.RawUrl;
                if (encURL.Contains("?"))
                {
                    encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                    if (!encURL.Equals(""))
                    {
                        encURL = DecryptQueryString(encURL);
                        String[] editInfo = encURL.Split('|');
                        String[] TeamId = editInfo[0].Split('=');
                        String[] TeamName = editInfo[1].Split('=');

                        String[] LibId = editInfo[2].Split('=');
                        String[] LibName = editInfo[3].Split('=');
                        String[] ContentTypeId = editInfo[4].Split('=');
                        String[] Description = editInfo[5].Split('=');
                        String[] IsBrandCategoryMapped = editInfo[6].Split('=');

                        hdnTeamId.Value = TeamId[1];
                        lblTeamName.InnerText = Server.HtmlDecode(TeamName[1]);

                        hdnLibId.Value = LibId[1];
                        lblLibraryName.InnerText = Server.HtmlDecode(LibName[1]);

                        hdnContentTypeId.Value = ContentTypeId[1];
                        lblContentType.InnerText = Server.HtmlDecode(Description[1]);

                        chkIsBrandCategoryEdit.Checked = Convert.ToBoolean(IsBrandCategoryMapped[1]);
                        populateteamInPrivilegeByTteamId(Convert.ToInt32(hdnTeamId.Value), Convert.ToInt32(hdnLibId.Value), Convert.ToInt32(hdnContentTypeId.Value));
                        popupEdit.Show();
                    }
                }
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }

        protected void PopulateLibraryListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibraryList.DataSource = objDAM.GetAllActiveLibraryMaster();
                ddlLibraryList.DataValueField = "LibId";
                ddlLibraryList.DataTextField = "LibName";
                ddlLibraryList.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateContentTypeByLibraryListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                if (ddlLibraryList.SelectedValue != "")
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    ddlContentType.DataSource = objDAM.GetContentTypeByLibId(Convert.ToInt32(ddlLibraryList.SelectedValue));
                    ddlContentType.DataValueField = "ContentTypeId";
                    ddlContentType.DataTextField = "Description";
                    ddlContentType.DataBind();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void ddlLibraryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLibraryList.SelectedValue != "")
            {
                try
                {
                    PopulateContentTypeByLibraryListDropDown();
                    PopulateTeamInPrivilegeList();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                }
            }
        }

        protected void ddlContentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlContentType.SelectedValue != "")
            {
                try
                {
                    PopulateTeamInPrivilegeList();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                }
            }
        }

        protected void PopulateTeamInPrivilegeList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                var apList = obje.GetAllActivePrivilegeMaster();
                StringBuilder sb = new StringBuilder();
                CommonClass abcd = new CommonClass();
                sb.AppendFormat(@"<table width='98%' cellpadding='0' cellspacing='0' style='text-align:center;'><thead>
                                    <tr> <th>Team Name</th>");
                foreach (var p in apList)
                {
                     sb.AppendFormat(@"<th colspan='4'>" + p.PrivilegeName + "</th>");
                }
                sb.AppendFormat(@"<th colspan='4'>" + "Map Brand Category" + "</th>");
                sb.AppendFormat(@"<th colspan='4'>" + "Action" + "</th></tr><tr><th></th>");
                foreach (var p in apList)
                {
                    sb.AppendFormat(@"<th colspan='2'>Conf.</th><th colspan='2'>Non Conf.</th>");
                }
                sb.AppendFormat(@"<th colspan='6'></th></tr><tr><th></th>");
                foreach (var p in apList)
                {
                    sb.AppendFormat(@"<th>Self</th><th>Other</th><th>Self</th><th>Other</th>");
                }
                sb.AppendFormat(@"<th colspan='6'></th></tr></thead><tbody>");
                //sb.AppendFormat(@"</tr></thead><tbody>");
                var list = obje.GetAllActiveTeamInPrivilege((ddlContentType.SelectedValue != "") ? Convert.ToInt32(ddlContentType.SelectedValue) : 0);
                var mList = list.Where(x => x.TeamName != "System Administrator").Where(x => x.TeamName != "Application Administrator").ToList();
                var tList = mList.GroupBy(b => b.TeamName, b => b.TeamId).Select(b => new DAMServices.TeamInPrivilegeInfo
                {
                    TeamName = b.Key.ToString()
                }).ToList();
                foreach (var t in tList)
                {
                    String encURL = String.Empty;
                    sb.AppendFormat(@"<tr><td>" + t.TeamName + "</td>");
                    var uList = mList.Where(b => b.TeamName == t.TeamName).Select(b => new DAMServices.TeamInPrivilegeInfo
                    {
                        TeamId = b.TeamId,
                        PrivilegeId = b.PrivilegeId,
                        Permission = b.Permission,
                        IsBrandCategoryMapped = b.IsBrandCategoryMapped
                    }).ToList();

                    encURL = "index.aspx?" + EncryptQueryString(String.Format("TeamId={0}|TeamName={1}|LibId={2}|LibName={3}|ContentTypeId={4}|Description={5}|IsBrandCategoryMapped={6}",
                                 uList[0].TeamId, t.TeamName, ddlLibraryList.SelectedValue, ddlLibraryList.SelectedItem.Text, ddlContentType.SelectedValue, ddlContentType.SelectedItem.Text, uList[0].IsBrandCategoryMapped));

                    for (int i = 0; i < uList.Count; i++)
                    {
                        String BinaryCode = abcd.DecimalToBinary(uList[i].Permission);
                        for (int b = 0; b < 4; b++)
                        {
                            if (BinaryCode.Substring(b, 1) == "1")
                                sb.AppendFormat(@"<td><input type='checkbox' checked='True' disabled='True' /></td>");
                            else
                                sb.AppendFormat(@"<td><input type='checkbox' disabled='True' /></td>");
                        }
                    }
                    if(uList[0].IsBrandCategoryMapped)
                        sb.AppendFormat(@"<td colspan='4'><input type='checkbox' disabled='True' checked='True' /></td>");
                    else
                        sb.AppendFormat(@"<td colspan='4'><input type='checkbox' disabled='True' /></td>");
                    if(t.TeamName == "System Administrator" || t.TeamName == "Application Administrator")
                        sb.AppendFormat(@"<td colspan='4'></td>", encURL);
                    else
                        sb.AppendFormat(@"<td colspan='4'><a href='{0}'><img src='../img/nav-icons/icon_edit.png' alt='' /></a></td>", encURL);
                }
                sb.AppendFormat(@"</tr></tbody></table>");
                gdvTeamInPrivilege.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        protected void PopulateTeamMasterForAddListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlTeam.DataSource = objDAM.GetAllActiveTeamMaster();
                ddlTeam.DataValueField = "TeamId";
                ddlTeam.DataTextField = "TeamName";
                ddlTeam.DataBind();
                ddlTeam.Items.Remove(ddlTeam.Items.FindByText("Application Administrator"));
                ddlTeam.Items.Remove(ddlTeam.Items.FindByText("System Administrator"));
                //ddlTeam.Items.Insert(0, new ListItem("-- Select team --", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateLibraryForAddListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibrary.DataSource = objDAM.GetAllActiveLibraryMaster();
                ddlLibrary.DataValueField = "LibId";
                ddlLibrary.DataTextField = "LibName";
                ddlLibrary.DataBind();
                //ddlLibrary.Items.Insert(0, new ListItem("-- Select Library --", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void populateteamInPrivilegeByTteamId(Int32 TeamId, Int32 LibId, Int32 ContentTypeId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                grdEditTeamPrivilege.DataSource = objDAM.GetTeamInPrivilegePrivilegeAllTeamId(TeamId, LibId, ContentTypeId);
                grdEditTeamPrivilege.DataBind();
                if (grdEditTeamPrivilege.Rows.Count > 0)
                    grdEditTeamPrivilege.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateContentTypeByLibraryForAddListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                if (ddlLibrary.SelectedValue != "")
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    ddlContent.DataSource = objDAM.GetContentTypeNotInTeamPrivilegeByLibId(Convert.ToInt32(ddlTeam.SelectedValue), Convert.ToInt32(ddlLibrary.SelectedValue));
                    ddlContent.DataValueField = "ContentTypeId";
                    ddlContent.DataTextField = "Description";
                    ddlContent.DataBind();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                PopulateTeamMasterForAddListDropDown();
                PopulateLibraryForAddListDropDown();
                PopulateContentTypeByLibraryForAddListDropDown();
                PopulatePrivilegeListNotInTeamPrivilege();                
                popup.Show();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlTeam.SelectedValue != "")
            {
                try
                {
                    PopulateLibraryForAddListDropDown();
                    PopulateContentTypeByLibraryForAddListDropDown();
                    PopulatePrivilegeListNotInTeamPrivilege();
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                }
            }
        }

        protected void ddlLibrary_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlLibrary.SelectedValue != "")
            {
                try
                {
                    PopulateContentTypeByLibraryForAddListDropDown();
                    PopulatePrivilegeListNotInTeamPrivilege();
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                }
            }
        }

        protected void PopulatePrivilegeListNotInTeamPrivilege()
        {
            if (ddlContent.SelectedValue != "")
            {
                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvPrivilegeMaster.DataSource = objDAM.GetAllPrivilegeMasterRowsNotInTeamInPrivilegeServ(Convert.ToInt32(ddlContent.SelectedValue), Convert.ToInt32(ddlTeam.SelectedValue));
                    gdvPrivilegeMaster.DataBind();
                    if (gdvPrivilegeMaster.Rows.Count > 0)
                        gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvPrivilegeMaster.DataSource = null;
                gdvPrivilegeMaster.DataBind();
                popup.Show();
            }
        }

        protected void ddlContent_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulatePrivilegeListNotInTeamPrivilege();
                popup.Show();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvPrivilegeMaster.Rows.Count > 0)
            {
                try
                {
                    CommonClass objCommon = new CommonClass();
                    String strtmInPrvDetails = String.Empty;
                    for (int i = 0; i < gdvPrivilegeMaster.Rows.Count; i++)
                    {
                        Int32 Permission = 0;
                        String BinaryCode = String.Empty;
                        CheckBox chkCSelf = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkCSelf");
                        CheckBox chkCOther = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkCOther");
                        CheckBox chkGSelf = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkGSelf");
                        CheckBox chkGOther = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkGOther");
                        Label lblPrivilegeId = (Label)gdvPrivilegeMaster.Rows[i].FindControl("lblPrivilegeId");
                        BinaryCode = (chkCSelf.Checked) ? "1" : "0";
                        BinaryCode += (chkCOther.Checked) ? "1" : "0";
                        BinaryCode += (chkGSelf.Checked) ? "1" : "0";
                        BinaryCode += (chkGOther.Checked) ? "1" : "0";
                        Permission = objCommon.BinaryToInteger(BinaryCode);

                        strtmInPrvDetails += ddlTeam.SelectedValue + "," + lblPrivilegeId.Text + "," + Permission + "," + ddlContent.SelectedValue + "," + ddlLibrary.SelectedValue + "," + chkIsBrandCategoryAdd.Checked + "," + UserId + "," + GetIPAddress() + "|";
                    }
                    if (strtmInPrvDetails != "")
                    {
                        strtmInPrvDetails = strtmInPrvDetails.Remove(strtmInPrvDetails.Length - 1);
                        if (strtmInPrvDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertTeamInPrivilege(strtmInPrvDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        ddlLibraryList.SelectedValue = ddlLibrary.SelectedValue;
                        ddlContentType.SelectedValue = ddlContent.SelectedValue;
                        PopulateTeamInPrivilegeList();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                confirmMsg.InnerHtml = "";
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        protected void grdEditTeamPrivilege_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblEPermission = (Label)e.Row.FindControl("lblEPermission");

                    Label lblEPrivilegeName = (Label)e.Row.FindControl("lblEPrivilegeName");

                    CheckBox chkECSelf = (CheckBox)e.Row.FindControl("chkECSelf");
                    CheckBox chkECOther = (CheckBox)e.Row.FindControl("chkECOther");
                    CheckBox chkEGSelf = (CheckBox)e.Row.FindControl("chkEGSelf");
                    CheckBox chkEGOther = (CheckBox)e.Row.FindControl("chkEGOther");

                    chkECSelf.Checked = (Convert.ToInt16(lblEPermission.Text) < 8) ? false : true;
                    chkECOther.Checked = (Convert.ToInt16(lblEPermission.Text) > -1 && Convert.ToInt16(lblEPermission.Text) < 4) ||
                                            (Convert.ToInt16(lblEPermission.Text) > 7 && Convert.ToInt16(lblEPermission.Text) < 12) ? false : true;
                    chkEGSelf.Checked = (Convert.ToInt16(lblEPermission.Text) > -1 && Convert.ToInt16(lblEPermission.Text) < 2) || 
                                            (Convert.ToInt16(lblEPermission.Text) > 3 && Convert.ToInt16(lblEPermission.Text) < 6) ||
                                            (Convert.ToInt16(lblEPermission.Text) > 7 && Convert.ToInt16(lblEPermission.Text) < 10) ||
                                            (Convert.ToInt16(lblEPermission.Text) > 11 && Convert.ToInt16(lblEPermission.Text) < 14) ? false : true;
                    chkEGOther.Checked = (Convert.ToInt16(lblEPermission.Text) == 0 || Convert.ToInt16(lblEPermission.Text) == 2 ||
                                            Convert.ToInt16(lblEPermission.Text) == 4 || Convert.ToInt16(lblEPermission.Text) == 6 ||
                                            Convert.ToInt16(lblEPermission.Text) == 8 || Convert.ToInt16(lblEPermission.Text) == 10 ||
                                            Convert.ToInt16(lblEPermission.Text) == 12 || Convert.ToInt16(lblEPermission.Text) == 14) ? false : true;

                    chkEGSelf.Enabled = (lblEPrivilegeName.Text == "Search") ? false : true;
                    if (lblEPrivilegeName.Text == "Search")
                        chkEGSelf.Checked = true;
                    //if (lblEPrivilegeName.Text == "Upload")
                    //    chkECOther.Checked =  false;
                    //chkECOther.Enabled = (lblEPrivilegeName.Text == "Upload") ? false : true;
                    //if (lblEPrivilegeName.Text == "Upload")
                    //    chkEGOther.Checked =  false;
                    //chkEGOther.Enabled = (lblEPrivilegeName.Text == "Upload") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void btnEditSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (grdEditTeamPrivilege.Rows.Count > 0)
            {
                try
                {
                    String strtmInPrvDetails = String.Empty;
                    CommonClass abcd = new CommonClass();
                    for (int i = 0; i < grdEditTeamPrivilege.Rows.Count; i++)
                    {
                        Double Permission = 0;
                        String BinaryCode = String.Empty;
                        CheckBox chkECSelf = (CheckBox)grdEditTeamPrivilege.Rows[i].FindControl("chkECSelf");
                        CheckBox chkECOther = (CheckBox)grdEditTeamPrivilege.Rows[i].FindControl("chkECOther");
                        CheckBox chkEGSelf = (CheckBox)grdEditTeamPrivilege.Rows[i].FindControl("chkEGSelf");
                        CheckBox chkEGOther = (CheckBox)grdEditTeamPrivilege.Rows[i].FindControl("chkEGOther");
                        Label lblEPrivilegeId = (Label)grdEditTeamPrivilege.Rows[i].FindControl("lblEPrivilegeId");
                        BinaryCode = (chkECSelf.Checked) ? "1" : "0";
                        BinaryCode += (chkECOther.Checked) ? "1" : "0";
                        BinaryCode += (chkEGSelf.Checked) ? "1" : "0";
                        BinaryCode += (chkEGOther.Checked) ? "1" : "0";
                        Permission = abcd.BinaryToInteger(BinaryCode);
                        strtmInPrvDetails += hdnTeamId.Value + "," + lblEPrivilegeId.Text + "," + Permission + "," + hdnContentTypeId.Value + "," + hdnLibId.Value + "," + chkIsBrandCategoryEdit.Checked + "," + UserId + "," + GetIPAddress() + "|";
                    }
                    if (strtmInPrvDetails != "")
                    {
                        strtmInPrvDetails = strtmInPrvDetails.Remove(strtmInPrvDetails.Length - 1);
                        if (strtmInPrvDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertTeamInPrivilege(strtmInPrvDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                        ddlLibraryList.SelectedValue = hdnLibId.Value;
                        PopulateContentTypeByLibraryListDropDown();
                        ddlContentType.SelectedValue = hdnContentTypeId.Value;
                        PopulateTeamInPrivilegeList();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                confirmMsg.InnerHtml = "";
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        protected void chkCSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkCSelf = (CheckBox)Row.FindControl("chkCSelf");
            CheckBox chkCOther = (CheckBox)Row.FindControl("chkCOther");
            if (!chkCSelf.Checked)
                chkCOther.Checked = false;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void chkCOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkCSelf = (CheckBox)Row.FindControl("chkCSelf");
            CheckBox chkCOther = (CheckBox)Row.FindControl("chkCOther");
            if (chkCOther.Checked)
                chkCSelf.Checked = true;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void chkGSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkGSelf = (CheckBox)Row.FindControl("chkGSelf");
            CheckBox chkGOther = (CheckBox)Row.FindControl("chkGOther");
            if (!chkGSelf.Checked)
                chkGOther.Checked = false;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void chkGOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkGSelf = (CheckBox)Row.FindControl("chkGSelf");
            CheckBox chkGOther = (CheckBox)Row.FindControl("chkGOther");
            if (chkGOther.Checked)
                chkGSelf.Checked = true;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void chkECSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkECSelf = (CheckBox)Row.FindControl("chkECSelf");
            CheckBox chkECOther = (CheckBox)Row.FindControl("chkECOther");
            if (!chkECSelf.Checked)
                chkECOther.Checked = false;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                grdEditTeamPrivilege.HeaderRow.TableSection = TableRowSection.TableHeader;
            popupEdit.Show();
        }

        protected void chkECOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkECSelf = (CheckBox)Row.FindControl("chkECSelf");
            CheckBox chkECOther = (CheckBox)Row.FindControl("chkECOther");
            if (chkECOther.Checked)
                chkECSelf.Checked = true;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                grdEditTeamPrivilege.HeaderRow.TableSection = TableRowSection.TableHeader;
            popupEdit.Show();
        }

        protected void chkEGSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkEGSelf = (CheckBox)Row.FindControl("chkEGSelf");
            CheckBox chkEGOther = (CheckBox)Row.FindControl("chkEGOther");
            if (!chkEGSelf.Checked)
                chkEGOther.Checked = false;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                grdEditTeamPrivilege.HeaderRow.TableSection = TableRowSection.TableHeader;
            popupEdit.Show();
        }

        protected void chkEGOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkEGSelf = (CheckBox)Row.FindControl("chkEGSelf");
            CheckBox chkEGOther = (CheckBox)Row.FindControl("chkEGOther");
            if (chkEGOther.Checked)
                chkEGSelf.Checked = true;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                grdEditTeamPrivilege.HeaderRow.TableSection = TableRowSection.TableHeader;
            popupEdit.Show();
        }

        protected void gdvPrivilegeMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkGSelf = (CheckBox)e.Row.FindControl("chkGSelf");
                    CheckBox chkGOther = (CheckBox)e.Row.FindControl("chkGOther");
                    CheckBox chkCOther = (CheckBox)e.Row.FindControl("chkCOther");
                    Label lblPrivilegeName = (Label)e.Row.FindControl("lblPrivilegeName");
                    chkGSelf.Checked = (lblPrivilegeName.Text != "Search") ? false : true;
                    chkGSelf.Enabled = (lblPrivilegeName.Text == "Search") ? false : true;
                    //if (lblPrivilegeName.Text == "Upload")
                    //    chkGOther.Checked = false;
                    //chkGOther.Enabled = (lblPrivilegeName.Text == "Upload") ? false : true;
                    //if (lblPrivilegeName.Text == "Upload")
                    //    chkCOther.Checked = false;
                    //chkCOther.Enabled = (lblPrivilegeName.Text == "Upload") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
    }
}