﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAMServices
{
    public class EmailSettingsMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(EmailSettingsMaster));

        public void InsertEmailSettingsMaster(List<EmailSettingsInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@AppAdminId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.AppAdminId);
                    mCmd.AddParameter("@UserId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.UserId);
                    mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.TeamId);
                    mCmd.AddParameter("@IsUpload", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsUpload);
                    mCmd.AddParameter("@IsEdit", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsEdit);
                    mCmd.AddParameter("@IsDelete", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsDelete);
                    mCmd.AddParameter("@IsOnExpiry", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsOnExpiry);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, uList.IPAddress);
                    mCmd.CommandText = "EmailSettingsInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<EmailSettingsInfo> GetAllEmailSettingsMaster(Int32 TeamId)
        {
            List<EmailSettingsInfo> mList = new List<EmailSettingsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailSettingsSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailSettingsInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            AppAdminId = mCmd.GetFieldValue<Int32>("AppAdminId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsUpload = mCmd.GetFieldValue<Boolean>("IsUpload"),
                            IsEdit = mCmd.GetFieldValue<Boolean>("IsEdit"),
                            IsDelete = mCmd.GetFieldValue<Boolean>("IsDelete"),
                            IsOnExpiry = mCmd.GetFieldValue<Boolean>("IsOnExpiry"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EmailSettingsInfo> GetEmailSettingsSearch(String SearchText)
        {
            List<EmailSettingsInfo> mList = new List<EmailSettingsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailSettingsSearchByUser";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchUser", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailSettingsInfo
                        {
                            //TeamInPrivilegeId = mCmd.GetFieldValue<Int32>("TeamInPrivilegeId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            IsUpload = mCmd.GetFieldValue<Boolean>("IsUpload"),
                            IsEdit = mCmd.GetFieldValue<Boolean>("IsEdit"),
                            IsDelete = mCmd.GetFieldValue<Boolean>("IsDelete"),
                            IsOnExpiry = mCmd.GetFieldValue<Boolean>("IsOnExpiry"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        
    }
}
