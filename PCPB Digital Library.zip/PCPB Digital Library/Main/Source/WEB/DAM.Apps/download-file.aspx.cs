﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using QueryStringEncryption;

namespace DAM.Apps
{
    public partial class download_file : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                String encURL = "";
                encURL = Request.RawUrl;
                encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                if (!encURL.Equals(""))
                {
                    encURL = DecryptQueryString(encURL);
                    String[] queryStr = encURL.Split('&');
                    String[] filename = queryStr[0].Split('=');

                    String[] guid = queryStr[1].Split('=');

                    String filePath = guid[1];
                    String ext = System.IO.Path.GetExtension(filePath);
                    ext = ext.TrimStart('.');
                    DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                    var mList = objDAM.GetFileExtensionMasterByExtension(ext);
                    System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                    response.ClearContent();
                    response.Clear();
                    response.ContentType = mList[0].Description;
                    response.AddHeader("Content-Disposition",
                                       "attachment; filename=" + filename[1] + ";");
                    response.TransmitFile(filePath);
                    response.Flush();
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
        }

        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
    }
}