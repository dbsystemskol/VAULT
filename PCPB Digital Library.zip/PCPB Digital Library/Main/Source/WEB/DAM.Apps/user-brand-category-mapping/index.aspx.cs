﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;
using System.Text;
using QueryStringEncryption;

namespace DAM.Apps.user_brand_category_mapping
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                BindMenu(LibId);
                PopulateBrandCategoryMapping();
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-with-category/index.aspx'>Brand With Category</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../document-log/index.aspx'>Document Log</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateBrandCategoryMapping()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvBrandCategory.DataSource = objDAM.GetAllUserBrandCategoryMapping();
                gdvBrandCategory.DataBind();
                if (gdvBrandCategory.Rows.Count > 0)
                    gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateUser()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlUser.DataSource = objDAM.GetUserForBrandCategoryMapping();
                ddlUser.DataValueField = "UserId";
                ddlUser.DataTextField = "Name";
                ddlUser.DataBind();
                ddlUser.Items.Insert(0, new ListItem("---- Select User ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateBrand()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                chkBrand.DataSource = objDAM.GetLookupMasterByFieldId(1, 1);
                chkBrand.DataValueField = "LookupId";
                chkBrand.DataTextField = "FieldValue";
                chkBrand.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateCategory()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                chkCategory.DataSource = objDAM.GetLookupMasterByFieldId(2, 1);
                chkCategory.DataValueField = "LookupId";
                chkCategory.DataTextField = "FieldValue";
                chkCategory.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }



        protected void gdvBrandCategory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvBrandCategory_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.UserBrandCategoryMappingInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.UserBrandCategoryMappingInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        mData.UserBrandCategoryMappingId = RowId;
                        mData.ModifiedBy = UserId;
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateUserBrandCategoryMapping(mData);
                        if (r > 0)
                        {
                            PopulateBrandCategoryMapping();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateBrand();
            PopulateCategory();
            PopulateUser();
            ddlUser.SelectedValue = "0";            
            popup.Show();
            if(gdvBrandCategory.Rows.Count>0)
                gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void chkBrandSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            foreach (ListItem listItem in chkBrand.Items)
            {
                if(chkBrandSelectAll.Checked)
                    listItem.Selected = true;
                else
                    listItem.Selected = false;
            }
            popup.Show();
            if (gdvBrandCategory.Rows.Count > 0)
                gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void chkCategorySelectAll_CheckedChanged(object sender, EventArgs e)
        {
            foreach (ListItem listItem in chkCategory.Items)
            {
                if (chkCategorySelectAll.Checked)
                    listItem.Selected = true;
                else
                    listItem.Selected = false;
            }
            popup.Show();
            if (gdvBrandCategory.Rows.Count > 0)
                gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void ddlUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlUser.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    var mList = objDAM.GetUserBrandCategoryMappingByUserId(Convert.ToInt32(ddlUser.SelectedValue));
                    if (mList.Count() > 0)
                    {
                        var brandList = mList.Select(x => x.BrandId).Distinct().ToList();
                        for (int i = 0; i < brandList.Count(); i++)
                        {
                            foreach (ListItem listItem in chkBrand.Items)
                            {
                                if (listItem.Value == brandList[i].ToString())
                                    listItem.Selected = true;
                            }
                        }
                        var categoryList = mList.Select(x => x.CategoryId).Distinct().ToList();
                        for (int i = 0; i < categoryList.Count(); i++)
                        {
                            foreach (ListItem listItem in chkCategory.Items)
                            {
                                if (listItem.Value == categoryList[i].ToString())
                                    listItem.Selected = true;
                            }
                        }
                    }
                    popup.Show();
                    if (gdvBrandCategory.Rows.Count > 0)
                        gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                popup.Show();
            }
        }  

        
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (1==1)
            {
                try
                {
                    CommonClass objCommon = new CommonClass();
                    String strDetails = String.Empty;
                    int brandCount= chkBrand.Items.Cast<ListItem>().Where(x => x.Selected).Count();
                    var brandSelected = chkBrand.Items.Cast<ListItem>().Where(x => x.Selected).ToList();
                    int categoryCount = chkCategory.Items.Cast<ListItem>().Where(x => x.Selected).Count();
                    var categorySelected = chkCategory.Items.Cast<ListItem>().Where(x => x.Selected).ToList();
                    int loopCount = 0;
                    if (brandCount >= categoryCount)
                        loopCount = brandCount;
                    else
                        loopCount = categoryCount;
                    for (int i = 1; i <= loopCount; i++)
                    {
                        if(i <= brandCount && i <= categoryCount)
                            strDetails += brandSelected[i-1].Value + "," + categorySelected[i-1].Value + "," + ddlUser.SelectedValue + "," + UserId + "|";
                        else if(i > brandCount)
                            strDetails += brandSelected[0].Value + "," + categorySelected[i-1].Value + "," + ddlUser.SelectedValue + "," + UserId + "|";
                        else if (i > categoryCount)
                            strDetails += brandSelected[i-1].Value + "," + categorySelected[0].Value + "," + ddlUser.SelectedValue + "," + UserId + "|";
                    }

                    if (strDetails != "")
                    {
                        strDetails = strDetails.Remove(strDetails.Length - 1);
                        if (strDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertUserBrandCategoryMapping(strDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        PopulateBrandCategoryMapping();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvBrandCategory.DataSource = objDAM.UserBrandCategoryMappingSearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvBrandCategory.DataBind();
                if (gdvBrandCategory.Rows.Count > 0)
                    gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvBrandCategory.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "BrandCategoryMapping.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvBrandCategory.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvBrandCategory.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvBrandCategory.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvBrandCategory.HeaderRow.Cells.Count; i++)
                        gdvBrandCategory.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvBrandCategory.Columns.Count; i++)
                    {
                        if (gdvBrandCategory.Columns[i].HeaderText == "Active" || gdvBrandCategory.Columns[i].HeaderText == "Edit" || gdvBrandCategory.Columns[i].HeaderText == "Confidential" || gdvBrandCategory.Columns[i].HeaderText == "Non confidential")
                            gdvBrandCategory.Columns[i].Visible = false;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsActive")
                            gdvBrandCategory.Columns[i].Visible = true;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsConfidential")
                            gdvBrandCategory.Columns[i].Visible = true;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsNonConfidential")
                            gdvBrandCategory.Columns[i].Visible = true;
                    }
                    gdvBrandCategory.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}