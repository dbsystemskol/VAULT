﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
using System.Data;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration;

namespace DAM.Apps.notification_list
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                String encURL = "";
                encURL = Request.RawUrl;  
                if (!encURL.Contains("?"))
                    return;
                encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                if (!encURL.Equals(""))
                {
                    encURL = DecryptQueryString(encURL);
                    String[] queryStr = encURL.Split('^');
                    String[] sType = queryStr[0].Split('=');
                    BindNotificationList(LibId, UserId, sType[1].ToString());
                    BindNotification(UserId, TeamId, LibId, sType[1].ToString());
                }
            }
        }
        private void BindNotification(Int32 UserId, Int32 TeamId, Int32 LibId, String NotificationType)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                objDAM.UpdateUserNotification(UserId, TeamId, LibId, NotificationType);
                var mList = objDAM.GetUserNotification(TeamId, UserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private void BindNotificationList(Int32 LibId, Int32 UserId, String NotificationType)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.UserNotificationList(LibId, UserId, NotificationType);
                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    String encURL = String.Empty;
                    html = "<table id='tblList' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.FreeTextSearchTable.Columns)
                    {
                        if (dcol.ColumnName == "FileInfoId" || dcol.ColumnName == "DocId" || dcol.ColumnName == "Confidential")
                        { }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "FileInfoId" || column.ColumnName == "DocId" || column.ColumnName == "Confidential")
                            { }
                            else if (column.ColumnName == "Title")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divNotificationList.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
    }
}