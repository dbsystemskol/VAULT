﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;


namespace DAMServices
{
    public class LibraryAttributeSet
    {
        protected static ILog log = LogManager.GetLogger(typeof(LibraryAttributeSet));

        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByContentTypeId(Int32 ContentTypeId)
        {
            List<LibraryAttributeSetInfo> mList = new List<LibraryAttributeSetInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryAttributeSetByContentTypeId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryAttributeSetInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),
                            IsMandatory = mCmd.GetFieldValue<Boolean>("IsMandatory"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByLibId(Int32 LibId)
        {
            List<LibraryAttributeSetInfo> mList = new List<LibraryAttributeSetInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryAttributeSetByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryAttributeSetInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),
                            //IsMandatory = mCmd.GetFieldValue<Boolean>("IsMandatory"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
